package com.ltimindtree.officebuddyfinder.model

data class Event(
    val id          : String = "",
    val title       : String = "",
    val time        : String = "",
    val location    : String = "",
    val category    : String = "General",
    val description : String = "",
    val attendees   : List<String> = emptyList(),
    val imageUrl    : String = "",
    val isJoined    : Boolean = false,
    val creatorId   : String = ""
)
