package com.ltimindtree.officebuddyfinder.ui1.ui1.components

import androidx.lifecycle.ViewModel

// ─────────────────────────────────────────────────────────────────────────────
// MODELS  (used by TravelBuddyUI only — all data lives in Firestore)
// ─────────────────────────────────────────────────────────────────────────────

enum class TransportMode { CAR, TRAIN, BUS, FLIGHT }

enum class TravelType { HOME_TRAVEL, WEEKEND_TRIP }

// Thin ViewModel — no local data, no dummy data.
// All actual data is fetched via FirebaseRepository directly in TravelBuddyNavHost.
class TravelBuddyViewModel : ViewModel()
