//package com.ltimindtree.officebuddyfinder.ui1.ui1.components
//
//import androidx.compose.animation.core.animateFloatAsState
//import androidx.compose.animation.core.tween
//import androidx.compose.foundation.*
//import androidx.compose.foundation.border
//import androidx.compose.foundation.layout.*
//import androidx.compose.foundation.lazy.LazyColumn
//import androidx.compose.foundation.shape.CircleShape
//import androidx.compose.foundation.shape.RoundedCornerShape
//import androidx.compose.material.icons.Icons
//import androidx.compose.material.icons.automirrored.filled.ArrowBack
//import androidx.compose.material.icons.filled.*
//import androidx.compose.material3.*
//import androidx.compose.runtime.*
//import androidx.compose.runtime.getValue
//import androidx.compose.runtime.setValue
//import androidx.compose.ui.Alignment
//import androidx.compose.ui.Modifier
//import androidx.compose.ui.draw.clip
//import androidx.compose.ui.graphics.Color
//import androidx.compose.ui.graphics.StrokeCap
//import androidx.compose.ui.layout.ContentScale
//import androidx.compose.ui.text.font.FontWeight
//import androidx.compose.ui.unit.dp
//import androidx.compose.ui.unit.sp
//import androidx.lifecycle.ViewModel
//import androidx.lifecycle.viewmodel.compose.viewModel
//import androidx.navigation.NavController
//import coil.compose.AsyncImage
//import com.google.firebase.auth.ktx.auth
//import com.google.firebase.firestore.ktx.firestore
//import com.google.firebase.ktx.Firebase
//
//// ─────────────────────────────────────────────────────────────────────────────
////  COLORS & DATA MODEL
//// ─────────────────────────────────────────────────────────────────────────────
//
//private val Teal1 = Color(0xFF1A9E8F)
//private val TealTrack = Color(0xFFD0EFEC)
//private val ScreenBg = Color(0xFFF5F6F8)
//private val CardBg = Color(0xFFFFFFFF)
//private val TextPrimary = Color(0xFF111111)
//private val TextSecondary = Color(0xFF888888)
//
//data class UserProfile(
//    val name: String = "",
//    val role: String = "",
//    val bio: String = "",
//    val matchPercent: Int = 0,
//    val avatarUrl: String = "",
//    val interests: List<String> = emptyList(),
//    val hometown: String = ""
//)
//
//// ─────────────────────────────────────────────────────────────────────────────
////  VIEWMODEL (Handles Firebase)
//// ─────────────────────────────────────────────────────────────────────────────
//
//class ProfileViewModel : ViewModel() {
//    var userData by mutableStateOf(UserProfile())
//    var isLoading by mutableStateOf(false)
//
//    init { fetchUserProfile() }
//
//    fun fetchUserProfile() {
//        val uid = Firebase.auth.currentUser?.uid ?: return
//        Firebase.firestore.collection("users").document(uid).get()
//            .addOnSuccessListener { doc ->
//                doc.toObject(UserProfile::class.java)?.let { userData = it }
//                isLoading = false
//            }
//    }
//
//    fun saveProfile(profile: UserProfile, onComplete: () -> Unit) {
//        val uid = Firebase.auth.currentUser?.uid ?: return
//        Firebase.firestore.collection("users").document(uid).set(profile)
//            .addOnSuccessListener {
//                userData = profile
//                onComplete()
//            }
//    }
//}
//
//// ─────────────────────────────────────────────────────────────────────────────
////  MAIN SCREEN
//// ─────────────────────────────────────────────────────────────────────────────
//
//@OptIn(ExperimentalMaterial3Api::class)
//@Composable
//fun UserProfileScreen(navController: NavController) {
//    val vm: ProfileViewModel = viewModel()
//    var isEditing by remember { mutableStateOf(false) }
//
//    // Form State (for editing)
//    var editName by remember(vm.userData) { mutableStateOf(vm.userData.name) }
//    var editRole by remember(vm.userData) { mutableStateOf(vm.userData.role) }
//    var editBio by remember(vm.userData) { mutableStateOf(vm.userData.bio) }
//
//    Scaffold(
//        containerColor = ScreenBg,
//        topBar = {
//            CenterAlignedTopAppBar(
//                title = { Text("User Profile", fontWeight = FontWeight.Bold) },
//                navigationIcon = {
//                    IconButton(onClick = { if (isEditing) isEditing = false else navController.popBackStack() }) {
//                        Icon(if (isEditing) Icons.Default.Close else Icons.AutoMirrored.Filled.ArrowBack, null)
//                    }
//                },
//                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(containerColor = CardBg)
//            )
//        }
//    ) { padding ->
//        if (vm.isLoading) {
//            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = Teal) }
//        } else {
//            LazyColumn(
//                modifier = Modifier
//                    .fillMaxSize()
//                    .padding(padding),
//                contentPadding = PaddingValues(24.dp),
//                horizontalAlignment = Alignment.CenterHorizontally
//            ) {
//                // 1. Avatar
//                item {
//                    ProfileAvatar(imageUrl = vm.userData.avatarUrl)
//                    Spacer(Modifier.height(16.dp))
//                }
//
//                if (isEditing) {
//                    // 2. EDIT MODE
//                    item {
//                        EditableField("Name", editName) { editName = it }
//                        EditableField("Department", editRole) { editRole = it }
//                        EditableField("Bio", editBio, singleLine = false) { editBio = it }
//
//                        Spacer(Modifier.height(24.dp))
//                        Button(
//                            onClick = {
//                                val updated = vm.userData.copy(name = editName, role = editRole, bio = editBio)
//                                vm.saveProfile(updated) { isEditing = false }
//                            },
//                            modifier = Modifier.fillMaxWidth(),
//                            colors = ButtonDefaults.buttonColors(containerColor = Teal),
//                            shape = RoundedCornerShape(12.dp)
//                        ) {
//                            Icon(Icons.Default.Check, null)
//                            Spacer(Modifier.width(8.dp))
//                            Text("Save Changes")
//                        }
//                    }
//                } else {
//                    // 3. MODERN VIEW MODE
//                    item {
//                        Text(vm.userData.name, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold, color = TextPrimary)
//                        Text(vm.userData.role, color = Teal, fontWeight = FontWeight.Medium)
//                        Spacer(Modifier.height(24.dp))
//
//                        MatchPercentageCard(vm.userData.matchPercent)
//                        Spacer(Modifier.height(24.dp))
//
//                        InterestChipsSection(vm.userData.interests)
//                        Spacer(Modifier.height(24.dp))
//
//                        DetailItem1("Bio", vm.userData.bio)
//                        DetailItem1("Hometown", vm.userData.hometown)
//
//                        Spacer(Modifier.height(32.dp))
//                        OutlinedButton(
//                            onClick = { isEditing = true },
//                            modifier = Modifier.fillMaxWidth(),
//                            shape = RoundedCornerShape(12.dp),
//                            border = androidx.compose.foundation.BorderStroke(1.dp, Teal)
//                        ) {
//                            Icon(Icons.Default.Edit, null, tint = Teal)
//                            Spacer(Modifier.width(8.dp))
//                            Text("Edit Profile", color = Teal)
//                        }
//                    }
//                }
//            }
//        }
//    }
//}
//
//// ─────────────────────────────────────────────────────────────────────────────
////  COMPONENTS
//// ─────────────────────────────────────────────────────────────────────────────
//
//@Composable
//fun ProfileAvatar(imageUrl: String) {
//    Box(modifier = Modifier
//        .size(114.dp)
//        .clip(CircleShape)
//        .border(3.dp, Teal, CircleShape)) {
//        AsyncImage(
//            model = imageUrl.ifEmpty { Icons.Default.AccountCircle },
//            contentDescription = null,
//            contentScale = ContentScale.Crop,
//            modifier = Modifier.fillMaxSize()
//        )
//    }
//}
//
//@Composable
//fun MatchPercentageCard(matchPercent: Int) {
//    var triggered by remember { mutableStateOf(false) }
//    val progress by animateFloatAsState(if (triggered) matchPercent / 100f else 0f, tween(1000), label = "")
//    LaunchedEffect(Unit) { triggered = true }
//
//    Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = CardBg), elevation = CardDefaults.cardElevation(2.dp)) {
//        Row(Modifier.padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
//            Box(Modifier.size(70.dp), contentAlignment = Alignment.Center) {
//                CircularProgressIndicator(progress = { 1f }, color = TealTrack, strokeWidth = 6.dp, strokeCap = StrokeCap.Round)
//                CircularProgressIndicator(progress = { progress }, color = Teal, strokeWidth = 6.dp, strokeCap = StrokeCap.Round)
//                Text("$matchPercent%", fontWeight = FontWeight.Bold, fontSize = 14.sp)
//            }
//            Spacer(Modifier.width(20.dp))
//            Column {
//                Text("Match Score", fontSize = 12.sp, color = TextSecondary)
//                Text("Great connection potential!", fontWeight = FontWeight.Bold, fontSize = 15.sp)
//            }
//        }
//    }
//}
//
//@Composable
//fun InterestChipsSection(interests: List<String>) {
//    Column(Modifier.fillMaxWidth()) {
//        Text("Interests", fontWeight = FontWeight.Bold, fontSize = 18.sp)
//        Spacer(Modifier.height(12.dp))
//        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
//            interests.forEach { interest ->
//                Surface(shape = RoundedCornerShape(50.dp), color = Teal) {
//                    Text(interest, color = Color.White, modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp), fontSize = 13.sp)
//                }
//            }
//        }
//    }
//}
//
//@Composable
//fun EditableField(label: String, value: String, singleLine: Boolean = true, onValueChange: (String) -> Unit) {
//    Column(Modifier.padding(vertical = 8.dp)) {
//        Text(label, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TextSecondary)
//        OutlinedTextField(value = value, onValueChange = onValueChange, modifier = Modifier.fillMaxWidth(), singleLine = singleLine, shape = RoundedCornerShape(10.dp))
//    }
//}
//
//@Composable
//fun DetailItem1(label: String, value: String) {
//    Column(Modifier
//        .fillMaxWidth()
//        .padding(vertical = 8.dp)) {
//        Text(label, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TextSecondary)
//        Text(value, fontSize = 15.sp, modifier = Modifier.padding(top = 2.dp))
//    }
//}