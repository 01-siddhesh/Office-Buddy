package com.ltimindtree.officebuddyfinder.viewmodel

import androidx.lifecycle.ViewModel
import com.google.firebase.auth.FirebaseAuth
import com.ltimindtree.officebuddyfinder.repository.FirebaseRepository

class AuthViewModel : ViewModel() {
    private val auth = FirebaseAuth.getInstance()
    private val repo = FirebaseRepository()

    fun signup(
        email: String,
        password: String,
        name: String,
        department: String,
        onResult: (Boolean, String?) -> Unit
    ) {
        repo.signup(email, password, name, department) { success, message ->
            if (success) {
                // Send email verification
                auth.currentUser?.sendEmailVerification()
            }
            onResult(success, message)
        }
    }

    fun login(email: String, password: String, onResult: (Boolean, String?) -> Unit) {
        repo.login(email, password, onResult)
    }
}
