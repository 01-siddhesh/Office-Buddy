package com.ltimindtree.officebuddyfinder.ui1.ui1.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

// Simple data class for a friend entry
data class FriendItem(
    val id        : String,
    val name      : String,
    val email     : String,
    val acceptedAt: Long   // epoch seconds — used to sort newest first
)

@Composable
fun FriendsScreen(navController: NavController) {
    val db        = FirebaseFirestore.getInstance()
    val currentId = FirebaseAuth.getInstance().currentUser?.uid ?: ""

    var friends   by remember { mutableStateOf(listOf<FriendItem>()) }
    var isLoading by remember { mutableStateOf(true) }

    // Fetch all accepted buddyRequests where current user is sender OR receiver
    LaunchedEffect(currentId) {
        if (currentId.isBlank()) {
            isLoading = false
            return@LaunchedEffect
        }

        // We run two queries and merge the results
        val rawPairs = mutableListOf<Pair<String, Long>>() // (otherUserId, acceptedAt seconds)
        var receiverDone = false
        var senderDone   = false

        fun fetchUserDetails() {
            if (!receiverDone || !senderDone) return

            // Deduplicate and sort newest first
            val sorted = rawPairs
                .distinctBy { it.first }
                .sortedByDescending { it.second }

            if (sorted.isEmpty()) {
                friends   = emptyList()
                isLoading = false
                return
            }

            val result  = mutableListOf<FriendItem>()
            var fetched = 0

            for ((otherId, acceptedAt) in sorted) {
                db.collection("users").document(otherId).get()
                    .addOnSuccessListener { doc ->
                        result.add(
                            FriendItem(
                                id        = otherId,
                                name      = doc.getString("name") ?: "Unknown",
                                email     = doc.getString("email") ?: "",
                                acceptedAt = acceptedAt
                            )
                        )
                        fetched++
                        if (fetched == sorted.size) {
                            // Re-sort after all fetches complete (fetch order is non-deterministic)
                            friends   = result.sortedByDescending { it.acceptedAt }
                            isLoading = false
                        }
                    }
                    .addOnFailureListener {
                        fetched++
                        if (fetched == sorted.size) {
                            friends   = result.sortedByDescending { it.acceptedAt }
                            isLoading = false
                        }
                    }
            }
        }

        // Query 1: I am the receiver (someone sent me a request I accepted)
        db.collection("buddyRequests")
            .whereEqualTo("receiverId", currentId)
            .whereEqualTo("status", "accepted")
            .get()
            .addOnSuccessListener { result ->
                for (doc in result) {
                    val otherId    = doc.getString("senderId") ?: continue
                    val acceptedAt = doc.getTimestamp("updatedAt")?.seconds ?: 0L
                    rawPairs.add(Pair(otherId, acceptedAt))
                }
                receiverDone = true
                fetchUserDetails()
            }
            .addOnFailureListener {
                receiverDone = true
                fetchUserDetails()
            }

        // Query 2: I am the sender (I sent a request they accepted)
        db.collection("buddyRequests")
            .whereEqualTo("senderId", currentId)
            .whereEqualTo("status", "accepted")
            .get()
            .addOnSuccessListener { result ->
                for (doc in result) {
                    val otherId    = doc.getString("receiverId") ?: continue
                    val acceptedAt = doc.getTimestamp("updatedAt")?.seconds ?: 0L
                    rawPairs.add(Pair(otherId, acceptedAt))
                }
                senderDone = true
                fetchUserDetails()
            }
            .addOnFailureListener {
                senderDone = true
                fetchUserDetails()
            }
    }

    Scaffold(
        topBar = {
            Surface(color = Teal) {
                Row(
                    modifier = Modifier
                        .statusBarsPadding()
                        .padding(horizontal = 8.dp, vertical = 12.dp)
                        .fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                    Text(
                        "Friends",
                        fontSize  = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color     = Color.White
                    )
                }
            }
        }
    ) { innerPadding ->
        when {
            isLoading -> {
                Box(
                    modifier = Modifier.fillMaxSize().padding(innerPadding),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator(color = Teal)
                }
            }

            friends.isEmpty() -> {
                Box(
                    modifier = Modifier.fillMaxSize().padding(innerPadding),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        "No friends yet.\nSend buddy requests to connect!",
                        color    = Color.Gray,
                        fontSize = 15.sp,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )
                }
            }

            else -> {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Friends count header
                    item {
                        Text(
                            "${friends.size} ${if (friends.size == 1) "Friend" else "Friends"}",
                            fontSize   = 14.sp,
                            fontWeight = FontWeight.SemiBold,
                            color      = Color.Gray,
                            modifier   = Modifier.padding(bottom = 4.dp)
                        )
                    }

                    items(friends, key = { it.id }) { friend ->
                        FriendCard(friend = friend)
                    }
                }
            }
        }
    }
}

@Composable
private fun FriendCard(friend: FriendItem) {
    Card(
        modifier  = Modifier.fillMaxWidth(),
        shape     = RoundedCornerShape(12.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        colors    = CardDefaults.cardColors(containerColor = Color.White)
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(CircleShape)
                    .background(Color.LightGray),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    Icons.Default.AccountCircle,
                    contentDescription = null,
                    modifier = Modifier.size(36.dp),
                    tint     = Color.Gray
                )
            }

            Spacer(Modifier.width(12.dp))

            Column {
                Text(friend.name,  fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Text(friend.email, fontSize   = 13.sp, color = Color.Gray)
            }
        }
    }
}