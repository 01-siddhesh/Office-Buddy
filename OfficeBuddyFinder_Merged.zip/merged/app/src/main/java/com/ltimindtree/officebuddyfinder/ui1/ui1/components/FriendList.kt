package com.ltimindtree.officebuddyfinder.ui1.ui1.components

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.ltimindtree.officebuddyfinder.model.User
import com.ltimindtree.officebuddyfinder.viewmodel.BuddyViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FriendsListScreen(navController: NavController, viewModel: BuddyViewModel = viewModel()) {
    var friendsList by remember { mutableStateOf(listOf<User>()) }

    LaunchedEffect(Unit) {
        viewModel.getAcceptedFriends { users -> friendsList = users }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("My Friends") },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, "Back")
                    }
                }
            )
        }
    ) { padding ->
        if (friendsList.isEmpty()) {
            Box(Modifier.fillMaxSize().padding(padding), Alignment.Center) {
                Text("No friends yet", color = Color.Gray)
            }
        } else {
            LazyColumn(modifier = Modifier.padding(padding)) {
                items(friendsList) { friend ->
                    FriendUserCard(user = friend)
                }
            }
        }
    }
}

@Composable
fun FriendUserCard(user: User) {
    Card(
        modifier  = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp),
        shape     = RoundedCornerShape(12.dp),
        colors    = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(2.dp)
    ) {
        Row(
            modifier          = Modifier.padding(16.dp).fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(user.name,       style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text(user.department, style = MaterialTheme.typography.bodySmall,   color = Color.Gray)
            }
            Icon(Icons.Default.CheckCircle, "Friend", tint = Color(0xFF1A9E8F), modifier = Modifier.size(24.dp))
        }
    }
}
