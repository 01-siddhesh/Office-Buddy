package com.ltimindtree.officebuddyfinder.ui1.ui1.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Color.Companion.Cyan
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.ltimindtree.officebuddyfinder.viewmodel.AuthViewModel
import android.widget.Toast
import androidx.compose.ui.platform.LocalContext



data class PreferenceItem(val genre: String)

@Composable
fun PrefrencesScreen(navController: NavController) {
    val viewModel: AuthViewModel = viewModel()
    val context = LocalContext.current
    val Navy = Color(0xFFF5F5F5)      // light grey background (instead of dark navy)
    val Cyan = Color(0xFF1A9E8F)
    var name by remember { mutableStateOf("") }
    var jobProfile by remember { mutableStateOf("") }
    var bio by remember { mutableStateOf("") }
    var hometown by remember { mutableStateOf("") }
    
    var selectedMovie by remember { mutableStateOf("") }
    var isMovieDropdownExpanded by remember { mutableStateOf(false) }

    val moviesList = remember {
        listOf(
            PreferenceItem("Horror"),
            PreferenceItem("Comedy"),
            PreferenceItem("Romance"),
            PreferenceItem("Thriller")
        )
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.White),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .padding(horizontal = 28.dp)
                .clip(RoundedCornerShape(24.dp))
                .background(Color.White)
                .padding(horizontal = 28.dp, vertical = 36.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {

            Text(
                "PREFERENCES",
                color = Cyan,
                fontSize = 24.sp,
                fontWeight = FontWeight.Black,
                letterSpacing = (-0.5).sp
            )

            Spacer(Modifier.height(6.dp))

            Text(
                "Tell us what you love",
                color = Cyan,
                fontSize = 13.sp
            )

            Spacer(Modifier.height(24.dp))

             
            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                label = { Text("Enter your name") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Cyan,
                    unfocusedBorderColor = Cyan.copy(alpha = 0.3f),
                    focusedContainerColor = Navy,
                    unfocusedContainerColor = Navy,
                    focusedTextColor = Color.Black,
                    unfocusedTextColor = Color.Black,
                    cursorColor = Cyan,
                    focusedLabelColor = Cyan,
                    unfocusedLabelColor = Cyan.copy(alpha = 0.5f)
                )
            )

            Spacer(Modifier.height(16.dp))

            // Job Profile Field
            OutlinedTextField(
                value = jobProfile,
                onValueChange = { jobProfile = it },
                label = { Text("Enter your job profile") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Cyan,
                    unfocusedBorderColor = Cyan.copy(alpha = 0.3f),
                    focusedContainerColor = Navy,
                    unfocusedContainerColor = Navy,
                    focusedTextColor = Color.Black,
                    unfocusedTextColor = Color.Black,
                    cursorColor = Cyan,
                    focusedLabelColor = Cyan,
                    unfocusedLabelColor = Cyan.copy(alpha = 0.5f)
                )
            )

            Spacer(Modifier.height(16.dp))

            // Bio Field
            OutlinedTextField(
                value = bio,
                onValueChange = { bio = it },
                label = { Text("Enter bio") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Cyan,
                    unfocusedBorderColor = Cyan.copy(alpha = 0.3f),
                    focusedContainerColor = Navy,
                    unfocusedContainerColor = Navy,
                    focusedTextColor = Color.Black,
                    unfocusedTextColor = Color.Black,
                    cursorColor = Cyan,
                    focusedLabelColor = Cyan,
                    unfocusedLabelColor = Cyan.copy(alpha = 0.5f)
                )
            )

            Spacer(Modifier.height(16.dp))

            // Movies Dropdown Label
            Text(
                "Movies",
                color = Cyan,
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(Modifier.height(8.dp))

            // Dropdown Selector
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(Navy)
                    .clickable { isMovieDropdownExpanded = !isMovieDropdownExpanded },
                contentAlignment = Alignment.CenterStart
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (selectedMovie.isEmpty()) "Choose a genre" else selectedMovie,
                        color = if (selectedMovie.isEmpty()) Color.White else Cyan,
                        fontSize = 14.sp
                    )
                    Text(
                        if (isMovieDropdownExpanded) "▲" else "▼",
                        color = Cyan,
                        fontSize = 11.sp
                    )
                }
            }

            if (isMovieDropdownExpanded) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(bottomStart = 12.dp, bottomEnd = 12.dp))
                        .background(Color(0xFF0D2D55))
                ) {
                    moviesList.forEachIndexed { index, item ->
                        val isSelected = selectedMovie == item.genre
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(if (isSelected) Cyan.copy(alpha = 0.12f) else Color.Transparent)
                                .clickable {
                                    selectedMovie = item.genre
                                    isMovieDropdownExpanded = false
                                }
                                .padding(horizontal = 16.dp, vertical = 14.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                item.genre,
                                color = if (isSelected) Cyan else Color.White,
                                fontSize = 14.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            )
                            if (isSelected) {
                                Text("✓", color = Cyan, fontWeight = FontWeight.Black)
                            }
                        }
                        if (index < moviesList.size - 1) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(1.dp)
                                    .background(Cyan.copy(alpha = 0.08f))
                            )
                        }
                    }
                }
            }

            Spacer(Modifier.height(16.dp))

            // Hometown Field
            OutlinedTextField(
                value = hometown,
                onValueChange = { hometown = it },
                label = { Text("Enter hometown") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Cyan,
                    unfocusedBorderColor = Cyan.copy(alpha = 0.3f),
                    focusedContainerColor = Navy,
                    unfocusedContainerColor = Navy,
                    focusedTextColor = Color.Black,
                    unfocusedTextColor = Color.Black,
                    cursorColor = Cyan,
                    focusedLabelColor = Cyan,
                    unfocusedLabelColor = Cyan.copy(alpha = 0.5f)
                )
            )

            Spacer(Modifier.height(24.dp))


            Button(
                onClick = {
                    viewModel.savePreferences(
                        name = name,

                        jobProfile = jobProfile,
                        bio = bio,
                        selectedMovie = selectedMovie,
                        hometown = hometown
                    ) { success ->

                        if (success) {
                            Toast.makeText(context, "Preferences saved!", Toast.LENGTH_SHORT).show()
                            com.google.firebase.auth.FirebaseAuth.getInstance().signOut()
                            navController.navigate("login") {
                                popUpTo(0) { inclusive = true }
                            }
                        }
                        else {
                            Toast.makeText(
                                context,
                                "Failed to save. Try again.",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    }
                },
                enabled = selectedMovie.isNotEmpty(),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Cyan,
                    contentColor = Navy,
                    disabledContainerColor = Cyan.copy(alpha = 0.25f),
                    disabledContentColor = Color.White.copy(alpha = 0.4f)
                )
            ) {
                Text(
                    "Save Preferences",
                    fontWeight = FontWeight.Black,
                    fontSize = 15.sp
                )
            }
        }
    }
}
