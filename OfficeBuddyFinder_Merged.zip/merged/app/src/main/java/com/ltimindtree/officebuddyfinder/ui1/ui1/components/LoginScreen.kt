package com.ltimindtree.officebuddyfinder.ui1.ui1.components
//
//import androidx.compose.animation.core.animateFloatAsState
//import androidx.compose.animation.core.tween
//import androidx.compose.foundation.Image
//import androidx.compose.foundation.background
//import androidx.compose.foundation.layout.Arrangement
//import androidx.compose.foundation.layout.Box
//import androidx.compose.foundation.layout.Column
//import androidx.compose.foundation.layout.Row
//import androidx.compose.foundation.layout.Spacer
//import androidx.compose.foundation.layout.fillMaxSize
//import androidx.compose.foundation.layout.fillMaxWidth
//import androidx.compose.foundation.layout.height
//import androidx.compose.foundation.layout.offset
//import androidx.compose.foundation.layout.padding
//import androidx.compose.foundation.shape.RoundedCornerShape
//import androidx.compose.material3.Button
//import androidx.compose.material3.MaterialTheme
//import androidx.compose.material3.OutlinedTextField
//import androidx.compose.material3.OutlinedTextFieldDefaults
//import androidx.compose.material3.Text
//import androidx.compose.material3.TextButton
//import androidx.compose.runtime.Composable
//import androidx.compose.runtime.LaunchedEffect
//import androidx.compose.runtime.getValue
//import androidx.compose.runtime.mutableStateOf
//import androidx.compose.runtime.remember
//import androidx.compose.runtime.setValue
//import androidx.compose.ui.Alignment
//import androidx.compose.ui.Modifier
//import androidx.compose.ui.draw.alpha
//import androidx.compose.ui.draw.clip
//import androidx.compose.ui.graphics.Color
//import androidx.compose.ui.graphics.Color.Companion.Cyan
//import androidx.compose.ui.res.painterResource
//import androidx.compose.ui.text.font.FontWeight
//import androidx.compose.ui.unit.dp
//import androidx.compose.ui.unit.sp
//import androidx.lifecycle.viewmodel.compose.viewModel
//import androidx.navigation.NavController
//import com.ltimindtree.officebuddyfinder.R
//import com.ltimindtree.officebuddyfinder.viewmodel.AuthViewModel
//
//
//@Composable
//fun LoginScreen(navController: NavController){
//    var email by remember {
//        mutableStateOf("")
//    }
//    var password by remember {
//        mutableStateOf("")
//    }
//    val viewModel : AuthViewModel = viewModel()
//    Column(modifier = Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.Center) {
//        Text(text = "WorkBond", style = MaterialTheme.typography.headlineMedium)
//        Spacer(modifier = Modifier.height(30.dp))
//        OutlinedTextField(value = email, onValueChange = {email=it}, label = {Text(text = "Enter your Email")})
//        Spacer(modifier = Modifier.height(20.dp))
//        OutlinedTextField(value = password, onValueChange = {password=it}, label = {Text(text = "Enter your Password")})
//        Spacer(modifier = Modifier.height(20.dp))
//        Button(onClick = {
//            viewModel.login(email,password,{
//                                           success,error ->
//                if(success){
//                    navController.navigate("home")
//                }
//            })}) { Text(text = "Login")}
//        Spacer(modifier = Modifier.height(20.dp))
//        TextButton(onClick = {navController.navigate("signup")}) {Text(text = "Create Account") }
//    }
//}
//
//
//
//


import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Color.Companion.Cyan
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.ltimindtree.officebuddyfinder.R
import com.ltimindtree.officebuddyfinder.viewmodel.AuthViewModel

val Navy = Color(0xFF001F3F) // Defining Navy as it's used in the friend's code

@Composable
fun LoginScreen(navController: NavController) {
    val Navy = Color(0xFFF5F5F5)      // light grey background (instead of dark navy)
    val Cyan = Color(0xFF1A9E8F)      // teal (instead of cyan blue)


    val viewModel: AuthViewModel = viewModel()

    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var entered by remember { mutableStateOf(false) }

    // Animation states
    LaunchedEffect(Unit) { entered = true }

    val alpha by animateFloatAsState(
        targetValue = if (entered) 1f else 0f,
        animationSpec = tween(700),
        label = "fade"
    )
    val slideY by animateFloatAsState(
        targetValue = if (entered) 0f else 60f,
        animationSpec = tween(700),
        label = "slide"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.White),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .padding(horizontal = 28.dp)
                .alpha(alpha)
                .offset(y = slideY.dp)
                .clip(RoundedCornerShape(24.dp))
                .background(Color.White)
                .padding(horizontal = 28.dp, vertical = 32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                "LOGIN PAGE",
                color = Cyan,
                fontSize = 26.sp,
                fontWeight = FontWeight.Black,
                letterSpacing = (-0.5).sp
            )

            Spacer(Modifier.height(10.dp))

            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "Welcome back ",
                    color = Cyan.copy(alpha = 0.7f),
                    fontSize = 13.sp
                )
                // Using handshake as a fallback if waving hand is missing
                Image(
                    painter = painterResource(id = R.drawable.outline_handshake_24),
                    contentDescription = "welcome icon"
                )
            }

            Spacer(Modifier.height(28.dp))

            OutlinedTextField(
                value = email,
                onValueChange = { email = it },
                label = { Text("Enter your email id") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Cyan,
                    unfocusedBorderColor = Cyan.copy(alpha = 0.3f),
                    focusedContainerColor = Navy,
                    unfocusedContainerColor = Navy,
                    focusedTextColor = Color.Black,
                    unfocusedTextColor = Color.Black,
                    cursorColor = Cyan,
                    focusedLabelColor = Cyan,
                    unfocusedLabelColor = Cyan.copy(alpha = 0.5f)
                )
            )

            Spacer(Modifier.height(14.dp))

            OutlinedTextField(
                value = password,
                onValueChange = { password = it },
                label = { Text("Enter your password") },
                visualTransformation = PasswordVisualTransformation(),
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Cyan,
                    unfocusedBorderColor = Cyan.copy(alpha = 0.3f),
                    focusedContainerColor = Navy,
                    unfocusedContainerColor = Navy,
                    focusedTextColor = Color.Black,
                    unfocusedTextColor = Color.Black,
                    cursorColor = Cyan,
                    focusedLabelColor = Cyan,
                    unfocusedLabelColor = Cyan.copy(alpha = 0.5f)
                )
            )

            Spacer(Modifier.height(26.dp))

            Button(
                onClick = {
                    viewModel.login(email, password) { success, error ->
                        if (success) {
                            navController.navigate("home")
                        }
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Cyan,
                    contentColor = Navy
                )
            ) {
                Text(
                    "Login",
                    fontWeight = FontWeight.Black,
                    fontSize = 15.sp
                )
            }

            Spacer(Modifier.height(18.dp))

            Row(verticalAlignment = Alignment.CenterVertically) {
                // Friend's code used a specific icon here, using handshake as placeholder if missing
                Image(
                    painter = painterResource(id = R.drawable.outline_handshake_24),
                    contentDescription = "pointing down",
                    modifier = Modifier.rotate(180f)
                )
                Text(
                    " Create your account below!",
                    color = Cyan,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium
                )
            }

            Spacer(Modifier.height(6.dp))
            Text(
                "New user ? Register here",
                color = Cyan,
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.clickable { navController.navigate("signup") }
            )
        }
    }
}