package com.ltimindtree.officebuddyfinder.ui1.ui1.components

import android.widget.Toast
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Color.Companion.Cyan
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.ltimindtree.officebuddyfinder.R
import com.ltimindtree.officebuddyfinder.viewmodel.AuthViewModel



@Composable
fun SignupScreen(navController: NavController) {
    val Navy = Color(0xFFF5F5F5)      // light grey background (instead of dark navy)
    val Cyan = Color(0xFF1A9E8F)
    val viewModel: AuthViewModel = viewModel()
    var name by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var department by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }
    
    var entered by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { entered = true }

    val alpha by animateFloatAsState(
        targetValue = if (entered) 1f else 0f,
        animationSpec = tween(700),
        label = "fade"
    )
    val slideY by animateFloatAsState(
        targetValue = if (entered) 0f else 60f,
        animationSpec = tween(700),
        label = "slide"
    )

    val context = LocalContext.current

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.White),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .padding(horizontal = 28.dp)
                .alpha(alpha)
                .offset(y = slideY.dp)
                .clip(RoundedCornerShape(24.dp))
                .background(Color.White)
                .padding(horizontal = 28.dp, vertical = 32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                "REGISTRATION",
                color = Cyan,
                fontSize = 26.sp,
                fontWeight = FontWeight.Black,
                letterSpacing = (-0.5).sp
            )

            Spacer(Modifier.height(10.dp))

            Text(
                "Create your account",
                color = Cyan.copy(alpha = 0.7f),
                fontSize = 13.sp
            )

            Spacer(Modifier.height(24.dp))

            // Email Field
            OutlinedTextField(
                value = email,
                onValueChange = { email = it },
                label = { Text("Enter your email") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Cyan,
                    unfocusedBorderColor = Cyan.copy(alpha = 0.3f),
                    focusedContainerColor = Navy,
                    unfocusedContainerColor = Navy,
                    focusedTextColor = Color.Black,
                    unfocusedTextColor = Color.Black,
                    cursorColor = Cyan,
                    focusedLabelColor = Cyan,
                    unfocusedLabelColor = Cyan.copy(alpha = 0.5f)
                )
            )

            Spacer(Modifier.height(12.dp))

            // Name Field
            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                label = { Text("Enter your name") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Cyan,
                    unfocusedBorderColor = Cyan.copy(alpha = 0.3f),
                    focusedContainerColor = Navy,
                    unfocusedContainerColor = Navy,
                    focusedTextColor = Color.Black,
                    unfocusedTextColor = Color.Black,
                    cursorColor = Cyan,
                    focusedLabelColor = Cyan,
                    unfocusedLabelColor = Cyan.copy(alpha = 0.5f)
                )
            )

            Spacer(Modifier.height(12.dp))

            // Department Field
            OutlinedTextField(
                value = department,
                onValueChange = { department = it },
                label = { Text("Enter your department") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Cyan,
                    unfocusedBorderColor = Cyan.copy(alpha = 0.3f),
                    focusedContainerColor = Navy,
                    unfocusedContainerColor = Navy,
                    focusedTextColor = Color.Black,
                    unfocusedTextColor = Color.Black,
                    cursorColor = Cyan,
                    focusedLabelColor = Cyan,
                    unfocusedLabelColor = Cyan.copy(alpha = 0.5f)
                )
            )

            Spacer(Modifier.height(12.dp))

            // Password Field
            OutlinedTextField(
                value = password,
                onValueChange = { password = it },
                label = { Text("Create a password") },
                visualTransformation = PasswordVisualTransformation(),
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Cyan,
                    unfocusedBorderColor = Cyan.copy(alpha = 0.3f),
                    focusedContainerColor = Navy,
                    unfocusedContainerColor = Navy,
                    focusedTextColor = Color.Black,
                    unfocusedTextColor = Color.Black,
                    cursorColor = Cyan,
                    focusedLabelColor = Cyan,
                    unfocusedLabelColor = Cyan.copy(alpha = 0.5f)
                )
            )

            Spacer(Modifier.height(12.dp))

            // Confirm Password Field
            OutlinedTextField(
                value = confirmPassword,
                onValueChange = { confirmPassword = it },
                label = { Text("Confirm the password") },
                visualTransformation = PasswordVisualTransformation(),
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Cyan,
                    unfocusedBorderColor = Cyan.copy(alpha = 0.3f),
                    focusedContainerColor = Navy,
                    unfocusedContainerColor = Navy,
                    focusedTextColor = Color.Black,
                    unfocusedTextColor = Color.Black,
                    cursorColor = Cyan,
                    focusedLabelColor = Cyan,
                    unfocusedLabelColor = Cyan.copy(alpha = 0.5f)
                )
            )

            Spacer(Modifier.height(24.dp))

            val isFormValid = email.contains("@") && password.length >= 6 && password == confirmPassword && name.isNotEmpty() && department.isNotEmpty()

            Button(
                onClick = {
                    viewModel.signup(email, password, name, department) { success, error ->
                        if (success) {
                            Toast.makeText(context, "Sign up Successful", Toast.LENGTH_SHORT).show()
                            navController.navigate("prefrences") { popUpTo("signup") { inclusive = true } }
                        } else {
                            Toast.makeText(context, error ?: "Sign up failed", Toast.LENGTH_LONG).show()
                        }
                    }
                },
                enabled = isFormValid,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Cyan,
                    contentColor = Navy,
                    disabledContainerColor = Cyan.copy(alpha = 0.3f),
                    disabledContentColor = Navy.copy(alpha = 0.5f)
                )
            ) {
                Text(
                    "Signup",
                    fontWeight = FontWeight.Black,
                    fontSize = 15.sp
                )
            }

            Spacer(Modifier.height(18.dp))

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                Image(
                    painter = painterResource(R.drawable.outline_handshake_24),
                    contentDescription = "pointingat",
                    modifier = Modifier.rotate(90f)
                )
                Text(
                    "Already have an account? ",
                    color = Cyan.copy(alpha = 0.7f),
                    fontSize = 12.sp
                )

                Text(
                    "Login here",
                    color = Cyan,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.clickable {
                        navController.popBackStack()
                    }
                )
            }
        }
    }
}
