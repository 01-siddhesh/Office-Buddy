package com.ltimindtree.officebuddyfinder.ui1.ui1.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

@Composable
fun BuddyCard(name:String,department: String,onConnectClick: ()-> Unit){
    Card (modifier = Modifier.fillMaxWidth().padding(8.dp), elevation = CardDefaults.cardElevation(6.dp)){
        Row (modifier = Modifier.padding(16.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween){
            Column() {
                Text(name, fontWeight = FontWeight.Bold)
                Text(department)
                // Yahan changes kiye gaye hain: {onConnectClick} ko onConnectClick se replace kiya hai
                Button(onClick = onConnectClick) { Text(text = "Connect") }
            }

        }
    }
}