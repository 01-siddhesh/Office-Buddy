package com.ltimindtree.officebuddyfinder.model

data class BuddyRequest(
    val senderId: String = "",
    val receiverId: String = "",
    val status: String = "pending"
)