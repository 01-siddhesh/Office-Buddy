package com.ltimindtree.officebuddyfinder.ui1.ui1.components

import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.google.firebase.auth.FirebaseAuth
import com.ltimindtree.officebuddyfinder.R
import com.ltimindtree.officebuddyfinder.model.User
import com.ltimindtree.officebuddyfinder.viewmodel.BuddyViewModel
import com.ltimindtree.officebuddyfinder.viewmodel.RequestViewModel
import kotlinx.coroutines.launch

@Composable
fun HomeScreen(navController: NavController) {
    val viewModel        : BuddyViewModel   = viewModel()
    val requestViewModel : RequestViewModel = viewModel()
    val auth             = FirebaseAuth.getInstance()
    val context          = LocalContext.current
    val drawerState      = rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope            = rememberCoroutineScope()

    var userList by remember { mutableStateOf(listOf<User>()) }
    val currentUserId = auth.currentUser?.uid ?: ""
    val hasNewFriend by requestViewModel.hasNewFriend

    LaunchedEffect(Unit) {
        viewModel.getAllUsers { users -> userList = users }
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet(modifier = Modifier.width(300.dp)) {
                Text("Menu", modifier = Modifier.padding(16.dp), fontSize = 24.sp, fontWeight = FontWeight.Bold)
                HorizontalDivider()
                NavigationDrawerItem(
                    label    = { Text("Events") },
                    selected = false,
                    icon     = { Icon(Icons.Default.DateRange, null) },
                    onClick  = { scope.launch { drawerState.close() }; navController.navigate("events") }
                )
                NavigationDrawerItem(
                    label    = { Text("Travel Buddy") },
                    selected = false,
                    icon     = { Icon(Icons.Default.Place, null) },
                    onClick  = { scope.launch { drawerState.close() }; navController.navigate("travel") }
                )
                NavigationDrawerItem(
                    label    = { Text("Profile") },
                    selected = false,
                    icon     = { Icon(Icons.Default.AccountCircle, null) },
                    onClick  = {
                        scope.launch { drawerState.close() }
                        navController.navigate("profile/{name}/{department}")
                    }
                )
                NavigationDrawerItem(
                    label    = { Text("Requests") },
                    selected = false,
                    icon     = { Icon(Icons.Default.AddCircle, null) },
                    onClick  = {
                        scope.launch { drawerState.close() }
                        navController.navigate("requests")
                    }
                )
                Spacer(Modifier.weight(1f))
                NavigationDrawerItem(
                    label    = { Text("Logout", color = Color.Red) },
                    selected = false,
                    icon     = { Icon(Icons.Default.ExitToApp, null, tint = Color.Red) },
                    onClick  = {
                        auth.signOut()
                        navController.navigate("login") { popUpTo("home") { inclusive = true } }
                    }
                )
            }
        }
    ) {
        Scaffold(
            topBar = {
                Surface(modifier = Modifier.fillMaxWidth(), color = Teal, tonalElevation = 3.dp) {
                    Row(
                        modifier = Modifier
                            .statusBarsPadding()
                            .padding(horizontal = 16.dp, vertical = 12.dp)
                            .fillMaxWidth(),
                        verticalAlignment    = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        // Logo + app name
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Image(
                                painter            = painterResource(R.drawable.outline_handshake_24),
                                contentDescription = "logo",
                                modifier           = Modifier.size(25.dp)
                            )
                            Spacer(Modifier.width(12.dp))
                            Text("WorkBond", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Color.White)
                        }

                        // Friends badge + menu
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            TextButton(
                                onClick = {
                                    requestViewModel.clearNewFriendFlag()
                                    navController.navigate("friends")
                                },
                                colors = ButtonDefaults.textButtonColors(contentColor = Color.White)
                            ) {
                                if (hasNewFriend) {
                                    Box(Modifier.size(8.dp).clip(CircleShape).background(Color(0xFF4CAF50)))
                                    Spacer(Modifier.width(6.dp))
                                    Text("New Friend!", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color(0xFF4CAF50))
                                } else {
                                    Text("Friends", fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = Color.White)
                                }
                            }
                            IconButton(onClick = { scope.launch { drawerState.open() } }) {
                                Icon(Icons.Default.Menu, "Menu", tint = Color.White)
                            }
                        }
                    }
                }
            }
        ) { innerPadding ->
            Column(modifier = Modifier.padding(innerPadding).fillMaxSize()) {
                Text(
                    "Recommended for you",
                    modifier   = Modifier.padding(16.dp),
                    fontSize   = 20.sp,
                    fontWeight = FontWeight.Bold
                )
                LazyColumn(
                    modifier            = Modifier.fillMaxSize(),
                    contentPadding      = PaddingValues(bottom = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(userList) { user ->
                        if (user.id != currentUserId) {
                            UserListItem(
                                user           = user,
                                onConnectClick = {
                                    if (currentUserId.isNotBlank()) {
                                        viewModel.sendRequest(currentUserId, user.id) { success ->
                                            if (success) Toast.makeText(context, "Request sent!", Toast.LENGTH_SHORT).show()
                                            else Toast.makeText(context, "Already sent or failed", Toast.LENGTH_SHORT).show()
                                        }
                                    }
                                },
                                onClick       = { navController.navigate("other_profile/${user.id}") },
                                navController = navController
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun UserListItem(user: User, onConnectClick: () -> Unit, onClick: () -> Unit, navController: NavController) {
    ElevatedCard(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp).background(Color.White),
        shape    = RoundedCornerShape(12.dp),
        onClick  = { navController.navigate("other_profile/${user.id}") }
    ) {
        Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier         = Modifier.size(60.dp).clip(CircleShape).background(Color.LightGray),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.AccountCircle, "profile pic", Modifier.size(40.dp), tint = Color.Gray)
            }
            Spacer(Modifier.width(16.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(user.name,       fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Text(user.department, fontSize   = 14.sp, color = Color.DarkGray)
            }
            IconButton(onClick = onConnectClick) {
                Icon(Icons.Default.Add, "Connect")
            }
        }
    }
}
