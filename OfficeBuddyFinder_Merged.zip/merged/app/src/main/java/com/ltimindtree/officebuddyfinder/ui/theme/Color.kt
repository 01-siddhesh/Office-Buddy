package com.ltimindtree.officebuddyfinder.ui.theme

import androidx.compose.ui.graphics.Color

val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)

//
//val Teal = Color(0xFF1A9E8F)
//
//// --- PALETTE ---
//val TealLight   = Color(0xFF3BC6B8)
// val TealBg      = Color(0xFFE0F5F3)
// val ScreenBg    = Color(0xFFF5F6F8)
// val CardBg      = Color(0xFFFFFFFF)
// val InputBg     = Color(0xFFF9FAFA)
// val DividerClr  = Color(0xFFE8EEEE)
// val TextPrimary = Color(0xFF111111)
// val TextSecond  = Color(0xFF666666)
// val TextHint    = Color(0xFFAAAAAA)