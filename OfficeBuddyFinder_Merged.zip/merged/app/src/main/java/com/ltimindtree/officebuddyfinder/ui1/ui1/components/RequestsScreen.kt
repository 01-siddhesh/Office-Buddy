package com.ltimindtree.officebuddyfinder.ui1.ui1.components

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.ltimindtree.officebuddyfinder.R
import com.ltimindtree.officebuddyfinder.model.ConnectionRequest
import com.ltimindtree.officebuddyfinder.viewmodel.RequestViewModel

private val TealUI       = Color(0xFF1A9E8F)
private val BackgroundUI = Color(0xFFF2F6F5)
private val CardWhite    = Color(0xFFFFFFFF)
private val DarkTextUI   = Color(0xFF0D2D2A)
private val SubTextUI    = Color(0xFF5A8A84)
private val ErrorRedUI   = Color(0xFFE53935)
private val SuccessGreen = Color(0xFF2E7D32)

@Composable
fun RequestsScreen(navController: NavController) {
    val vm      : RequestViewModel = viewModel()
    val context = LocalContext.current

    LaunchedEffect(Unit) { vm.fetchRequests() }

    Box(modifier = Modifier.fillMaxSize().background(BackgroundUI)) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Header
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(CardWhite)
                    .padding(top = 48.dp, bottom = 20.dp, start = 20.dp, end = 20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(Modifier.size(56.dp).background(TealUI, CircleShape), Alignment.Center) {
                    Image(
                        painter        = painterResource(R.drawable.outline_handshake_24),
                        colorFilter    = ColorFilter.tint(Color.White),
                        contentDescription = "Logo",
                        modifier       = Modifier.size(32.dp)
                    )
                }
                Spacer(Modifier.height(12.dp))
                Text("Connection Requests", color = DarkTextUI, fontSize = 22.sp, fontWeight = FontWeight.Black)
                Text("${vm.requests.count { !it.isAccepted }} pending", color = SubTextUI, fontSize = 13.sp)
            }

            if (vm.isLoading.value) {
                Box(Modifier.fillMaxSize(), Alignment.Center) {
                    CircularProgressIndicator(color = TealUI)
                }
            } else if (vm.requests.isEmpty()) {
                Box(Modifier.fillMaxSize(), Alignment.Center) {
                    Text("No pending requests", color = SubTextUI)
                }
            } else {
                LazyColumn(
                    modifier            = Modifier.fillMaxSize(),
                    contentPadding      = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(vm.requests, key = { it.id }) { request ->
                        RequestCard(
                            request  = request,
                            onAccept = {
                                vm.acceptRequest(request.id) { success ->
                                    if (success) Toast.makeText(context, "Accepted!", Toast.LENGTH_SHORT).show()
                                    else Toast.makeText(context, "Failed to accept", Toast.LENGTH_SHORT).show()
                                }
                            },
                            onDeny = {
                                vm.denyRequest(request.id) { success ->
                                    if (success) Toast.makeText(context, "Denied", Toast.LENGTH_SHORT).show()
                                }
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun RequestCard(
    request  : ConnectionRequest,
    onAccept : () -> Unit,
    onDeny   : () -> Unit
) {
    Card(
        modifier  = Modifier.fillMaxWidth().animateContentSize(),
        shape     = RoundedCornerShape(16.dp),
        colors    = CardDefaults.cardColors(containerColor = CardWhite),
        elevation = CardDefaults.cardElevation(2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(request.fromName,  color = DarkTextUI, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Text(request.fromBio,   color = SubTextUI,  fontSize = 14.sp)
            Spacer(Modifier.height(16.dp))

            AnimatedVisibility(
                visible = request.isAccepted,
                enter   = fadeIn() + expandVertically(animationSpec = tween(500))
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(SuccessGreen.copy(alpha = 0.1f), RoundedCornerShape(12.dp))
                        .padding(12.dp)
                ) {
                    Text("Connection Secured! ✅", color = SuccessGreen, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Spacer(Modifier.height(8.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            painter        = painterResource(R.drawable.outline_handshake_24),
                            contentDescription = null,
                            tint           = SuccessGreen,
                            modifier       = Modifier.size(16.dp)
                        )
                        Spacer(Modifier.width(8.dp))
                        Text("Email: ${request.contactEmail}", color = DarkTextUI, fontSize = 15.sp)
                    }
                }
            }

            if (!request.isAccepted) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(
                        onClick  = onAccept,
                        modifier = Modifier.weight(1f).height(44.dp),
                        shape    = RoundedCornerShape(10.dp),
                        colors   = ButtonDefaults.buttonColors(containerColor = TealUI)
                    ) {
                        Text("Accept", fontWeight = FontWeight.Bold)
                    }
                    OutlinedButton(
                        onClick  = onDeny,
                        modifier = Modifier.weight(1f).height(44.dp),
                        shape    = RoundedCornerShape(10.dp),
                        colors   = ButtonDefaults.outlinedButtonColors(contentColor = ErrorRedUI),
                        border   = androidx.compose.foundation.BorderStroke(1.dp, ErrorRedUI)
                    ) {
                        Text("Deny", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
