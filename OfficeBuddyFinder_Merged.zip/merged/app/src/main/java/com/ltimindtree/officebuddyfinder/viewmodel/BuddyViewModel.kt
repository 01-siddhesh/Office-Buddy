package com.ltimindtree.officebuddyfinder.viewmodel

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FieldPath
import com.google.firebase.firestore.FirebaseFirestore
import com.ltimindtree.officebuddyfinder.model.Event
import com.ltimindtree.officebuddyfinder.model.User
import com.ltimindtree.officebuddyfinder.repository.FirebaseRepository
import java.util.UUID

class BuddyViewModel : ViewModel() {
    private val repo = FirebaseRepository()

    // ── Users ─────────────────────────────────────────────────────────────────
    fun getAllUsers(onResult: (List<User>) -> Unit) = repo.getAllUsers(onResult)

    fun sendRequest(senderId: String, receiverId: String, onResult: (Boolean) -> Unit) =
        repo.sendBuddyRequest(senderId, receiverId, onResult)

    // ── Events ────────────────────────────────────────────────────────────────
    fun hostEvent(event: Event, onComplete: (Boolean) -> Unit) {
        val docId = if (event.id.isBlank()) UUID.randomUUID().toString() else event.id
        repo.addEvent(
            id          = docId,
            title       = event.title,
            time        = event.time,
            location    = event.location,
            category    = event.category,
            description = event.description,
            imageUrl    = event.imageUrl,
            onResult    = onComplete
        )
    }

    fun getAllEvents(onEventsUpdate: (List<Event>) -> Unit) {
        repo.listenToEvents { rawList ->
            val events = rawList.map { map ->
                Event(
                    id          = map["id"]?.toString() ?: "",
                    title       = map["title"]?.toString() ?: "",
                    time        = map["time"]?.toString() ?: "",
                    location    = map["location"]?.toString() ?: "",
                    category    = map["category"]?.toString() ?: "General",
                    description = map["description"]?.toString() ?: "",
                    imageUrl    = map["imageUrl"]?.toString() ?: "",
                    isJoined    = map["isJoined"] as? Boolean ?: false,
                    attendees   = (map["attendees"] as? List<*>)?.map { it.toString() } ?: emptyList(),
                    creatorId   = map["creatorId"]?.toString() ?: ""
                )
            }
            onEventsUpdate(events)
        }
    }

    // ── Friends ───────────────────────────────────────────────────────────────
    var friendsCount by mutableStateOf(0)

    fun getAcceptedFriendsCount() {
        val currentUserId = FirebaseAuth.getInstance().currentUser?.uid ?: return
        FirebaseFirestore.getInstance().collection("buddyRequests")
            .whereEqualTo("status", "accepted")
            .addSnapshotListener { snapshot, error ->
                if (error != null) { friendsCount = 0; return@addSnapshotListener }
                var count = 0
                snapshot?.documents?.forEach { doc ->
                    val s = doc.getString("senderId")
                    val r = doc.getString("receiverId")
                    if (s == currentUserId || r == currentUserId) count++
                }
                friendsCount = count
            }
    }

    fun getAcceptedFriends(onResult: (List<User>) -> Unit) {
        val currentUserId = FirebaseAuth.getInstance().currentUser?.uid ?: return
        val db = FirebaseFirestore.getInstance()
        db.collection("buddyRequests")
            .whereEqualTo("status", "accepted")
            .addSnapshotListener { snapshot, error ->
                if (error != null) { onResult(emptyList()); return@addSnapshotListener }
                val friendIds = mutableSetOf<String>()
                snapshot?.documents?.forEach { doc ->
                    val s = doc.getString("senderId")
                    val r = doc.getString("receiverId")
                    if (s == currentUserId) r?.let { friendIds.add(it) }
                    else if (r == currentUserId) s?.let { friendIds.add(it) }
                }
                if (friendIds.isEmpty()) { onResult(emptyList()); return@addSnapshotListener }
                db.collection("users")
                    .whereIn(FieldPath.documentId(), friendIds.toList())
                    .get()
                    .addOnSuccessListener { docs ->
                        val users = docs.documents.map { doc ->
                            User(
                                id         = doc.id,
                                name       = doc.getString("name")       ?: "",
                                department = doc.getString("department") ?: "",
                                bio        = doc.getString("bio")        ?: "",
                                hobbies    = doc.getString("hobbies")    ?: "",
                                movies     = doc.getString("movies")     ?: "",
                                hometown   = doc.getString("hometown")   ?: ""
                            )
                        }
                        onResult(users)
                    }
                    .addOnFailureListener { onResult(emptyList()) }
            }
    }
}

    fun joinEvent(eventId: String, onResult: (Boolean) -> Unit) = repo.joinEvent(eventId, onResult)
    fun leaveEvent(eventId: String, onResult: (Boolean) -> Unit) = repo.leaveEvent(eventId, onResult)
