package com.ltimindtree.officebuddyfinder.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.*
import androidx.navigation.navArgument
import com.ltimindtree.officebuddyfinder.ui1.ui1.components.*

@Composable
fun NavGraph(navController: NavHostController) {
    NavHost(navController = navController, startDestination = "splash") {
        composable("splash")    { SplashScreen(navController) }
        composable("login")     { LoginScreen(navController) }
        composable("signup")    { SignupScreen(navController) }
        composable("home")      { HomeScreen(navController) }
        composable("requests")  { RequestsScreen(navController) }
        composable("events")    { MainEventsScreen(navController) }
        composable("travel")    { TravelBuddyNavHost(navController) }
        composable("friends")   { FriendsScreen(navController) }
        composable("friends_list") { FriendsListScreen(navController) }
        composable("prefrences") { PrefrencesScreen(navController) }
        composable(
            route     = "profile/{name}/{department}",
            arguments = listOf(
                navArgument("name")       { type = NavType.StringType },
                navArgument("department") { type = NavType.StringType }
            )
        ) { ProfileScreen(navController) }
        composable("other_profile/{userId}") { backStack ->
            val userId = backStack.arguments?.getString("userId") ?: ""
            OtherUserProfileScreen(navController, userId)
        }
    }
}
