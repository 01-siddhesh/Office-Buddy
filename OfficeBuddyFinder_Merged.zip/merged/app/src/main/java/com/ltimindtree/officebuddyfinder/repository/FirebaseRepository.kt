package com.ltimindtree.officebuddyfinder.repository

import android.util.Log
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.SetOptions
import com.ltimindtree.officebuddyfinder.model.ConnectionRequest
import com.ltimindtree.officebuddyfinder.model.User

class FirebaseRepository {
    private val auth = FirebaseAuth.getInstance()
    private val db   = FirebaseFirestore.getInstance()

    // ── AUTH ─────────────────────────────────────────────────────────────────

    fun signup(
        email: String, password: String, name: String, department: String,
        onResult: (Boolean, String?) -> Unit
    ) {
        if (email.isBlank() || password.isBlank() || name.isBlank() || department.isBlank()) {
            onResult(false, "All fields are required"); return
        }
        auth.createUserWithEmailAndPassword(email.trim(), password).addOnCompleteListener { task ->
            if (task.isSuccessful) {
                val userId = auth.currentUser?.uid
                if (userId != null) saveUser(userId, name.trim(), department.trim(), email.trim())
                onResult(true, null)
            } else {
                onResult(false, task.exception?.message)
            }
        }
    }

    fun login(email: String, password: String, onResult: (Boolean, String?) -> Unit) {
        if (email.isBlank() || password.isBlank()) {
            onResult(false, "Email and password are required"); return
        }
        auth.signInWithEmailAndPassword(email.trim(), password).addOnCompleteListener { task ->
            if (task.isSuccessful) onResult(true, null)
            else onResult(false, task.exception?.message)
        }
    }

    // ── USERS ─────────────────────────────────────────────────────────────────

    fun saveUser(userId: String, name: String, department: String, email: String) {
        val user = hashMapOf(
            "id" to userId, "name" to name, "department" to department, "email" to email,
            "bio" to "", "hobbies" to "", "movies" to "", "hometown" to "", "friendsCount" to 0L
        )
        db.collection("users").document(userId).set(user)
            .addOnSuccessListener { Log.d("FirebaseRepo", "User saved") }
            .addOnFailureListener { e -> Log.w("FirebaseRepo", "saveUser failed", e) }
    }

    fun getAllUsers(onResult: (List<User>) -> Unit) {
        db.collection("users").get().addOnSuccessListener { result ->
            val list = result.documents.map { doc ->
                User(
                    id = doc.id,
                    name = doc.getString("name") ?: "",
                    department = doc.getString("department") ?: "",
                    bio = doc.getString("bio") ?: "",
                    hobbies = doc.getString("hobbies") ?: "",
                    movies = doc.getString("movies") ?: "",
                    hometown = doc.getString("hometown") ?: ""
                )
            }
            onResult(list)
        }.addOnFailureListener { e ->
            Log.e("FirebaseRepo", "getAllUsers failed: ${e.message}"); onResult(emptyList())
        }
    }

    fun getCurrentUserDetails(onResult: (Map<String, Any>?) -> Unit) {
        val userId = auth.currentUser?.uid
        if (userId != null) getUserDetails(userId, onResult) else onResult(null)
    }

    fun getUserDetails(userId: String, onResult: (Map<String, Any>?) -> Unit) {
        db.collection("users").document(userId).get()
            .addOnSuccessListener { doc -> onResult(doc.data) }
            .addOnFailureListener { onResult(null) }
    }

    fun updateFullUserProfile(data: Map<String, Any>, onResult: (Boolean) -> Unit) {
        val userId = auth.currentUser?.uid ?: return onResult(false)
        db.collection("users").document(userId)
            .set(data, SetOptions.merge())
            .addOnSuccessListener { onResult(true) }
            .addOnFailureListener { onResult(false) }
    }

    // ── BUDDY REQUESTS ────────────────────────────────────────────────────────

    fun sendBuddyRequest(senderId: String, receiverId: String, onResult: (Boolean) -> Unit) {
        if (senderId.isBlank() || receiverId.isBlank() || senderId == receiverId) {
            onResult(false); return
        }
        // Prevent duplicate pending requests
        db.collection("buddyRequests")
            .whereEqualTo("senderId", senderId)
            .whereEqualTo("receiverId", receiverId)
            .whereEqualTo("status", "pending")
            .get()
            .addOnSuccessListener { existing ->
                if (!existing.isEmpty) { Log.d("FirebaseRepo", "Already pending"); onResult(false); return@addOnSuccessListener }
                val request = hashMapOf(
                    "senderId" to senderId, "receiverId" to receiverId,
                    "status" to "pending", "createdAt" to FieldValue.serverTimestamp()
                )
                db.collection("buddyRequests").add(request)
                    .addOnSuccessListener { onResult(true) }
                    .addOnFailureListener { e -> Log.e("FirebaseRepo", "sendBuddyRequest: ${e.message}"); onResult(false) }
            }
            .addOnFailureListener { e -> Log.e("FirebaseRepo", "Dup check failed: ${e.message}"); onResult(false) }
    }

    fun getPendingRequests(userId: String, onResult: (List<ConnectionRequest>) -> Unit) {
        db.collection("buddyRequests")
            .whereEqualTo("receiverId", userId)
            .whereEqualTo("status", "pending")
            .get()
            .addOnSuccessListener { result ->
                if (result.isEmpty) { onResult(emptyList()); return@addOnSuccessListener }
                val requestList = mutableListOf<ConnectionRequest>()
                var count = 0
                for (document in result) {
                    val senderId = document.getString("senderId") ?: ""
                    val requestId = document.id
                    db.collection("users").document(senderId).get()
                        .addOnSuccessListener { userDoc ->
                            requestList.add(ConnectionRequest(requestId,
                                userDoc.getString("name") ?: "Unknown",
                                userDoc.getString("department") ?: "",
                                userDoc.getString("email") ?: ""))
                            count++
                            if (count == result.size()) onResult(requestList)
                        }
                        .addOnFailureListener { count++; if (count == result.size()) onResult(requestList) }
                }
            }
            .addOnFailureListener { e -> Log.e("FirebaseRepo", "getPendingRequests: ${e.message}"); onResult(emptyList()) }
    }

    fun updateRequestStatus(requestId: String, status: String, onResult: (Boolean) -> Unit) {
        val ref = db.collection("buddyRequests").document(requestId)
        ref.get().addOnSuccessListener { requestDoc ->
            val senderId   = requestDoc.getString("senderId")   ?: ""
            val receiverId = requestDoc.getString("receiverId") ?: ""
            ref.update(mapOf("status" to status, "updatedAt" to FieldValue.serverTimestamp()))
                .addOnSuccessListener {
                    if (status == "accepted" && senderId.isNotBlank() && receiverId.isNotBlank()) {
                        incrementFriendsCount(senderId)
                        incrementFriendsCount(receiverId)
                    }
                    onResult(true)
                }
                .addOnFailureListener { e -> Log.e("FirebaseRepo", "updateRequestStatus: ${e.message}"); onResult(false) }
        }.addOnFailureListener { e -> Log.e("FirebaseRepo", "fetch request doc: ${e.message}"); onResult(false) }
    }

    private fun incrementFriendsCount(userId: String) {
        val ref = db.collection("users").document(userId)
        db.runTransaction { tx ->
            val snap  = tx.get(ref)
            val count = (snap.getLong("friendsCount") ?: 0L) + 1L
            tx.update(ref, "friendsCount", count)
        }.addOnFailureListener { e -> Log.e("FirebaseRepo", "friendsCount increment for $userId: ${e.message}") }
    }

    // ── EVENTS ────────────────────────────────────────────────────────────────

    fun addEvent(
        id: String, title: String, time: String, location: String,
        category: String, description: String, imageUrl: String, onResult: (Boolean) -> Unit
    ) {
        val creatorId = auth.currentUser?.uid ?: return onResult(false)
        val event = hashMapOf(
            "id" to id, "title" to title, "time" to time, "location" to location,
            "category" to category, "description" to description, "imageUrl" to imageUrl,
            "isJoined" to false, "attendees" to listOf<String>(), "creatorId" to creatorId,
            "createdAt" to FieldValue.serverTimestamp()
        )
        db.collection("events").document(id).set(event)
            .addOnSuccessListener { onResult(true) }
            .addOnFailureListener { e -> Log.e("FirebaseRepo", "addEvent: ${e.message}"); onResult(false) }
    }

    fun listenToEvents(onUpdate: (List<Map<String, Any?>>) -> Unit): com.google.firebase.firestore.ListenerRegistration {
        return db.collection("events")
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .addSnapshotListener { snapshot, error ->
                if (error != null) { Log.e("FirebaseRepo", "listenToEvents: ${error.message}"); return@addSnapshotListener }
                val list = snapshot?.documents?.map { doc ->
                    val data = doc.data?.toMutableMap() ?: mutableMapOf()
                    data["id"] = doc.id
                    data as Map<String, Any?>
                } ?: emptyList()
                onUpdate(list)
            }
    }

    // ── TRIPS ─────────────────────────────────────────────────────────────────

    fun addTrip(
        creatorName: String, from: String, to: String, date: String,
        transport: String, seats: Int, description: String, onResult: (Boolean) -> Unit
    ) {
        val userId = auth.currentUser?.uid ?: return onResult(false)
        val trip = hashMapOf(
            "creatorId" to userId, "creatorName" to creatorName, "from" to from, "to" to to,
            "date" to date, "transport" to transport, "seats" to seats,
            "description" to description, "memberIds" to listOf(userId),
            "createdAt" to FieldValue.serverTimestamp()
        )
        db.collection("trips").add(trip)
            .addOnSuccessListener { onResult(true) }
            .addOnFailureListener { e -> Log.e("FirebaseRepo", "addTrip: ${e.message}"); onResult(false) }
    }

    fun listenToTrips(onUpdate: (List<Map<String, Any?>>) -> Unit): com.google.firebase.firestore.ListenerRegistration {
        return db.collection("trips")
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .addSnapshotListener { snapshot, error ->
                if (error != null) { Log.e("FirebaseRepo", "listenToTrips: ${error.message}"); return@addSnapshotListener }
                val list = snapshot?.documents?.map { doc ->
                    val data = doc.data?.toMutableMap() ?: mutableMapOf()
                    data["id"] = doc.id
                    data as Map<String, Any?>
                } ?: emptyList()
                onUpdate(list)
            }
    }

    fun joinTrip(tripId: String, onResult: (Boolean) -> Unit) {
        val userId = auth.currentUser?.uid ?: return onResult(false)
        val ref    = db.collection("trips").document(tripId)
        db.runTransaction { tx ->
            val snap    = tx.get(ref)
            val seats   = (snap.getLong("seats") ?: 0L).toInt()
            val members = snap.get("memberIds") as? List<*> ?: emptyList<String>()
            if (seats <= 0)               throw Exception("No seats left")
            if (members.contains(userId)) throw Exception("Already joined")
            tx.update(ref, mapOf("seats" to seats - 1, "memberIds" to members + userId))
        }
            .addOnSuccessListener { onResult(true) }
            .addOnFailureListener { e -> Log.e("FirebaseRepo", "joinTrip: ${e.message}"); onResult(false) }
    }
}

    // ── JOIN EVENT ────────────────────────────────────────────────────────────
    fun joinEvent(eventId: String, onResult: (Boolean) -> Unit) {
        val userId = auth.currentUser?.uid ?: return onResult(false)
        val ref    = db.collection("events").document(eventId)
        db.runTransaction { tx ->
            val snap    = tx.get(ref)
            val members = snap.get("attendees") as? List<*> ?: emptyList<String>()
            if (members.contains(userId)) throw Exception("Already joined")
            tx.update(ref, "attendees", members + userId)
        }
            .addOnSuccessListener { onResult(true) }
            .addOnFailureListener { e -> Log.e("FirebaseRepo", "joinEvent: ${e.message}"); onResult(false) }
    }

    fun leaveEvent(eventId: String, onResult: (Boolean) -> Unit) {
        val userId = auth.currentUser?.uid ?: return onResult(false)
        val ref    = db.collection("events").document(eventId)
        db.runTransaction { tx ->
            val snap    = tx.get(ref)
            val members = (snap.get("attendees") as? List<*>)?.map { it.toString() } ?: emptyList()
            if (!members.contains(userId)) throw Exception("Not joined")
            tx.update(ref, "attendees", members - userId)
        }
            .addOnSuccessListener { onResult(true) }
            .addOnFailureListener { e -> Log.e("FirebaseRepo", "leaveEvent: ${e.message}"); onResult(false) }
    }
