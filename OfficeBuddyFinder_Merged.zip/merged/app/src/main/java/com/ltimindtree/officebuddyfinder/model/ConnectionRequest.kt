package com.ltimindtree.officebuddyfinder.model

data class ConnectionRequest(
    val id           : String,
    val fromName     : String,
    val fromBio      : String,
    val contactEmail : String,
    var isAccepted   : Boolean = false
)
