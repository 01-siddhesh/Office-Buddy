package com.ltimindtree.officebuddyfinder

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.material3.Surface
import androidx.compose.runtime.remember
import androidx.navigation.compose.rememberNavController
import com.ltimindtree.officebuddyfinder.navigation.NavGraph
import com.ltimindtree.officebuddyfinder.ui.theme.OfficeBuddyFinderTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            OfficeBuddyFinderTheme {
                Surface {
                    val navController = rememberNavController()
                    NavGraph(navController)
                }
            }
        }
    }
}
