package com.ltimindtree.officebuddyfinder.ui1.ui1.components

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import coil.compose.AsyncImage
import com.ltimindtree.officebuddyfinder.model.Event
import com.ltimindtree.officebuddyfinder.viewmodel.BuddyViewModel
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.UUID

val Teal = Color(0xFF1A9E8F)

private val TealLight   = Color(0xFF3BC6B8)
private val TealBg      = Color(0xFFE0F5F3)
private val ScreenBg    = Color(0xFFF5F6F8)
private val CardBg      = Color(0xFFFFFFFF)
private val InputBg     = Color(0xFFF9FAFA)
private val DividerClr  = Color(0xFFE8EEEE)
private val TextPrimary = Color(0xFF111111)
private val TextSecond  = Color(0xFF666666)
private val TextHint    = Color(0xFFAAAAAA)

// Category → image URL mapping (no hardcoded event data)
private fun categoryImageUrl(category: String): String = when (category) {
    "Sports"  -> "https://images.unsplash.com/photo-1574629810360-7efbbe195018?q=80&w=800"
    "Gaming"  -> "https://images.unsplash.com/photo-1542751371-adc38448a05e?q=80&w=800"
    "Cooking" -> "https://images.unsplash.com/photo-1551183053-bf91a1d81141?q=80&w=800"
    "Travel"  -> "https://images.unsplash.com/photo-1533105079780-92b9be482077?q=80&w=800"
    "Music"   -> "https://images.unsplash.com/photo-1511192336575-5a79af67a629?q=80&w=800"
    "Tech"    -> "https://images.unsplash.com/photo-1518770660439-4636190af475?q=80&w=800"
    "Social"  -> "https://images.unsplash.com/photo-1529156069898-49953e39b3ac?q=80&w=800"
    else      -> "https://images.unsplash.com/photo-1501281668745-f7f57925c3b4?q=80&w=800"
}

// ─────────────────────────────────────────────────────────────────────────────
// DATA HOLDER (form only — not stored in model)
// ─────────────────────────────────────────────────────────────────────────────

private data class EventFormData(
    val eventName   : String,
    val hostName    : String,
    val dateMillis  : Long,
    val location    : String,
    val memberCount : String,
    val category    : String
)

// ─────────────────────────────────────────────────────────────────────────────
// ENTRY POINT
// ─────────────────────────────────────────────────────────────────────────────

@Composable
fun MainEventsScreen(
    rootNavController: NavController,
    viewModel: BuddyViewModel = viewModel()
) {
    val context = LocalContext.current

    // Live events from Firestore
    var events by remember { mutableStateOf(listOf<Event>()) }
    var showForm by remember { mutableStateOf(false) }

    // Real-time listener
    LaunchedEffect(Unit) {
        viewModel.getAllEvents { fetched -> events = fetched }
    }

    if (showForm) {
        EventFormScreen(
            onBack = { showForm = false },
            onAdd  = { formData ->
                val formatter = DateTimeFormatter.ofPattern("MMM dd, yyyy")
                val dateStr   = Instant.ofEpochMilli(formData.dateMillis)
                    .atZone(ZoneId.systemDefault()).toLocalDate().format(formatter)

                val newEvent = Event(
                    id          = UUID.randomUUID().toString(),
                    title       = formData.eventName,
                    time        = dateStr,
                    location    = formData.location,
                    category    = formData.category,
                    description = "Hosted by ${formData.hostName}",
                    imageUrl    = categoryImageUrl(formData.category)
                )
                viewModel.hostEvent(newEvent) { success ->
                    if (success) {
                        showForm = false
                        Toast.makeText(context, "Event created!", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(context, "Failed to create event", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        )
    } else {
        EventDiscoveryScreen(
            events           = events,
            onHostEventClick = { showForm = true },
            onBack           = { rootNavController.popBackStack() }
        )
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// EVENT DISCOVERY SCREEN
// ─────────────────────────────────────────────────────────────────────────────

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EventDiscoveryScreen(
    events: List<Event>,
    onHostEventClick: () -> Unit,
    onBack: () -> Unit
) {
    var searchQuery      by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("All") }

    val categories = listOf("All", "Sports", "Gaming", "Cooking", "Travel", "Music", "Tech", "Social")

    Scaffold(
        containerColor = Color(0xFFFAFAFA),
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick        = onHostEventClick,
                containerColor = Teal,
                contentColor   = Color.White,
                shape          = RoundedCornerShape(16.dp),
                icon           = { Icon(Icons.Default.Add, contentDescription = null) },
                text           = { Text("Host Event", fontWeight = FontWeight.Bold) }
            )
        },
        topBar = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color.White)
                    .padding(top = 48.dp, bottom = 16.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier          = Modifier.padding(horizontal = 8.dp)
                ) {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                    Text(
                        "Explore Events",
                        style = MaterialTheme.typography.headlineMedium.copy(
                            fontWeight = FontWeight.ExtraBold,
                            color      = Color(0xFF1A1A1A),
                            letterSpacing = (-1).sp
                        )
                    )
                }
                Spacer(Modifier.height(20.dp))
                Box(Modifier.padding(horizontal = 20.dp)) {
                    EventSearchBar(query = searchQuery, onQueryChange = { searchQuery = it })
                }
                Spacer(Modifier.height(12.dp))
                EventCategoryChips(
                    categories       = categories,
                    selectedCategory = selectedCategory,
                    onCategorySelected = { selectedCategory = it }
                )
            }
        }
    ) { padding ->
        val filtered = events.filter {
            (selectedCategory == "All" || it.category == selectedCategory) &&
            it.title.contains(searchQuery, ignoreCase = true)
        }

        if (filtered.isEmpty()) {
            Box(
                modifier         = Modifier.fillMaxSize().padding(padding),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    if (events.isEmpty()) "No events yet.\nTap 'Host Event' to create one!"
                    else "No events match your search.",
                    color     = Color.Gray,
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                )
            }
        } else {
            LazyColumn(
                modifier       = Modifier.fillMaxSize().padding(padding),
                contentPadding = PaddingValues(20.dp),
                verticalArrangement = Arrangement.spacedBy(24.dp)
            ) {
                items(filtered, key = { it.id }) { event ->
                    EventCard(event = event)
                }
            }
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// EVENT FORM SCREEN
// ─────────────────────────────────────────────────────────────────────────────

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EventFormScreen(
    onBack : () -> Unit = {},
    onAdd  : (EventFormData) -> Unit = {}
) {
    val context = LocalContext.current

    var eventName   by remember { mutableStateOf("") }
    var hostName    by remember { mutableStateOf("") }
    var location    by remember { mutableStateOf("") }
    var memberCount by remember { mutableStateOf("") }
    var locExpanded by remember { mutableStateOf(false) }
    var showDatePicker by remember { mutableStateOf(false) }

    val categories       = listOf("Sports", "Gaming", "Tech", "Music", "Social", "Cooking", "Travel")
    var selectedCategory by remember { mutableStateOf("Tech") }

    // Validation errors
    var eventNameErr  by remember { mutableStateOf("") }
    var hostNameErr   by remember { mutableStateOf("") }
    var dateErr       by remember { mutableStateOf("") }
    var locationErr   by remember { mutableStateOf("") }
    var memberCountErr by remember { mutableStateOf("") }

    val datePickerState = rememberDatePickerState()
    val selectedDate = datePickerState.selectedDateMillis?.let {
        Instant.ofEpochMilli(it).atZone(ZoneId.systemDefault()).toLocalDate()
            .format(DateTimeFormatter.ofPattern("MMM dd, yyyy"))
    } ?: ""

    val locationOptions = listOf(
        "Auditorium A", "Town Hall", "Conference Room 3",
        "Rooftop Garden", "Main Cafeteria", "Virtual – Google Meet",
        "Exhibition Hall", "Open Amphitheatre"
    )

    fun validate(): Boolean {
        var ok = true
        eventNameErr = when {
            eventName.isBlank()         -> { ok = false; "Event name is required" }
            eventName.trim().length < 3 -> { ok = false; "Minimum 3 characters" }
            else -> ""
        }
        hostNameErr = when {
            hostName.isBlank()         -> { ok = false; "Host name is required" }
            hostName.trim().length < 2 -> { ok = false; "Minimum 2 characters" }
            else -> ""
        }
        dateErr = if (datePickerState.selectedDateMillis == null) { ok = false; "Please pick a date" } else ""
        locationErr = if (location.isBlank()) { ok = false; "Location is required" } else ""
        val mc = memberCount.toIntOrNull()
        memberCountErr = when {
            memberCount.isBlank() -> { ok = false; "Required" }
            mc == null            -> { ok = false; "Must be a number" }
            mc < 1                -> { ok = false; "At least 1" }
            mc > 500              -> { ok = false; "Max 500" }
            else -> ""
        }
        return ok
    }

    Box(modifier = Modifier.fillMaxSize().background(ScreenBg)) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
                .padding(top = 44.dp, bottom = 36.dp),
            verticalArrangement     = Arrangement.spacedBy(16.dp),
            horizontalAlignment     = Alignment.CenterHorizontally
        ) {
            // Top bar
            Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                IconButton(
                    onClick  = onBack,
                    modifier = Modifier.background(CardBg, CircleShape).border(1.dp, DividerClr, CircleShape)
                ) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, null, tint = Teal)
                }
                Spacer(Modifier.width(16.dp))
                Text("Create Event", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
            }

            // Header banner
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .background(Brush.horizontalGradient(listOf(Teal, TealLight)))
                    .padding(20.dp)
            ) {
                Column {
                    Text("New Event", color = Color.White.copy(alpha = 0.8f), fontSize = 12.sp)
                    Text("Host a new gathering", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                }
            }

            // Category chips
            Text("Select Category", modifier = Modifier.fillMaxWidth(),
                style = MaterialTheme.typography.labelLarge, color = TextSecond)
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(categories) { cat ->
                    FilterChip(
                        selected = selectedCategory == cat,
                        onClick  = { selectedCategory = cat },
                        label    = { Text(cat) },
                        colors   = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = Teal,
                            selectedLabelColor     = Color.White
                        )
                    )
                }
            }

            // Form card
            Card(
                modifier  = Modifier.fillMaxWidth(),
                shape     = RoundedCornerShape(20.dp),
                colors    = CardDefaults.cardColors(containerColor = CardBg),
                elevation = CardDefaults.cardElevation(2.dp)
            ) {
                Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {

                    // Event Name
                    EFormField(value = eventName, onValueChange = { eventName = it; eventNameErr = "" },
                        label = "Event Name", placeholder = "e.g. Annual Tech Meetup",
                        icon = Icons.Default.Star, error = eventNameErr)
                    HorizontalDivider(color = DividerClr)

                    // Host Name
                    EFormField(value = hostName, onValueChange = { hostName = it; hostNameErr = "" },
                        label = "Host Name", placeholder = "e.g. Sarah Chen",
                        icon = Icons.Default.Person, error = hostNameErr)
                    HorizontalDivider(color = DividerClr)

                    // Date
                    EDateField(dateText = selectedDate, error = dateErr, onPickDate = { showDatePicker = true })
                    HorizontalDivider(color = DividerClr)

                    // Location dropdown
                    ELocationDropdown(
                        value          = location,
                        onValueChange  = { location = it; locationErr = "" },
                        expanded       = locExpanded,
                        onExpandChange = { locExpanded = it },
                        options        = locationOptions.filter { it.contains(location, true) },
                        onSelect       = { location = it; locExpanded = false },
                        error          = locationErr
                    )
                    HorizontalDivider(color = DividerClr)

                    // Max Attendees
                    EFormField(
                        value          = memberCount,
                        onValueChange  = { memberCount = it; memberCountErr = "" },
                        label          = "Max Attendees",
                        placeholder    = "e.g. 50",
                        icon           = Icons.Default.Person,
                        error          = memberCountErr,
                        keyboardType   = KeyboardType.Number
                    )
                }
            }

            Button(
                onClick = {
                    if (validate()) {
                        onAdd(EventFormData(
                            eventName   = eventName.trim(),
                            hostName    = hostName.trim(),
                            dateMillis  = datePickerState.selectedDateMillis!!,
                            location    = location,
                            memberCount = memberCount,
                            category    = selectedCategory
                        ))
                    }
                },
                modifier = Modifier.fillMaxWidth().height(56.dp),
                shape    = RoundedCornerShape(16.dp),
                colors   = ButtonDefaults.buttonColors(containerColor = Teal)
            ) {
                Text("Create Event", fontWeight = FontWeight.Bold)
            }
        }
    }

    if (showDatePicker) {
        DatePickerDialog(
            onDismissRequest = { showDatePicker = false },
            confirmButton    = {
                TextButton(onClick = { showDatePicker = false; dateErr = "" }) {
                    Text("OK", color = Teal)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDatePicker = false }) { Text("Cancel") }
            }
        ) {
            DatePicker(state = datePickerState)
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// FORM COMPONENTS
// ─────────────────────────────────────────────────────────────────────────────

@Composable
private fun EFormField(
    value: String, onValueChange: (String) -> Unit,
    label: String, placeholder: String, icon: ImageVector,
    error: String = "", keyboardType: KeyboardType = KeyboardType.Text
) {
    Row(verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Box(modifier = Modifier.size(40.dp).background(TealBg, RoundedCornerShape(12.dp)).padding(top = 8.dp),
            contentAlignment = Alignment.TopCenter) {
            Icon(icon, null, tint = Teal, modifier = Modifier.size(20.dp))
        }
        Column(modifier = Modifier.weight(1f)) {
            Text(label, fontSize = 11.sp, color = TextSecond, fontWeight = FontWeight.SemiBold)
            OutlinedTextField(
                value          = value,
                onValueChange  = onValueChange,
                placeholder    = { Text(placeholder, color = TextHint, fontSize = 14.sp) },
                isError        = error.isNotEmpty(),
                supportingText = if (error.isNotEmpty()) {{ Text(error, color = MaterialTheme.colorScheme.error, fontSize = 11.sp) }} else null,
                modifier       = Modifier.fillMaxWidth(),
                shape          = RoundedCornerShape(12.dp),
                keyboardOptions = KeyboardOptions(keyboardType = keyboardType),
                colors         = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor   = Teal,
                    unfocusedBorderColor = DividerClr,
                    errorBorderColor     = MaterialTheme.colorScheme.error
                )
            )
        }
    }
}

@Composable
private fun EDateField(dateText: String, error: String, onPickDate: () -> Unit) {
    Row(verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Box(modifier = Modifier.size(40.dp).background(TealBg, RoundedCornerShape(12.dp)).padding(top = 8.dp),
            contentAlignment = Alignment.TopCenter) {
            Icon(Icons.Default.DateRange, null, tint = Teal, modifier = Modifier.size(20.dp))
        }
        Column(modifier = Modifier.weight(1f)) {
            Text("Date", fontSize = 11.sp, color = TextSecond, fontWeight = FontWeight.SemiBold)
            Box(
                modifier = Modifier
                    .fillMaxWidth().height(56.dp)
                    .border(1.dp, if (error.isNotEmpty()) MaterialTheme.colorScheme.error else DividerClr, RoundedCornerShape(12.dp))
                    .background(InputBg, RoundedCornerShape(12.dp))
                    .clickable { onPickDate() }
                    .padding(horizontal = 16.dp),
                contentAlignment = Alignment.CenterStart
            ) {
                Text(
                    text  = if (dateText.isEmpty()) "Pick a date" else dateText,
                    color = if (dateText.isEmpty()) TextHint else TextPrimary
                )
            }
            if (error.isNotEmpty()) {
                Text(error, color = MaterialTheme.colorScheme.error, fontSize = 11.sp,
                    modifier = Modifier.padding(start = 4.dp, top = 4.dp))
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ELocationDropdown(
    value: String, onValueChange: (String) -> Unit,
    expanded: Boolean, onExpandChange: (Boolean) -> Unit,
    options: List<String>, onSelect: (String) -> Unit, error: String
) {
    Row(verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Box(modifier = Modifier.size(40.dp).background(TealBg, RoundedCornerShape(12.dp)).padding(top = 8.dp),
            contentAlignment = Alignment.TopCenter) {
            Icon(Icons.Default.LocationOn, null, tint = Teal, modifier = Modifier.size(20.dp))
        }
        Column(modifier = Modifier.weight(1f)) {
            Text("Location", fontSize = 11.sp, color = TextSecond, fontWeight = FontWeight.SemiBold)
            ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = onExpandChange) {
                OutlinedTextField(
                    value          = value,
                    onValueChange  = onValueChange,
                    placeholder    = { Text("Where?", color = TextHint, fontSize = 14.sp) },
                    isError        = error.isNotEmpty(),
                    supportingText = if (error.isNotEmpty()) {{ Text(error, color = MaterialTheme.colorScheme.error, fontSize = 11.sp) }} else null,
                    modifier       = Modifier.menuAnchor(MenuAnchorType.PrimaryNotEditable).fillMaxWidth(),
                    shape          = RoundedCornerShape(12.dp),
                    colors         = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor   = Teal,
                        unfocusedBorderColor = DividerClr
                    )
                )
                if (options.isNotEmpty()) {
                    ExposedDropdownMenu(expanded = expanded, onDismissRequest = { onExpandChange(false) }) {
                        options.forEach { opt ->
                            DropdownMenuItem(text = { Text(opt) }, onClick = { onSelect(opt) })
                        }
                    }
                }
            }
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// SEARCH + CHIPS
// ─────────────────────────────────────────────────────────────────────────────

@Composable
fun EventSearchBar(query: String, onQueryChange: (String) -> Unit) {
    TextField(
        value         = query,
        onValueChange = onQueryChange,
        modifier      = Modifier.fillMaxWidth().height(56.dp)
            .border(1.dp, Color(0xFFEEEEEE), RoundedCornerShape(16.dp)),
        placeholder   = { Text("Search events...", color = Color(0xFF9E9E9E), fontSize = 14.sp) },
        leadingIcon   = { Icon(Icons.Default.Search, null, tint = Color.Black, modifier = Modifier.size(20.dp)) },
        colors        = TextFieldDefaults.colors(
            focusedContainerColor   = Color(0xFFF5F5F5),
            unfocusedContainerColor = Color(0xFFF5F5F5),
            focusedIndicatorColor   = Color.Transparent,
            unfocusedIndicatorColor = Color.Transparent,
            cursorColor             = Teal
        ),
        shape     = RoundedCornerShape(16.dp),
        singleLine = true
    )
}

@Composable
fun EventCategoryChips(
    categories: List<String>, selectedCategory: String, onCategorySelected: (String) -> Unit
) {
    LazyRow(
        contentPadding      = PaddingValues(horizontal = 20.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        items(categories) { category ->
            val isSelected = category == selectedCategory
            FilterChip(
                selected = isSelected,
                onClick  = { onCategorySelected(category) },
                label    = {
                    Text(category,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                        fontSize   = 13.sp)
                },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = Teal, selectedLabelColor = Color.White,
                    containerColor = Color.White, labelColor = Color(0xFF757575)
                ),
                border = FilterChipDefaults.filterChipBorder(
                    enabled = true, selected = isSelected,
                    borderColor = if (isSelected) Teal else Color(0xFFEEEEEE), borderWidth = 1.dp
                ),
                shape = RoundedCornerShape(12.dp)
            )
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// EVENT CARD
// ─────────────────────────────────────────────────────────────────────────────

@Composable
fun EventCard(event: Event, viewModel: BuddyViewModel = androidx.lifecycle.viewmodel.compose.viewModel()) {
    val currentUserId = com.google.firebase.auth.FirebaseAuth.getInstance().currentUser?.uid ?: ""
    var isJoined      by remember(event.id, currentUserId) {
        mutableStateOf(event.attendees.contains(currentUserId))
    }
    var attendeeCount by remember(event.id) { mutableIntStateOf(event.attendees.size) }

    Card(
        modifier  = Modifier.fillMaxWidth(),
        shape     = RoundedCornerShape(28.dp),
        colors    = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(0.dp)
    ) {
        Column(modifier = Modifier.border(1.dp, Color(0xFFF0F0F0), RoundedCornerShape(28.dp))) {
            Box(
                modifier = Modifier
                    .fillMaxWidth().height(200.dp)
                    .clip(RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp))
                    .background(Color(0xFFEEEEEE)),
                contentAlignment = Alignment.Center
            ) {
                AsyncImage(
                    model              = event.imageUrl,
                    contentDescription = null,
                    modifier           = Modifier.fillMaxSize(),
                    contentScale       = ContentScale.Crop
                )
                Surface(
                    modifier = Modifier.align(Alignment.TopStart).padding(16.dp),
                    shape    = RoundedCornerShape(12.dp),
                    color    = Color.White.copy(alpha = 0.9f)
                ) {
                    Text(event.category,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                        style    = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold))
                }
            }

            Column(modifier = Modifier.padding(20.dp)) {
                Text(event.title,
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontWeight = FontWeight.Bold, color = Color(0xFF1A1A1A), lineHeight = 28.sp))
                Spacer(Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.LocationOn, null, Modifier.size(16.dp), tint = Color(0xFF757575))
                    Spacer(Modifier.width(6.dp))
                    Text(event.location, style = MaterialTheme.typography.bodyMedium, color = Color(0xFF757575))
                    Spacer(Modifier.width(12.dp))
                    Box(Modifier.size(4.dp).background(Color(0xFFBDBDBD), CircleShape))
                    Spacer(Modifier.width(12.dp))
                    Text(event.time, style = MaterialTheme.typography.bodyMedium, color = Color(0xFF757575))
                }
                if (event.description.isNotBlank()) {
                    Spacer(Modifier.height(6.dp))
                    Text(event.description,
                        style = MaterialTheme.typography.bodySmall, color = Color(0xFF888888), maxLines = 2)
                }
                Spacer(Modifier.height(24.dp))
                Row(
                    modifier              = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment     = Alignment.CenterVertically
                ) {
                    Text("$attendeeCount Attending",
                        style = MaterialTheme.typography.bodySmall.copy(
                            fontWeight = FontWeight.Medium, color = Color(0xFF757575)))
                    Button(
                        onClick = {
                            if (!isJoined) {
                                viewModel.joinEvent(event.id) { success ->
                                    if (success) { isJoined = true; attendeeCount++ }
                                }
                            } else {
                                viewModel.leaveEvent(event.id) { success ->
                                    if (success) { isJoined = false; attendeeCount-- }
                                }
                            }
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isJoined) Color(0xFFF5F5F5) else Teal,
                            contentColor   = if (isJoined) Teal else Color.White
                        ),
                        shape          = RoundedCornerShape(14.dp),
                        contentPadding = PaddingValues(horizontal = 24.dp, vertical = 12.dp)
                    ) {
                        Text(if (isJoined) "Going ✓" else "Join", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }
                }
            }
        }
    }
}
