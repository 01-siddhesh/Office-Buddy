package com.ltimindtree.officebuddyfinder.ui1.ui1.components

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.google.firebase.auth.FirebaseAuth
import com.ltimindtree.officebuddyfinder.repository.FirebaseRepository
import com.ltimindtree.officebuddyfinder.viewmodel.BuddyViewModel

@Composable
fun OtherUserProfileScreen(navController: NavController, userId: String) {
    val repository    = remember { FirebaseRepository() }
    val buddyViewModel: BuddyViewModel = viewModel()
    val context       = LocalContext.current
    val currentUserId = FirebaseAuth.getInstance().currentUser?.uid ?: ""

    var name         by remember { mutableStateOf("Loading...") }
    var job          by remember { mutableStateOf("...") }
    var bio          by remember { mutableStateOf("") }
    var hobbies      by remember { mutableStateOf("") }
    var movies       by remember { mutableStateOf("") }
    var hometown     by remember { mutableStateOf("") }
    var friendsCount by remember { mutableStateOf(0L) }
    var requestSent  by remember { mutableStateOf(false) }

    LaunchedEffect(userId) {
        repository.getUserDetails(userId) { data ->
            if (data != null) {
                name         = data["name"]?.toString() ?: "Unknown"
                job          = data["department"]?.toString() ?: "No Department"
                bio          = data["bio"]?.toString() ?: "No bio available"
                hobbies      = data["hobbies"]?.toString() ?: "None listed"
                movies       = data["movies"]?.toString() ?: "None listed"
                hometown     = data["hometown"]?.toString() ?: "Not specified"
                friendsCount = (data["friendsCount"] as? Long) ?: 0L
            }
        }
    }

    Scaffold(
        topBar = {
            Surface(tonalElevation = 3.dp) {
                Row(
                    modifier          = Modifier.statusBarsPadding().padding(8.dp).fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                    Text("Buddy Profile", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    ) { innerPadding ->
        LazyColumn(
            modifier            = Modifier.padding(innerPadding).fillMaxSize(),
            contentPadding      = PaddingValues(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            item {
                // Avatar
                Box(modifier = Modifier.padding(bottom = 8.dp)) {
                    Box(
                        modifier         = Modifier.size(120.dp).clip(CircleShape).background(Color.LightGray),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.AccountCircle, null, Modifier.size(90.dp), tint = Color.Gray)
                    }
                }

                // Friends count badge
                Surface(
                    shape    = RoundedCornerShape(20.dp),
                    color    = Teal.copy(alpha = 0.12f),
                    modifier = Modifier.padding(bottom = 16.dp)
                ) {
                    Row(
                        modifier          = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Person, null, tint = Teal, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text(
                            "$friendsCount ${if (friendsCount == 1L) "Friend" else "Friends"}",
                            color      = Teal,
                            fontSize   = 13.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }

                Text(name, fontSize = 26.sp, fontWeight = FontWeight.Bold)
                Text(job, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(bottom = 24.dp))

                DetailItem("Bio",        bio)
                DetailItem("Department", job)
                DetailItem("Hobbies",    hobbies)
                DetailItem("Movies",     movies)
                DetailItem("Hometown",   hometown)

                Spacer(Modifier.size(32.dp))

                // Send Buddy Request button
                if (currentUserId != userId) {
                    Button(
                        onClick = {
                            buddyViewModel.sendRequest(currentUserId, userId) { success ->
                                if (success) {
                                    requestSent = true
                                    Toast.makeText(context, "Request sent!", Toast.LENGTH_SHORT).show()
                                } else {
                                    Toast.makeText(context, "Already sent or failed", Toast.LENGTH_SHORT).show()
                                }
                            }
                        },
                        enabled  = !requestSent,
                        modifier = Modifier.fillMaxWidth().height(50.dp),
                        shape    = RoundedCornerShape(12.dp),
                        colors   = ButtonDefaults.buttonColors(
                            containerColor         = Teal,
                            disabledContainerColor = Color(0xFFBDBDBD)
                        )
                    ) {
                        Text(
                            if (requestSent) "Request Sent ✓" else "Send Buddy Request",
                            fontWeight = FontWeight.Bold,
                            color      = Color.White
                        )
                    }
                }
            }
        }
    }
}
