package com.ltimindtree.officebuddyfinder.ui1.ui1.components

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.tooling.data.JoinedKey
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import coil.compose.AsyncImage
import com.ltimindtree.officebuddyfinder.viewmodel.BuddyViewModel
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter

val Teal = Color(0xFF1A9E8F)

// --- PALETTE ---
private val TealLight   = Color(0xFF3BC6B8)
private val TealBg      = Color(0xFFE0F5F3)
private val ScreenBg    = Color(0xFFF5F6F8)
private val CardBg      = Color(0xFFFFFFFF)
private val InputBg     = Color(0xFFF9FAFA)
private val DividerClr  = Color(0xFFE8EEEE)
private val TextPrimary = Color(0xFF111111)
private val TextSecond  = Color(0xFF666666)
private val TextHint    = Color(0xFFAAAAAA)

data class Event(
    val id: String = "",
    val title: String = "",
    val time: String = "",
    val location: String = "",
    val category: String = "General",
    val description: String = "",
    val attendees: List<String> = emptyList(),
    val imageUrl: String = "https://images.unsplash.com/photo-1501281668745-f7f57925c3b4?q=80&w=800", // Comma added here
    val isJoined: Boolean = false
)
data class EventInfo(
    val eventName: String,
    val hostName: String,
    val dateMillis: Long,
    val location: String,
    val memberCount: String
)

val avatarUrls = listOf(
    "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100",
    "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100",
    "https://images.unsplash.com/photo-1527980965255-d3b416303d12?w=100",
    "https://images.unsplash.com/photo-1580489944761-15a19d654956?w=100"
)

@Composable

fun MainEventsScreen(rootNavController: NavController, viewModel: BuddyViewModel = viewModel()) {
    val navController = rememberNavController()

    // 1. Hardcoded list ki jagah mutableState use karein
    var events by remember { mutableStateOf(listOf<Event>()) }

    // 2. Database se real-time data fetch karein
    LaunchedEffect(Unit) {
        viewModel.getAllEvents { fetchedEvents ->
            events = fetchedEvents
        }
    }




    Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
        Box(modifier = Modifier.padding(innerPadding)) {
            NavHost(
                navController = navController,
                startDestination = "discovery"
            ) {
                composable("discovery") {
                    EventDiscoveryScreen(
                        events = events,
                        onHostEventClick = { navController.navigate("host_event") },
                        onBack = { rootNavController.popBackStack() }
                    )
                }
                composable("host_event") {
                    EventFormScreen(
                        onBack = { navController.popBackStack() },
                        // Line 105 ke aas-paas onAdd block ko replace karein
                        onAdd = { newEventInfo ->
                            val formatter = DateTimeFormatter.ofPattern("MMM dd, yyyy")
                            val dateStr = Instant.ofEpochMilli(newEventInfo.dateMillis)
                                .atZone(ZoneId.systemDefault())
                                .toLocalDate()
                                .format(formatter)

                            // Naya event object (ID Firestore auto-generate karega)
                            val newEvent = Event(
                                title = newEventInfo.eventName,
                                time = dateStr,
                                location = newEventInfo.location,
                                category = "General",
                                description = "Hosted by ${newEventInfo.hostName}",
                                attendees = listOf(avatarUrls.random()), // random avatar
                                imageUrl = "https://images.unsplash.com/photo-1501281668745-f7f57925c3b4?q=80&w=800"
                            )

                            // DATABASE MEIN ADD KAREIN (events.add ki jagah ye use karein)
                            viewModel.hostEvent(newEvent) { success ->
                                if (success) {
                                    navController.navigate("discovery") {
                                        popUpTo("discovery") { inclusive = true }
                                    }
                                }
                            }


                        }
                    )
                }
            }
        }
    }
}


@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EventDiscoveryScreen(
    events: List<Event>,
    onHostEventClick: () -> Unit,
    onBack: () -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("All") }

    val categories = listOf("All", "Sports", "Gaming", "Cooking", "Travel", "Music")

    Scaffold(
        containerColor = Color(0xFFFAFAFA),
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = onHostEventClick,
                containerColor = Teal,
                contentColor = Color.White,
                shape = RoundedCornerShape(16.dp),
                icon = { Icon(Icons.Default.Add, contentDescription = null) },
                text = { Text("Host Event", fontWeight = FontWeight.Bold) }
            )
        },
        topBar = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color.White)
                    .padding(top = 48.dp, bottom = 16.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(horizontal = 8.dp)) {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                    Text(
                        text = "Explore Events",
                        style = MaterialTheme.typography.headlineMedium.copy(
                            fontWeight = FontWeight.ExtraBold,
                            color = Color(0xFF1A1A1A),
                            letterSpacing = (-1).sp
                        )
                    )
                }
                
                Spacer(modifier = Modifier.height(20.dp))
                
                Box(modifier = Modifier.padding(horizontal = 20.dp)) {
                    SearchBar(query = searchQuery, onQueryChange = { searchQuery = it })
                }
                
                Spacer(modifier = Modifier.height(12.dp))
                
                CategoryChips(
                    categories = categories,
                    selectedCategory = selectedCategory,
                    onCategorySelected = { selectedCategory = it }
                )
            }
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(20.dp),
            verticalArrangement = Arrangement.spacedBy(24.dp)
        ) {
            val filteredEvents = events.filter { 
                (selectedCategory == "All" || it.category == selectedCategory) &&
                (it.title.contains(searchQuery, ignoreCase = true))
            }

            if (filteredEvents.isEmpty()) {
                item {
                    Box(modifier = Modifier.fillParentMaxSize(), contentAlignment = Alignment.Center) {
                        Text("No events found", color = Color.Gray)
                    }
                }
            } else {
                items(filteredEvents, key = { it.id }) { event ->
                    EventCard(event = event)
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EventFormScreen(
    onBack: () -> Unit = {},
    onAdd: (EventInfo) -> Unit = {}
) {
    val context = LocalContext.current
    var eventName by remember { mutableStateOf("") }
    var hostName by remember { mutableStateOf("") }
    var location by remember { mutableStateOf("") }
    var memberCount by remember { mutableStateOf("") }
    var locExpanded by remember { mutableStateOf(false) }
    var showDatePicker by remember { mutableStateOf(false) }

    val categories = listOf("Sports", "Gaming", "Tech", "Music", "Social")
    var selectedCategory by remember { mutableStateOf("Tech") }

    // Date State Logic
    val datePickerState = rememberDatePickerState()
    val selectedDate = datePickerState.selectedDateMillis?.let {
        Instant.ofEpochMilli(it).atZone(ZoneId.systemDefault()).toLocalDate()
            .format(DateTimeFormatter.ofPattern("MMM dd, yyyy"))
    } ?: ""

    val locationOptions = listOf("Auditorium A", "Town Hall", "Conference Room 3",
        "Rooftop Garden", "Main Cafeteria", "Virtual – Google Meet",
        "Exhibition Hall", "Open Amphitheatre")

    Box(modifier = Modifier.fillMaxSize().background(ScreenBg)) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
                .padding(top = 44.dp, bottom = 36.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            TopBar(onBack = onBack)
            HeaderBanner()

            Text("Select Category", modifier = Modifier.fillMaxWidth(), style = MaterialTheme.typography.labelLarge, color = TextSecond)
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(categories) { cat ->
                    FilterChip(
                        selected = selectedCategory == cat,
                        onClick = { selectedCategory = cat },
                        label = { Text(cat) },
                        colors = FilterChipDefaults.filterChipColors(selectedContainerColor = Teal, selectedLabelColor = Color.White)
                    )
                }
            }

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = CardBg),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                    FormField(
                        value = eventName,
                        onValueChange = { eventName = it },
                        label = "Event Name",
                        placeholder = "e.g. Annual Tech Meetup",
                        icon = Icons.Default.Star 
                    )
                    FieldDivider()
                    FormField(
                        value = hostName,
                        onValueChange = { hostName = it },
                        label = "Host Name",
                        placeholder = "e.g. Sarah Chen",
                        icon = Icons.Default.Person
                    )
                    FieldDivider()
                    DateField(dateText = selectedDate, onPickDate = { showDatePicker = true })
                    FieldDivider()

                    LocationDropdown(
                        value = location,
                        onValueChange = { location = it },
                        expanded = locExpanded,
                        onExpandChange = { locExpanded = it },
                        options = locationOptions.filter { it.contains(location, true) },
                        onSelect = { location = it; locExpanded = false }
                    )

                    FieldDivider()
                    FormField(
                        value = memberCount,
                        onValueChange = { memberCount = it },
                        label = "Max Attendees",
                        placeholder = "e.g. 10",
                        icon = Icons.Default.Person,
                        keyboardType = KeyboardType.Number
                    )
                }
            }

            Button(
                onClick = {
                    if (eventName.isNotBlank() && datePickerState.selectedDateMillis != null) {
                        onAdd(EventInfo(eventName, hostName, datePickerState.selectedDateMillis!!, location, memberCount))
                        Toast.makeText(context, "Event Created", Toast.LENGTH_SHORT).show()
                    }
                },
                modifier = Modifier.fillMaxWidth().height(56.dp),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Teal)
            ) {
                Text("Create Event", fontWeight = FontWeight.Bold)
            }
        }
    }

    if (showDatePicker) {
        DatePickerDialog(
            onDismissRequest = { showDatePicker = false },
            confirmButton = { TextButton(onClick = { showDatePicker = false }) { Text("OK") } }
        ) {
            DatePicker(state = datePickerState)
        }
    }
}

@Composable
fun TopBar(onBack: () -> Unit) {
    Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        IconButton(onClick = onBack, modifier = Modifier.background(CardBg, CircleShape).border(1.dp, DividerClr, CircleShape)) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null, tint = Teal)
        }
        Spacer(Modifier.width(16.dp))
        Text("Create Event", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
    }
}

@Composable
fun HeaderBanner() {
    Box(modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Brush.horizontalGradient(listOf(Teal, TealLight))).padding(20.dp)) {
        Column {
            Text("New Event", color = Color.White.copy(alpha = 0.8f), fontSize = 12.sp)
            Text("Host a new gathering", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun FormField(value: String, onValueChange: (String) -> Unit, label: String, placeholder: String, icon: ImageVector, keyboardType: KeyboardType = KeyboardType.Text) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Box(modifier = Modifier.size(40.dp).background(TealBg, RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) {
            Icon(icon, null, tint = Teal, modifier = Modifier.size(20.dp))
        }
        Column(modifier = Modifier.weight(1f)) {
            Text(label, fontSize = 11.sp, color = TextSecond, fontWeight = FontWeight.SemiBold)
            OutlinedTextField(
                value = value, onValueChange = onValueChange, placeholder = { Text(placeholder, color = TextHint, fontSize = 14.sp) },
                modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp),
                keyboardOptions = KeyboardOptions(keyboardType = keyboardType),
                colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Teal, unfocusedBorderColor = DividerClr)
            )
        }
    }
}

@Composable
fun DateField(dateText: String, onPickDate: () -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Box(modifier = Modifier.size(40.dp).background(TealBg, RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) {
            Icon(Icons.Default.DateRange, null, tint = Teal, modifier = Modifier.size(20.dp))
        }
        Column(modifier = Modifier.weight(1f)) {
            Text("Date", fontSize = 11.sp, color = TextSecond, fontWeight = FontWeight.SemiBold)
            Box(modifier = Modifier.fillMaxWidth().height(56.dp).border(1.dp, DividerClr, RoundedCornerShape(12.dp)).background(InputBg, RoundedCornerShape(12.dp)).clickable { onPickDate() }.padding(horizontal = 16.dp), contentAlignment = Alignment.CenterStart) {
                Text(text = if (dateText.isEmpty()) "Pick a date" else dateText, color = if (dateText.isEmpty()) TextHint else TextPrimary)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LocationDropdown(value: String, onValueChange: (String) -> Unit, expanded: Boolean, onExpandChange: (Boolean) -> Unit, options: List<String>, onSelect: (String) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Box(modifier = Modifier.size(40.dp).background(TealBg, RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) {
            Icon(Icons.Default.LocationOn, null, tint = Teal, modifier = Modifier.size(20.dp))
        }
        Column(modifier = Modifier.weight(1f)) {
            Text("Location", fontSize = 11.sp, color = TextSecond, fontWeight = FontWeight.SemiBold)
            ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = onExpandChange) {
                OutlinedTextField(
                    value = value, onValueChange = onValueChange, placeholder = { Text("Where?", color = TextHint, fontSize = 14.sp) },
                    modifier = Modifier.menuAnchor(MenuAnchorType.PrimaryNotEditable).fillMaxWidth(), shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Teal, unfocusedBorderColor = DividerClr)
                )
                ExposedDropdownMenu(expanded = expanded, onDismissRequest = { onExpandChange(false) }) {
                    options.forEach { opt -> DropdownMenuItem(text = { Text(opt) }, onClick = { onSelect(opt) }) }
                }
            }
        }
    }
}

@Composable
fun FieldDivider() { HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp), color = DividerClr) }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SearchBar(query: String, onQueryChange: (String) -> Unit) {
    TextField(
        value = query,
        onValueChange = onQueryChange,
        modifier = Modifier
            .fillMaxWidth()
            .height(56.dp)
            .border(1.dp, Color(0xFFEEEEEE), RoundedCornerShape(16.dp)),
        placeholder = { Text("Search events, hobbies...", color = Color(0xFF9E9E9E), fontSize = 14.sp) },
        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = Color.Black, modifier = Modifier.size(20.dp)) },
        colors = TextFieldDefaults.colors(
            focusedContainerColor = Color(0xFFF5F5F5),
            unfocusedContainerColor = Color(0xFFF5F5F5),
            disabledContainerColor = Color(0xFFF5F5F5),
            focusedIndicatorColor = Color.Transparent,
            unfocusedIndicatorColor = Color.Transparent,
            cursorColor = Teal
        ),
        shape = RoundedCornerShape(16.dp),
        singleLine = true
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CategoryChips(
    categories: List<String>,
    selectedCategory: String,
    onCategorySelected: (String) -> Unit
) {
    LazyRow(
        contentPadding = PaddingValues(horizontal = 20.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        items(categories) { category ->
            val isSelected = category == selectedCategory
            FilterChip(
                selected = isSelected,
                onClick = { onCategorySelected(category) },
                label = { 
                    Text(
                        category, 
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                        fontSize = 13.sp
                    ) 
                },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = Teal,
                    selectedLabelColor = Color.White,
                    containerColor = Color.White,
                    labelColor = Color(0xFF757575)
                ),
                border = FilterChipDefaults.filterChipBorder(
                    enabled = true,
                    selected = isSelected,
                    borderColor = if (isSelected) Teal else Color(0xFFEEEEEE),
                    borderWidth = 1.dp
                ),
                shape = RoundedCornerShape(12.dp)
            )
        }
    }
}

@Composable
fun EventCard(event: Event) {
    var isJoined by remember(event.id) { mutableStateOf(event.isJoined) }
    val initialCount = event.attendees.size
    var attendeeCount by remember(event.id) { mutableIntStateOf(initialCount) }
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { /* TODO: Detail view */ },
        shape = RoundedCornerShape(28.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Column(modifier = Modifier.border(1.dp, Color(0xFFF0F0F0), RoundedCornerShape(28.dp))) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp)
                    .clip(RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp))
                    .background(Color(0xFFEEEEEE)),
                contentAlignment = Alignment.Center
            ) {
                AsyncImage(
                    model = event.imageUrl,
                    contentDescription = null,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
                
                Surface(
                    modifier = Modifier.align(Alignment.TopStart).padding(16.dp),
                    shape = RoundedCornerShape(12.dp),
                    color = Color.White.copy(alpha = 0.9f)
                ) {
                    Text(
                        text = event.category,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                        style = MaterialTheme.typography.labelMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = Color.Black
                        )
                    )
                }
            }

            Column(modifier = Modifier.padding(20.dp)) {
                Text(
                    text = event.title,
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF1A1A1A),
                        lineHeight = 28.sp
                    )
                )
                
                Spacer(modifier = Modifier.height(8.dp))
                
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        Icons.Default.LocationOn,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp),
                        tint = Color(0xFF757575)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = event.location,
                        style = MaterialTheme.typography.bodyMedium,
                        color = Color(0xFF757575)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Box(modifier = Modifier.size(4.dp).background(Color(0xFFBDBDBD), CircleShape))
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = event.time,
                        style = MaterialTheme.typography.bodyMedium,
                        color = Color(0xFF757575)
                    )
                }

                Spacer(modifier = Modifier.height(24.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    AttendanceCount(count = attendeeCount)
                    
                    Button(
                        onClick = {
                            if (!isJoined) attendeeCount++ else attendeeCount--
                            isJoined = !isJoined
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isJoined) Color(0xFFF5F5F5) else Teal,
                            contentColor = if (isJoined) Teal else Color.White
                        ),
                        shape = RoundedCornerShape(14.dp),
                        contentPadding = PaddingValues(horizontal = 24.dp, vertical = 12.dp)
                    ) {
                        Text(
                            text = if (isJoined) "Going" else "Join",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun AttendanceCount(count: Int) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(
            text = "$count Peoples Attending",
            style = MaterialTheme.typography.bodySmall.copy(
                fontWeight = FontWeight.Medium,
                color = Color(0xFF757575)
            )
        )
    }
}
