package com.ltimindtree.officebuddyfinder.ui1.ui1.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import com.ltimindtree.officebuddyfinder.repository.FirebaseRepository


import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController

@Composable
fun ProfileScreen(navController: NavController, initialName: String = "Loading...", initialDepartment: String = "...") {
    val repository = remember { FirebaseRepository() }

    // State to toggle between View and Edit mode
    var isEditing by remember { mutableStateOf(false) }

    // User Data State
    var name by remember { mutableStateOf(initialName) }
    var job by remember { mutableStateOf(initialDepartment) }
    var bio by remember { mutableStateOf("") }
    var hobbies by remember { mutableStateOf("") }
    var movies by remember { mutableStateOf("") }
    var hometown by remember { mutableStateOf("") }

    // Fetch data from Firebase when screen opens
    LaunchedEffect(Unit) {

        repository.getCurrentUserDetails { data ->
            if (data != null) {
                name = data["name"]?.toString() ?: "No Name"
                job = data["department"]?.toString() ?: "No Department"
                bio = data["bio"]?.toString() ?: "Add a bio about yourself!"
                hobbies = data["hobbies"]?.toString() ?: "List your hobbies"
                movies = data["movies"]?.toString() ?: "Favorite movies"
                hometown = data["hometown"]?.toString() ?: "Where are you from?"
            }
        }
    }

    Scaffold(
            topBar = {
            Surface(tonalElevation = 3.dp) {
                Row(
                    modifier = Modifier.statusBarsPadding().padding(8.dp).fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = {
                        if (isEditing) isEditing = false else navController.popBackStack()
                    }) {
                        Icon(if (isEditing) Icons.Default.Close else Icons.Default.ArrowBack, contentDescription = null)
                    }
                    Text(if (isEditing) "User Profile" else "User Profile", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier.padding(innerPadding).fillMaxSize(),
            contentPadding = PaddingValues(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // 1. Profile Picture
            item {
                Box(contentAlignment = Alignment.Center, modifier = Modifier.padding(bottom = 16.dp)) {
                    Box(modifier = Modifier.size(120.dp).clip(CircleShape).background(Color.LightGray), contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.AccountCircle, null, Modifier.size(90.dp), tint = Color.Gray)
                    }
                }
            }

            // 2. Profile Content (Changes based on isEditing)
            item {
                if (isEditing) {
                    EditableField(label = "Name", value = name, onValueChange = { name = it })
                    EditableField(label = "Department", value = job, onValueChange = { job = it })
                    EditableField(label = "Bio", value = bio, onValueChange = { bio = it }, singleLine = false)
                    EditableField(label = "Hobbies", value = hobbies, onValueChange = { hobbies = it })
                    EditableField(label = "Movies", value = movies, onValueChange = { movies = it })
                    EditableField(label = "Hometown", value = hometown, onValueChange = { hometown = it })
                } else {
                    Text(name, fontSize = 26.sp, fontWeight = FontWeight.Bold)
                    Text(job, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(bottom = 24.dp))

                    DetailItem("Bio", bio)
                    DetailItem("Department", job)
                    DetailItem("Hobbies", hobbies)
                    DetailItem("Movies", movies)
                    DetailItem("Hometown", hometown)
                }
            }

            // 3. The Toggle Button at the end
            item {
                Spacer(Modifier.height(32.dp))
                Button(
                    onClick = {
                        if (isEditing) {
                            val updatedData = mapOf(
                                "name" to name,
                                "department" to job,
                                "bio" to bio,
                                "hobbies" to hobbies,
                                "movies" to movies,
                                "hometown" to hometown
                            )
                            repository.updateFullUserProfile(updatedData) { success ->
                                if (success) isEditing = false
                            }
                        } else {
                            isEditing = true
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(if (isEditing) Icons.Default.Check else Icons.Default.Edit, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text(if (isEditing) "Save Profile" else "Edit Profile")
                }
            }
        }
    }
}

@Composable
fun EditableField(label: String, value: String, onValueChange: (String) -> Unit, singleLine: Boolean = true) {
    Column(modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
        Text(label, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
        OutlinedTextField(
            value = value,
            onValueChange = onValueChange,
            modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
            singleLine = singleLine,
            shape = RoundedCornerShape(8.dp)
        )
    }
}

@Composable
fun DetailItem(label: String, value: String) {
    Column(modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
        Text(label, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
        Text(value, fontSize = 16.sp, modifier = Modifier.padding(top = 4.dp))
    }
}

