package com.ltimindtree.officebuddyfinder.repository

import android.util.Log
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.ltimindtree.officebuddyfinder.ui1.ui1.components.ConnectionRequest
import com.ltimindtree.officebuddyfinder.ui1.ui1.components.User

class FirebaseRepository {
    private val auth = FirebaseAuth.getInstance()
    private val db = FirebaseFirestore.getInstance()

    fun signup(
        email: String,
        password: String,
        name: String,
        department: String,
        onResult: (Boolean, String?) -> Unit
    ) {
        auth.createUserWithEmailAndPassword(email, password).addOnCompleteListener { task ->
            if (task.isSuccessful) {
                val userId = auth.currentUser?.uid
                if (userId != null) {
                    saveUser(userId, name, department, email)
                }
                onResult(true, null)
            } else {
                onResult(false, task.exception?.message)
            }
        }
    }

    fun login(
        email: String,
        password: String,
        onResult: (Boolean, String?) -> Unit
    ) {
        auth.signInWithEmailAndPassword(email, password).addOnCompleteListener { task ->
            if (task.isSuccessful) {
                onResult(true, null)
            } else {
                onResult(false, task.exception?.message)
            }
        }
    }

    // FirebaseRepository.kt ke andar is function ko replace karein
    fun saveUser(userId: String, name: String, department: String, email: String) {
        val user = hashMapOf(
            "id" to userId,
            "name" to name,
            "department" to department,
            "email" to email,
            "bio" to "",         // Khali field create karein
            "hobbies" to "",     // Khali field create karein
            "movies" to "",      // Khali field create karein
            "hometown" to ""     // Khali field create karein
        )

        db.collection("users").document(userId).set(user)
            .addOnSuccessListener { Log.d("Firebase", "User Created with all fields") }
            .addOnFailureListener { e -> Log.w("Firebase", "Error creating user", e) }
    }

    fun getAllUsers(onResult: (List<User>) -> Unit) {
        db.collection("users")
            .get()
            .addOnSuccessListener { result ->
                val userlist = mutableListOf<User>()
                for (document in result) {
                    val user = User(
                        id = document.id,
                        name = document.getString("name") ?: "",
                        department = document.getString("department") ?: "",
                        // Naye fields yahan add karein taaki cards mein data dikhe
                        bio = document.getString("bio") ?: "",
                        hobbies = document.getString("hobbies") ?: "",
                        movies = document.getString("movies") ?: "",
                        hometown = document.getString("hometown") ?: ""
                    )
                    userlist.add(user)
                }
                onResult(userlist)
            }
    }


    fun sendBuddyRequest(
        senderId: String,
        receiverId: String,
        onResult: (Boolean) -> Unit
    ) {
        if (senderId.isBlank() || receiverId.isBlank()) {
            onResult(false)
            return
        }
        val request = hashMapOf(
            "senderId" to senderId,
            "receiverId" to receiverId,
            "status" to "pending"
        )
        db.collection("buddyRequests")
            .add(request)
            .addOnSuccessListener { onResult(true) }
            .addOnFailureListener { e ->
                Log.e("FirebaseRepo", "Error sending request: ${e.message}")
                onResult(false)
            }
    }

    fun getPendingRequests(userId: String, onResult: (List<ConnectionRequest>) -> Unit) {
        db.collection("buddyRequests")
            .whereEqualTo("receiverId", userId)
            .whereEqualTo("status", "pending")
            .get()
            .addOnSuccessListener { result ->
                val requestList = mutableListOf<ConnectionRequest>()
                var processedCount = 0

                if (result.isEmpty) {
                    onResult(emptyList())
                    return@addOnSuccessListener
                }

                for (document in result) {
                    val senderId = document.getString("senderId") ?: ""
                    val requestId = document.id

                    db.collection("users").document(senderId).get()
                        .addOnSuccessListener { userDoc ->
                            val name = userDoc.getString("name") ?: "Unknown"
                            val dept = userDoc.getString("department") ?: ""
                            val email = userDoc.getString("email") ?: ""

                            requestList.add(ConnectionRequest(requestId, name, dept, email))

                            processedCount++
                            if (processedCount == result.size()) {
                                onResult(requestList)
                            }
                        }
                        .addOnFailureListener { e ->
                            Log.e("FirebaseRepo", "Error fetching user details: ${e.message}")
                            processedCount++
                            if (processedCount == result.size()) {
                                onResult(requestList)
                            }
                        }
                }
            }
            .addOnFailureListener { e ->
                Log.e("FirebaseRepo", "Error fetching requests: ${e.message}")
                onResult(emptyList())
            }
    }

//    fun updateRequestStatus(requestId: String, status: String, onResult: (Boolean) -> Unit) {
//        Log.d("FirebaseRepo", "Updating request $requestId to $status")
//        db.collection("buddyRequests").document(requestId)
//            .update("status", status)
//            .addOnSuccessListener {
//                Log.d("FirebaseRepo", "Status updated successfully")
//                onResult(true)
//            }
//            .addOnFailureListener { e ->
//                Log.e("FirebaseRepo", "Update FAILED: ${e.message}")
//                onResult(false)
//            }
//    }
//}

    fun updateRequestStatus(requestId: String, status: String, onResult: (Boolean) -> Unit) {
        Log.d("FirebaseRepo", "Updating request $requestId to $status")
        db.collection("buddyRequests").document(requestId)
            .update("status", status)
            .addOnSuccessListener {
                Log.d("FirebaseRepo", "Status updated successfully")
                onResult(true)
            }
            .addOnFailureListener { e ->
                Log.e("FirebaseRepo", "Update FAILED: ${e.message}")
                onResult(false)
            }
    }


    fun getCurrentUserDetails(onResult: (Map<String, Any>?) -> Unit) {
        val userId = auth.currentUser?.uid
        if (userId != null) {
            getUserDetails(userId, onResult)
        } else {
            onResult(null)
        }
    }

    // This fetches any user's data (Self or Recommended)
    fun getUserDetails(userId: String, onResult: (Map<String, Any>?) -> Unit) {
        db.collection("users").document(userId).get()
            .addOnSuccessListener { document ->
                onResult(document.data)
            }
            .addOnFailureListener { onResult(null) }
    }

    fun updateFullUserProfile(data: Map<String, Any>, onResult: (Boolean) -> Unit) {
        val userId = auth.currentUser?.uid
        if (userId != null) {
            // Using .set with merge: true ensures fields like 'bio' are created if they don't exist
            db.collection("users").document(userId)
                .set(data, com.google.firebase.firestore.SetOptions.merge())
                .addOnSuccessListener { onResult(true) }
                .addOnFailureListener { onResult(false) }
        }
    }
}
