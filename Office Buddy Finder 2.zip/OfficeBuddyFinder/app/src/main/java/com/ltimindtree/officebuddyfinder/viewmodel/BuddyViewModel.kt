package com.ltimindtree.officebuddyfinder.viewmodel


import androidx.compose.animation.core.copy
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
//import com.ltimindtree.officebuddyfinder
import com.ltimindtree.officebuddyfinder.ui1.ui1.components.Event
import com.ltimindtree.officebuddyfinder.repository.FirebaseRepository
import com.ltimindtree.officebuddyfinder.ui1.ui1.components.User
import com.google.firebase.firestore.FieldPath
class BuddyViewModel : ViewModel() {
    private val repo = FirebaseRepository()
    fun getAllUsers(onResult: (List<User>) -> Unit) {
        repo.getAllUsers(onResult)
    }

    fun sendRequest(senderId: String, receiverId: String, onResult: (Boolean) -> Unit) {
        repo.sendBuddyRequest(senderId, receiverId, onResult)
    }
    // BuddyViewModel.kt mein add karein

    fun updateUserData(userId: String, field: String, value: String) {
        val db = FirebaseFirestore.getInstance()
        if (userId.isNotEmpty()) {
            db.collection("users").document(userId)
                .update(field, value)
                .addOnSuccessListener {
                    println("Field $field updated successfully!")
                }
                .addOnFailureListener {
                    println("Error updating $field")
                }
        }
    }

    // User ka data fetch karne ke liye function
    fun getCurrentUser(userId: String, onSuccess: (User) -> Unit) {
        val db = FirebaseFirestore.getInstance()
        db.collection("users").document(userId).get()
            .addOnSuccessListener { document ->
                val user = document.toObject(User::class.java)
                if (user != null) onSuccess(user)
            }
    }

    // 1. Naya event upload karne ke liye
    fun hostEvent(event: Event, onComplete: (Boolean) -> Unit) {
        val db = FirebaseFirestore.getInstance()
        val eventRef = db.collection("events").document() // Auto-generate ID
        val finalEvent = event.copy(id = eventRef.id)

        eventRef.set(finalEvent)
            .addOnSuccessListener { onComplete(true) }
            .addOnFailureListener { onComplete(false) }
    }

    // 2. Saare events real-time fetch karne ke liye
    fun getAllEvents(onEventsUpdate: (List<Event>) -> Unit) {
        val db = FirebaseFirestore.getInstance()
        db.collection("events")
            .addSnapshotListener { snapshot, error ->
                if (error != null) return@addSnapshotListener

                val events = snapshot?.documents?.mapNotNull { it.toObject(Event::class.java) }
                    ?: emptyList()
                onEventsUpdate(events)
            }
    }
    // Ye import zaroori hai

    fun getAcceptedFriends(onResult: (List<User>) -> Unit) {
        val currentUserId = FirebaseAuth.getInstance().currentUser?.uid ?: return
        val db = FirebaseFirestore.getInstance()

        // 1. "buddyRequests" collection ko listen karein
        db.collection("buddyRequests")
            .whereEqualTo("status", "accepted")
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    onResult(emptyList())
                    return@addSnapshotListener
                }

                val friendIds = mutableSetOf<String>()
                snapshot?.documents?.forEach { doc ->
                    val senderId = doc.getString("senderId")
                    val receiverId = doc.getString("receiverId")

                    if (senderId == currentUserId) {
                        receiverId?.let { friendIds.add(it) }
                    } else if (receiverId == currentUserId) {
                        senderId?.let { friendIds.add(it) }
                    }
                }

                if (friendIds.isEmpty()) {
                    onResult(emptyList())
                } else {
                    // 2. IMPORTANT FIX: documentId() use karein agar aapne user id ko document name rakha hai
                    // Ya fir check karein ki aapka field name "id" hai ya "uid"
                    db.collection("users")
                        .whereIn(FieldPath.documentId(), friendIds.toList())
                        .get()
                        .addOnSuccessListener { userDocs ->
                            val users = userDocs.toObjects(User::class.java)
                            onResult(users)
                        }
                        .addOnFailureListener {
                            onResult(emptyList())
                        }
                }
            }
    }
    // BuddyViewModel.kt mein class ke andar add karein

    // Friends count ko hold karne ke liye state
    var friendsCount by mutableStateOf(0)

    fun getAcceptedFriendsCount() {


        val currentUserId = FirebaseAuth.getInstance().currentUser?.uid ?: return
        val db = FirebaseFirestore.getInstance()

        db.collection("buddyRequests")
            .whereEqualTo("status", "accepted")
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    friendsCount = 0
                    return@addSnapshotListener
                }

                var count = 0
                snapshot?.documents?.forEach { doc ->
                    val senderId = doc.getString("senderId")
                    val receiverId = doc.getString("receiverId")
                    if (senderId == currentUserId || receiverId == currentUserId) {
                        count++
                    }
                }
                friendsCount = count // Count update ho jayega automatically
                android.util.Log.d("Count_DEBUG", "Count updated to : $friendsCount")
            }
    }
}