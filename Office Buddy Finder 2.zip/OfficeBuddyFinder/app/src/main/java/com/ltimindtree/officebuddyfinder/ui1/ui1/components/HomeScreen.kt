package com.ltimindtree.officebuddyfinder.ui1.ui1.components

import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AddCircle
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.ExitToApp
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Place
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.google.firebase.auth.FirebaseAuth
import com.ltimindtree.officebuddyfinder.R
import com.ltimindtree.officebuddyfinder.viewmodel.BuddyViewModel
import kotlinx.coroutines.launch

import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle

data class User(
    val id: String = "",
    val name: String = "",
    val department: String = "",
    val bio: String = "",
    val hobbies: String = "",
    val movies: String = "",
    val hometown: String = ""
)

@Composable
fun HomeScreen(navController: NavController) {
    val viewModel: BuddyViewModel = viewModel()
    val auth = FirebaseAuth.getInstance()
    val context=LocalContext.current
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope = rememberCoroutineScope()

    var userList by remember {
        mutableStateOf(listOf<User>())
    }

    val currentUserId = auth.currentUser?.uid ?: ""

    LaunchedEffect(Unit) {
        viewModel.getAllUsers { users ->
            userList = users
        }
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet(
                modifier = Modifier.width(300.dp)
            ) {
                Text(
                    "Menu",
                    modifier = Modifier.padding(16.dp),
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold
                )
                HorizontalDivider()

                NavigationDrawerItem(
                    label = { Text("Events") },
                    selected = false,
                    icon = { Icon(Icons.Default.DateRange, contentDescription = null) },
                    onClick = { navController.navigate("events")}
                )
                NavigationDrawerItem(
                    label = { Text("Travel Buddy") },
                    selected = false,
                    icon = { Icon(Icons.Default.Place, contentDescription = null) },
                    onClick = { navController.navigate("travel")}
                )
                NavigationDrawerItem(
                    label = { Text("Profile") },
                    selected = false,
                    icon = { Icon(Icons.Default.AccountCircle, contentDescription = null) },
                    onClick = {
                        scope.launch { drawerState.close() }
                        navController.navigate("profile/{name}/{department}")
                    }
                )
                NavigationDrawerItem(
                    label = { Text("Requests") },
                    selected = false,
                    icon = { Icon(Icons.Default.AddCircle, contentDescription = null) },
                    onClick = {
                        scope.launch { drawerState.close() }
                        navController.navigate("requests")
                    }
                )
                Spacer(Modifier.weight(1f))
                NavigationDrawerItem(
                    label = { Text("Logout", color = Color.Red) },
                    selected = false,
                    icon = { Icon(Icons.Default.ExitToApp, contentDescription = null, tint = Color.Red) },
                    onClick = {
                        auth.signOut()
                        navController.navigate("login") {
                            popUpTo("home") { inclusive = true }
                        }
                    }
                )
            }
        }
    ) {
        Scaffold(
            topBar = {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    color = Teal,
                    tonalElevation = 3.dp
                ) {
                    Row(
                        modifier = Modifier
                            .statusBarsPadding()
                            .padding(horizontal = 16.dp, vertical = 12.dp)
                            .fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Image(
                                painter = painterResource(R.drawable.outline_handshake_24),
                                contentDescription = "logo",
                                modifier = Modifier.size(25.dp)
                            )
                            Spacer(Modifier.width(12.dp))
                            Text("WorkBond", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        }

                        IconButton(onClick = { scope.launch { drawerState.open() } }) {
                            Icon(Icons.Default.Menu, contentDescription = "Menu")
                        }
                    }
                }
            }
        ) { innerPadding ->
            Column(modifier = Modifier
                .padding(innerPadding)
                .fillMaxSize()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween, // Isse dono text opposite sides pe ho jayenge
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Recommended for you",
                        style = TextStyle(
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.Black
                        )
                    )

                    // Naya Friends clickable text
                    Text(
                        text = "Friends (${viewModel.friendsCount})",
                        modifier = Modifier.clickable {
                            navController.navigate("friends_list") // Nayi screen ka route
                        },
                        style = TextStyle(
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Medium,
                            color = Color(0xFF1A9E8F) // Cyan color jo aap use kar rahe hain
                        )
                    )
                }
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(bottom = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(userList) { user ->
                        if (user.id != currentUserId) {
                            UserListItem(
                                user = user,
                                onConnectClick = {
                                    if (currentUserId.isNotBlank()) {
                                        viewModel.sendRequest(
                                            senderId = currentUserId,
                                            receiverId = user.id
                                        ) { success ->
                                            if (success) Toast.makeText(context, "Request Sent!", Toast.LENGTH_SHORT).show()
                                            else Toast.makeText(context, "Failed to send request", Toast.LENGTH_SHORT).show()
                                        }
                                    }
                                },
                                onClick = {
                                    // Dusre user ki profile kholne ke liye uski ID bhejni hogi
                                    navController.navigate("other_profile/${user.id}")
                                },

                                navController = navController
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun UserListItem(user: User, onConnectClick: () -> Unit, onClick: () -> Unit,navController: NavController) {
    ElevatedCard(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
            .background(Color.White),
        shape = RoundedCornerShape(12.dp),
        onClick = {

            // This 'user.id' must be the Firestore Document ID of that specific person
            navController.navigate("other_profile/${user.id}")
        }
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(60.dp)
                    .clip(CircleShape)
                    .background(Color.LightGray),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    Icons.Default.AccountCircle,
                    contentDescription = "profile pic",
                    modifier = Modifier.size(40.dp),
                    tint = Color.Gray
                )
            }

            Spacer(modifier = Modifier.width(16.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(text = user.name, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Text(text = user.department, fontSize = 14.sp, color = Color.DarkGray)
            }

            IconButton(onClick = {onConnectClick}) {
                Icon(imageVector = Icons.Default.Add, contentDescription = "Connect")

            }

        }
    }
}
