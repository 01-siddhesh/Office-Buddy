package com.ltimindtree.officebuddyfinder.model

//data class Event(
//    val id: String = "",
//    val title: String = "",
//    val description: String = "",
//    val date: String = "",
//    val hostedBy: String = "", // User ID ya Name
//    val location: String = ""
//)