package com.ltimindtree.officebuddyfinder.ui1.ui1.components



import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.ltimindtree.officebuddyfinder.repository.FirebaseRepository

@Composable
fun OtherUserProfileScreen(navController: NavController, userId: String) {
    val repository = remember { FirebaseRepository() }

    var name by remember { mutableStateOf("Loading...") }
    var job by remember { mutableStateOf("...") }
    var bio by remember { mutableStateOf("") }
    var hobbies by remember { mutableStateOf("") }
    var movies by remember { mutableStateOf("") }
    var hometown by remember { mutableStateOf("") }

    LaunchedEffect(userId) {
        repository.getUserDetails(userId) { data ->
            if (data != null) {
                name = data["name"]?.toString() ?: "Unknown"
                job = data["department"]?.toString() ?: "No Department"
                bio = data["bio"]?.toString() ?: "No bio available"
                hobbies = data["hobbies"]?.toString() ?: "None listed"
                movies = data["movies"]?.toString() ?: "None listed"
                hometown = data["hometown"]?.toString() ?: "Not specified"
            }
        }
    }

    Scaffold(
        topBar = {
            Surface(tonalElevation = 3.dp) {
                Row(
                    modifier = Modifier.statusBarsPadding().padding(8.dp).fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                    Text("Buddy Profile", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier.padding(innerPadding).fillMaxSize(),
            contentPadding = PaddingValues(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            item {
                Box(modifier = Modifier.padding(bottom = 16.dp)) {
                    Box(modifier = Modifier.size(120.dp).clip(CircleShape).background(Color.LightGray), contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.AccountCircle, null, Modifier.size(90.dp), tint = Color.Gray)
                    }
                }

                Text(name, fontSize = 26.sp, fontWeight = FontWeight.Bold)
                Text(job, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(bottom = 24.dp))

                DetailItem("Bio", bio)
                DetailItem("Department", job)
                DetailItem("Hobbies", hobbies)
                DetailItem("Movies", movies)
                DetailItem("Hometown", hometown)

                Spacer(Modifier.height(32.dp))

//                Button(
//                    onClick = {  },
//                    modifier = Modifier.fillMaxWidth()
//                ) {
//                    Text("Send Buddy Request")
//                }
            }
        }
    }
}