package com.ltimindtree.officebuddyfinder.ui1.ui1.components

import androidx.compose.runtime.mutableStateListOf
import androidx.lifecycle.ViewModel
import java.util.UUID

// ─────────────────────────────────────────────────────────────────────────────
//  MODELS
// ─────────────────────────────────────────────────────────────────────────────

enum class TransportMode { CAR, TRAIN, BUS, FLIGHT }

enum class TravelType { HOME_TRAVEL, WEEKEND_TRIP }

data class Expense(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val amount: Double
)

data class TravelPost(
    val id: String = UUID.randomUUID().toString(),
    val creatorName: String,
    val travelType: TravelType,
    val startLocation: String,
    val destination: String,
    val travelDate: String,
    val transportMode: TransportMode,
    val availableSeats: Int,
    val estimatedCost: Double,
    val description: String,
    val placesToVisit: List<String> = emptyList(),
    val expenses: List<Expense> = emptyList(),
    val members: List<String> = emptyList()
)

// ─────────────────────────────────────────────────────────────────────────────
//  VIEWMODEL
// ─────────────────────────────────────────────────────────────────────────────

class TravelBuddyViewModel : ViewModel() {

    // mutableStateListOf is Compose-aware — any change automatically recomposes UI
    private val _posts = mutableStateListOf<TravelPost>()
    val posts: List<TravelPost> get() = _posts

    init { loadDummyData() }

    // ── Add a new post to the top of the feed ────────────────────────────────
    fun addPost(post: TravelPost) {
        _posts.add(0, post)
    }

    // ── Find a post by its ID ────────────────────────────────────────────────
    fun getPostById(id: String): TravelPost? = _posts.find { it.id == id }

    // ── Join a trip: decrease seats, add user to members ────────────────────
    fun joinTrip(postId: String, userName: String = "You") {
        val index = _posts.indexOfFirst { it.id == postId }
        if (index == -1) return
        val post = _posts[index]
        if (post.availableSeats <= 0 || post.members.contains(userName)) return
        _posts[index] = post.copy(
            availableSeats = post.availableSeats - 1,
            members = post.members + userName
        )
    }

    // ── Expense helpers ──────────────────────────────────────────────────────
    fun getTotalExpense(postId: String): Double =
        getPostById(postId)?.expenses?.sumOf { it.amount } ?: 0.0

    fun getCostPerPerson(postId: String): Double {
        val post = getPostById(postId) ?: return 0.0
        val count = post.members.size.coerceAtLeast(1)
        return getTotalExpense(postId) / count
    }

    // ── Sample data loaded on first launch ──────────────────────────────────
    private fun loadDummyData() {
        _posts.addAll(listOf(
            TravelPost(
                creatorName = "Arjun Kumar",
                travelType = TravelType.HOME_TRAVEL,
                startLocation = "Bangalore", destination = "Chennai",
                travelDate = "20 Mar 2025", transportMode = TransportMode.TRAIN,
                availableSeats = 3, estimatedCost = 450.0,
                description = "Going home for the weekend. Looking for travel companions to share the journey. It's a fun 5-hour train ride!",
                placesToVisit = listOf("Marina Beach", "Kapaleeshwarar Temple", "Pondy Bazaar"),
                expenses = listOf(Expense(name = "Train Tickets", amount = 900.0), Expense(name = "Food", amount = 300.0)),
//                members = listOf("Arjun Kumar", "Priya Sharma")
            ),
            TravelPost(
                creatorName = "Sneha Reddy",
                travelType = TravelType.WEEKEND_TRIP,
                startLocation = "Hyderabad", destination = "Goa",
                travelDate = "22 Mar 2025", transportMode = TransportMode.FLIGHT,
                availableSeats = 2, estimatedCost = 3500.0,
                description = "Weekend trip to Goa! Planning beaches, local food, and the famous night market. Accommodation is booked. Need 2 more people to split costs!",
                placesToVisit = listOf("Baga Beach", "Dudhsagar Falls", "Old Goa Churches", "Anjuna Night Market"),
                expenses = listOf(
                    Expense(name = "Flight Tickets", amount = 7000.0),
                    Expense(name = "Hotel (2 nights)", amount = 4000.0),
                    Expense(name = "Food & Activities", amount = 2000.0)
                ),
                members = listOf("Sneha Reddy", "Rahul Mehta", "Divya Nair")
            ),
            TravelPost(
                creatorName = "Vikram Singh",
                travelType = TravelType.WEEKEND_TRIP,
                startLocation = "Pune", destination = "Lonavala",
                travelDate = "15 Mar 2025", transportMode = TransportMode.CAR,
                availableSeats = 4, estimatedCost = 800.0,
                description = "Road trip to Lonavala! Fresh air, stunning waterfalls, and of course — chikki! I have a car with 4 empty seats. Let's split the fuel cost.",
                placesToVisit = listOf("Bhushi Dam", "Tiger's Leap", "Karla Caves", "Lion's Point"),
                expenses = listOf(Expense(name = "Fuel", amount = 1500.0), Expense(name = "Food & Chikki", amount = 600.0)),
                members = listOf("Vikram Singh")
            ),
            TravelPost(
                creatorName = "Meera Iyer",
                travelType = TravelType.HOME_TRAVEL,
                startLocation = "Mumbai", destination = "Coimbatore",
                travelDate = "28 Mar 2025", transportMode = TransportMode.BUS,
                availableSeats = 1, estimatedCost = 600.0,
                description = "Taking the overnight bus home. It's a long journey — would be nice to have some company! Anyone traveling the same route?",
                placesToVisit = listOf("Marudhamalai Temple", "Nilgiris Hills"),
                expenses = listOf(Expense(name = "Bus Ticket", amount = 600.0)),
                members = listOf("Meera Iyer", "Karthik Raj")
            )
        ))
    }
}
