package com.ltimindtree.officebuddyfinder.model

data class User(
    val id: String = "",
    val name: String = "",
    val department: String = "",
    val bio: String = "",
    val hobbies: String = "",
    val movies: String = "",
    val hometown: String = ""
)