package com.ltimindtree.officebuddyfinder.ui1.ui1.components


import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import java.text.SimpleDateFormat
import java.util.*

// ─────────────────────────────────────────────────────────────────────────────
//  THEME COLORS  (inline — no separate Color.kt needed)
// ─────────────────────────────────────────────────────────────────────────────

private val Teal1         = Color(0xFF1A9E8F)
private val TealDark       = Color(0xFF13796D)
private val TealTrack      = Color(0xFFD0EFEC)
private val ChipUnselected = Color(0xFFEEEEEE)
private val ScreenBg       = Color(0xFFF5F6F8)
private val CardBg         = Color(0xFFFFFFFF)
private val TextPrimary    = Color(0xFF111111)
private val TextSecondary  = Color(0xFF888888)
private val DividerColor   = Color(0xFFE8E8E8)

// ─────────────────────────────────────────────────────────────────────────────
//  NAVIGATION
// ─────────────────────────────────────────────────────────────────────────────

private object Routes {
    const val FEED   = "travel_feed"
    const val CREATE = "create_travel_post"
    const val DETAIL = "travel_detail/{postId}"
    fun detail(postId: String) = "travel_detail/$postId"
}

@Composable
fun TravelBuddyNavHost(
    rootNavController: NavController
) {
    // Single ViewModel instance shared across all three screens
    val viewModel: TravelBuddyViewModel = viewModel()
    val navController = rememberNavController()
    NavHost(navController = navController, startDestination = Routes.FEED) {

        composable(Routes.FEED) {
            TravelFeedScreen(
                viewModel     = viewModel,
                onCreatePost  = { navController.navigate(Routes.CREATE) },
                onViewDetails = { postId -> navController.navigate(Routes.detail(postId)) }
            )
        }

        composable(Routes.CREATE) {
            CreateTravelPostScreen(
                viewModel      = viewModel,
                onPostCreated  = { navController.popBackStack() },
                onBack         = { navController.popBackStack() }
            )
        }

        composable(Routes.DETAIL) { backStack ->
            val postId = backStack.arguments?.getString("postId") ?: return@composable
            TravelDetailScreen(
                viewModel = viewModel,
                postId    = postId,
                onBack    = { navController.popBackStack() }
            )
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
//  TRANSPORT HELPERS
// ─────────────────────────────────────────────────────────────────────────────

private fun transportIcon(mode: TransportMode): ImageVector = when (mode) {
    TransportMode.CAR    -> Icons.Default.DirectionsCar
    TransportMode.TRAIN  -> Icons.Default.Train
    TransportMode.BUS    -> Icons.Default.DirectionsBus
    TransportMode.FLIGHT -> Icons.Default.Flight
}

private fun transportLabel(mode: TransportMode): String = when (mode) {
    TransportMode.CAR    -> "Car"
    TransportMode.TRAIN  -> "Train"
    TransportMode.BUS    -> "Bus"
    TransportMode.FLIGHT -> "Flight"
}

// ─────────────────────────────────────────────────────────────────────────────
//  SCREEN 1 — TRAVEL FEED
// ─────────────────────────────────────────────────────────────────────────────

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun TravelFeedScreen(
    viewModel: TravelBuddyViewModel,
    onCreatePost: () -> Unit,
    onViewDetails: (String) -> Unit
) {
    Scaffold(
        containerColor = ScreenBg,
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Default.ConnectingAirports,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(26.dp)
                        )
                        Spacer(Modifier.width(10.dp))
                        Column {
                            Text(
                                "Travel Buddy",
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Text(
                                "Find your travel companion",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color.White.copy(alpha = 0.75f)
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Teal)
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = onCreatePost,
                icon = { Icon(Icons.Default.Add, null, tint = Color.White) },
                text = { Text("Post a Trip", color = Color.White, fontWeight = FontWeight.SemiBold) },
                containerColor = Teal
            )
        }
    ) { padding ->

        if (viewModel.posts.isEmpty()) {
            Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("✈️", style = MaterialTheme.typography.displayMedium)
                    Spacer(Modifier.height(12.dp))
                    Text("No trips posted yet", style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold, color = TextPrimary)
                    Text("Be the first to post a trip!", style = MaterialTheme.typography.bodyMedium,
                        color = TextSecondary)
                }
            }
            return@Scaffold
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Text("${viewModel.posts.size} trips available",
                    style = MaterialTheme.typography.bodySmall, color = TextSecondary,
                    modifier = Modifier.padding(start = 2.dp, bottom = 2.dp))
            }
            items(items = viewModel.posts, key = { it.id }) { post ->
                TravelPostCard(post = post, onViewDetails = { onViewDetails(post.id) })
            }
            item { Spacer(Modifier.height(80.dp)) }
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
//  TRAVEL POST CARD  (used inside the feed)
// ─────────────────────────────────────────────────────────────────────────────

@Composable
private fun TravelPostCard(post: TravelPost, onViewDetails: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(2.dp),
        colors = CardDefaults.cardColors(containerColor = CardBg)
    ) {
        Column {
            // Teal header
            Box(
                Modifier.fillMaxWidth().background(Teal)
                    .padding(horizontal = 16.dp, vertical = 14.dp)
            ) {
                Row(Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically) {

                    Column(Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(transportIcon(post.transportMode), null,
                                tint = Color.White, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text(transportLabel(post.transportMode),
                                style = MaterialTheme.typography.labelMedium,
                                color = Color.White.copy(alpha = 0.85f))
                        }
                        Spacer(Modifier.height(6.dp))
                        Text("${post.startLocation}  →  ${post.destination}",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold, color = Color.White)
                    }

                    Surface(shape = RoundedCornerShape(20.dp),
                        color = Color.White.copy(alpha = 0.20f)) {
                        Text(
                            if (post.travelType == TravelType.HOME_TRAVEL) "Home Travel" else "Weekend Trip",
                            style = MaterialTheme.typography.labelSmall, color = Color.White,
                            fontWeight = FontWeight.Medium,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp))
                    }
                }
            }

            // White card body
            Column(Modifier.padding(16.dp)) {
                Row(Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically) {
                    SmallIconText(Icons.Default.DateRange, post.travelDate)
                    SmallIconText(Icons.Default.Person, post.creatorName)
                }

                Spacer(Modifier.height(12.dp))
                HorizontalDivider(color = DividerColor)
                Spacer(Modifier.height(12.dp))

                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    val seatsOk = post.availableSeats > 0
                    TinyChip(
                        label = if (seatsOk) "${post.availableSeats} Seats" else "Full",
                        containerColor = if (seatsOk) TealTrack else Color(0xFFFFDAD6),
                        contentColor   = if (seatsOk) TealDark  else Color(0xFF93000A),
                        modifier = Modifier.weight(1f))
                    TinyChip("₹${post.estimatedCost.toInt()}/person",
                        TealTrack, TealDark, Modifier.weight(1f))
                    TinyChip("${post.members.size} Joined",
                        Color(0xFFF0F0F0), TextSecondary, Modifier.weight(1f))
                }

                Spacer(Modifier.height(14.dp))

                Button(onClick = onViewDetails, modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Teal)) {
                    Text("View Details", style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.SemiBold, color = Color.White)
                    Spacer(Modifier.width(4.dp))
                    Icon(Icons.Default.ChevronRight, null,
                        modifier = Modifier.size(18.dp), tint = Color.White)
                }
            }
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
//  SCREEN 2 — CREATE TRAVEL POST
// ─────────────────────────────────────────────────────────────────────────────

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun CreateTravelPostScreen(
    viewModel: TravelBuddyViewModel,
    onPostCreated: () -> Unit,
    onBack: () -> Unit
) {
    // Form state
    var creatorName   by remember { mutableStateOf("") }
    var startLocation by remember { mutableStateOf("") }
    var destination   by remember { mutableStateOf("") }
    var travelDate    by remember { mutableStateOf("") }
    var seats         by remember { mutableStateOf("") }
    var cost          by remember { mutableStateOf("") }
    var description   by remember { mutableStateOf("") }
    var selectedType      by remember { mutableStateOf(TravelType.HOME_TRAVEL) }
    var selectedTransport by remember { mutableStateOf(TransportMode.TRAIN) }
    var newPlace      by remember { mutableStateOf("") }
    val placesList    = remember { mutableStateListOf<String>() }

    // Validation errors
    var nameErr   by remember { mutableStateOf("") }
    var startErr  by remember { mutableStateOf("") }
    var destErr   by remember { mutableStateOf("") }
    var dateErr   by remember { mutableStateOf("") }
    var seatsErr  by remember { mutableStateOf("") }
    var costErr   by remember { mutableStateOf("") }
    var descErr   by remember { mutableStateOf("") }
    var placeErr  by remember { mutableStateOf("") }

    // Date picker
    var showDatePicker by remember { mutableStateOf(false) }

    val todayUtc: Long = remember {
        Calendar.getInstance(TimeZone.getTimeZone("UTC")).apply {
            set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0);      set(Calendar.MILLISECOND, 0)
        }.timeInMillis
    }

    val datePickerState = rememberDatePickerState(
        initialSelectedDateMillis = todayUtc,
        selectableDates = object : SelectableDates {
            override fun isSelectableDate(utcTimeMillis: Long) = utcTimeMillis >= todayUtc
        }
    )

    val dateFmt = remember {
        SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).apply {
            timeZone = TimeZone.getTimeZone("UTC")
        }
    }

    fun validate(): Boolean {
        var ok = true
        nameErr  = when { creatorName.isBlank() -> { ok=false; "Name is required" }
            creatorName.trim().length < 2 -> { ok=false; "Minimum 2 characters" } else -> "" }
        startErr = when { startLocation.isBlank() -> { ok=false; "Starting location is required" }
            startLocation.trim().length < 2 -> { ok=false; "Enter a valid location" } else -> "" }
        destErr  = when { destination.isBlank() -> { ok=false; "Destination is required" }
            destination.trim().equals(startLocation.trim(), ignoreCase=true) ->
            { ok=false; "Must differ from starting location" } else -> "" }
        dateErr  = if (travelDate.isBlank()) { ok=false; "Please select a travel date" } else ""
        val si = seats.toIntOrNull()
        seatsErr = when { seats.isBlank() -> { ok=false; "Seats is required" }
            si==null -> { ok=false; "Enter a valid number" }
            si<=0    -> { ok=false; "At least 1 seat" }
            si>50    -> { ok=false; "Cannot exceed 50" } else -> "" }
        val cd = cost.toDoubleOrNull()
        costErr  = when { cost.isBlank()  -> { ok=false; "Cost is required" }
            cd==null -> { ok=false; "Enter a valid amount" }
            cd<0     -> { ok=false; "Cannot be negative" } else -> "" }
        descErr  = when { description.isBlank() -> { ok=false; "Description is required" }
            description.trim().length < 10 -> { ok=false; "Minimum 10 characters" } else -> "" }
        return ok
    }

    Scaffold(
        containerColor = ScreenBg,
        topBar = {
            TopAppBar(
                title = { Text("Post a Trip", fontWeight = FontWeight.Bold, color = Color.White) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back", tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Teal)
            )
        }
    ) { padding ->

        Column(
            modifier = Modifier.fillMaxSize().padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 20.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {

            // ── Your Name ────────────────────────────────────────────────────
            FieldLabel("Your Name")
            Spacer(Modifier.height(4.dp))
            OutlinedTextField(
                value = creatorName, onValueChange = { creatorName = it; nameErr = "" },
                placeholder = { Text("e.g. Ravi Sharma", color = TextSecondary) },
                isError = nameErr.isNotEmpty(),
                supportingText = if (nameErr.isNotEmpty()) {{ ErrText(nameErr) }} else null,
                modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(10.dp),
                singleLine = true, colors = fieldColors()
            )

            Spacer(Modifier.height(8.dp))

            // ── Travel Type ──────────────────────────────────────────────────
            FieldLabel("Travel Type")
            Spacer(Modifier.height(4.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                TravelType.values().forEach { type ->
                    val lbl = if (type == TravelType.HOME_TRAVEL) "Home Travel" else "Weekend Trip"
                    FilterChip(
                        selected = selectedType == type, onClick = { selectedType = type },
                        label = { Text(lbl, style = MaterialTheme.typography.bodySmall,
                            fontWeight = if (selectedType==type) FontWeight.SemiBold else FontWeight.Normal) },
                        modifier = Modifier.weight(1f),
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = Teal, selectedLabelColor = Color.White,
                            containerColor = ChipUnselected, labelColor = TextPrimary),
                        border = FilterChipDefaults.filterChipBorder(
                            enabled=true, selected=selectedType==type,
                            selectedBorderColor=Teal, borderColor=Color(0xFFCCCCCC))
                    )
                }
            }

            Spacer(Modifier.height(8.dp))

            // ── Starting Location ────────────────────────────────────────────
            FieldLabel("Starting Location")
            Spacer(Modifier.height(4.dp))
            OutlinedTextField(
                value = startLocation, onValueChange = { startLocation = it; startErr = "" },
                placeholder = { Text("e.g. Bangalore", color = TextSecondary) },
                isError = startErr.isNotEmpty(),
                supportingText = if (startErr.isNotEmpty()) {{ ErrText(startErr) }} else null,
                modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(10.dp),
                singleLine = true, colors = fieldColors()
            )

            Spacer(Modifier.height(8.dp))

            // ── Destination ──────────────────────────────────────────────────
            FieldLabel("Destination")
            Spacer(Modifier.height(4.dp))
            OutlinedTextField(
                value = destination, onValueChange = { destination = it; destErr = "" },
                placeholder = { Text("e.g. Mumbai", color = TextSecondary) },
                isError = destErr.isNotEmpty(),
                supportingText = if (destErr.isNotEmpty()) {{ ErrText(destErr) }} else null,
                modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(10.dp),
                singleLine = true, colors = fieldColors()
            )

            Spacer(Modifier.height(8.dp))

            // ── Travel Date — tappable Box, no OutlinedTextField ─────────────
            // Using a plain Box with Modifier.border + Modifier.clickable.
            // A readOnly OutlinedTextField intercepts ALL touch events internally,
            // so taps never fire. This Box approach is 100% reliable.
            FieldLabel("Travel Date")
            Spacer(Modifier.height(4.dp))
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .border(
                        width = 1.dp,
                        color = if (dateErr.isNotEmpty()) MaterialTheme.colorScheme.error
                        else Color(0xFFCCCCCC),
                        shape = RoundedCornerShape(10.dp)
                    )
                    .clip(RoundedCornerShape(10.dp))
                    .clickable { showDatePicker = true }
                    .padding(horizontal = 14.dp),
                contentAlignment = Alignment.CenterStart
            ) {
                Row(Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(
                        text  = if (travelDate.isBlank()) "Tap to pick a date" else travelDate,
                        style = MaterialTheme.typography.bodyLarge,
                        color = if (travelDate.isBlank()) TextSecondary else TextPrimary
                    )
                    Icon(Icons.Default.CalendarToday, "Pick date",
                        tint = Teal, modifier = Modifier.size(20.dp))
                }
            }
            if (dateErr.isNotEmpty()) {
                Spacer(Modifier.height(4.dp))
                ErrText(dateErr)
            }

            Spacer(Modifier.height(8.dp))

            // ── Mode of Transport ────────────────────────────────────────────
            FieldLabel("Mode of Transport")
            Spacer(Modifier.height(4.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(TransportMode.CAR, TransportMode.TRAIN).forEach { mode ->
                    TransportSelectChip(mode, selectedTransport==mode,
                        { selectedTransport=mode }, Modifier.weight(1f))
                }
            }
            Spacer(Modifier.height(6.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(TransportMode.BUS, TransportMode.FLIGHT).forEach { mode ->
                    TransportSelectChip(mode, selectedTransport==mode,
                        { selectedTransport=mode }, Modifier.weight(1f))
                }
            }

            Spacer(Modifier.height(8.dp))

            // ── Seats & Cost ─────────────────────────────────────────────────
            FieldLabel("Seats & Estimated Cost")
            Spacer(Modifier.height(4.dp))
            Row(Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.Top) {
                OutlinedTextField(
                    value = seats,
                    onValueChange = { if (it.all { c -> c.isDigit() } && it.length <= 2) { seats=it; seatsErr="" } },
                    label = { Text("Seats", style = MaterialTheme.typography.labelSmall) },
                    placeholder = { Text("e.g. 3", color = TextSecondary) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    isError = seatsErr.isNotEmpty(),
                    supportingText = if (seatsErr.isNotEmpty()) {{ ErrText(seatsErr) }} else null,
                    modifier = Modifier.weight(1f), shape = RoundedCornerShape(10.dp),
                    singleLine = true, maxLines = 1, colors = fieldColors()
                )
                OutlinedTextField(
                    value = cost,
                    onValueChange = { input ->
                        val f = input.filter { it.isDigit() || it=='.' }
                        if (f.count { it=='.' }<=1 && f.length<=7) { cost=f; costErr="" }
                    },
                    label = { Text("Cost (₹/person)", style = MaterialTheme.typography.labelSmall) },
                    placeholder = { Text("e.g. 500", color = TextSecondary) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    isError = costErr.isNotEmpty(),
                    supportingText = if (costErr.isNotEmpty()) {{ ErrText(costErr) }} else null,
                    modifier = Modifier.weight(1f), shape = RoundedCornerShape(10.dp),
                    singleLine = true, maxLines = 1, colors = fieldColors()
                )
            }

            Spacer(Modifier.height(8.dp))

            // ── Description ──────────────────────────────────────────────────
            FieldLabel("Description")
            Spacer(Modifier.height(4.dp))
            OutlinedTextField(
                value = description, onValueChange = { description=it; descErr="" },
                placeholder = { Text("Tell others about the trip, plans, what to expect...", color = TextSecondary) },
                isError = descErr.isNotEmpty(),
                supportingText = if (descErr.isNotEmpty()) {{ ErrText(descErr) }}
                else {{ Text("${description.length} chars (min 10)",
                    color=TextSecondary, style=MaterialTheme.typography.labelSmall) }},
                modifier = Modifier.fillMaxWidth().height(130.dp),
                shape = RoundedCornerShape(10.dp), maxLines = 5, colors = fieldColors()
            )

            Spacer(Modifier.height(8.dp))

            // ── Places to Visit (optional) ───────────────────────────────────
            FieldLabel("Places to Visit  (Optional)")
            Spacer(Modifier.height(4.dp))
            Row(Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.Top,
                horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = newPlace, onValueChange = { newPlace=it; placeErr="" },
                    placeholder = { Text("e.g. Beach, Museum", color = TextSecondary) },
                    isError = placeErr.isNotEmpty(),
                    supportingText = if (placeErr.isNotEmpty()) {{ ErrText(placeErr) }} else null,
                    modifier = Modifier.weight(1f), shape = RoundedCornerShape(10.dp),
                    singleLine = true, colors = fieldColors()
                )
                Button(
                    onClick = {
                        when {
                            newPlace.isBlank()  -> placeErr = "Enter a place name"
                            newPlace.trim().length < 2 -> placeErr = "Too short"
                            placesList.any { it.equals(newPlace.trim(), ignoreCase=true) } -> placeErr = "Already added"
                            placesList.size >= 10 -> placeErr = "Max 10 places"
                            else -> { placesList.add(newPlace.trim()); newPlace = "" }
                        }
                    },
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Teal),
                    modifier = Modifier.height(56.dp)
                ) { Icon(Icons.Default.Add, null, tint = Color.White) }
            }

            if (placesList.isNotEmpty()) {
                Spacer(Modifier.height(6.dp))
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    placesList.toList().forEach { place ->
                        Surface(shape = RoundedCornerShape(8.dp), color = TealTrack,
                            modifier = Modifier.fillMaxWidth()) {
                            Row(Modifier.fillMaxWidth()
                                .padding(start=14.dp, end=6.dp, top=4.dp, bottom=4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically) {
                                Text(place, style=MaterialTheme.typography.bodySmall,
                                    color=TealDark, modifier=Modifier.weight(1f))
                                IconButton(onClick={ placesList.remove(place) },
                                    modifier=Modifier.size(32.dp)) {
                                    Icon(Icons.Default.Close, "Remove $place",
                                        modifier=Modifier.size(16.dp),
                                        tint=TealDark.copy(alpha=0.7f))
                                }
                            }
                        }
                    }
                }
            }

            Spacer(Modifier.height(16.dp))

            // ── Submit ───────────────────────────────────────────────────────
            Button(
                onClick = {
                    if (validate()) {
                        viewModel.addPost(TravelPost(
                            creatorName    = creatorName.trim(),
                            travelType     = selectedType,
                            startLocation  = startLocation.trim(),
                            destination    = destination.trim(),
                            travelDate     = travelDate,
                            transportMode  = selectedTransport,
                            availableSeats = seats.toInt(),
                            estimatedCost  = cost.toDouble(),
                            description    = description.trim(),
                            placesToVisit  = placesList.toList(),
                            members        = listOf(creatorName.trim())
                        ))
                        onPostCreated()
                    }
                },
                modifier = Modifier.fillMaxWidth().height(52.dp),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Teal)
            ) {
                Text("Post Trip", style=MaterialTheme.typography.titleSmall,
                    fontWeight=FontWeight.Bold, color=Color.White)
            }

            Spacer(Modifier.height(28.dp))
        }
    }

    // DatePickerDialog — outside the Scaffold so it overlays the full screen
    if (showDatePicker) {
        DatePickerDialog(
            onDismissRequest = { showDatePicker = false },
            confirmButton = {
                TextButton(onClick = {
                    datePickerState.selectedDateMillis?.let { millis ->
                        travelDate = dateFmt.format(Date(millis)); dateErr = ""
                    }
                    showDatePicker = false
                }) { Text("OK", color=Teal, fontWeight=FontWeight.Bold) }
            },
            dismissButton = {
                TextButton(onClick = { showDatePicker=false }) {
                    Text("Cancel", color=TextSecondary)
                }
            },
            colors = DatePickerDefaults.colors(containerColor = CardBg)
        ) {
            DatePicker(
                state = datePickerState,
                colors = DatePickerDefaults.colors(
                    todayContentColor=Teal, todayDateBorderColor=Teal,
                    selectedDayContainerColor=Teal, selectedDayContentColor=Color.White,
                    currentYearContentColor=Teal,
                    selectedYearContainerColor=Teal, selectedYearContentColor=Color.White
                )
            )
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
//  SCREEN 3 — TRAVEL DETAIL

private data class DetailRow(val label: String, val value: String)
// ─────────────────────────────────────────────────────────────────────────────

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun TravelDetailScreen(
    viewModel: TravelBuddyViewModel,
    postId: String,
    onBack: () -> Unit
) {
    val post = viewModel.getPostById(postId)
    if (post == null) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("Trip not found.", color = TextSecondary)
        }
        return
    }

    // Pre-build detail rows list so we can pass it to LazyColumn items()
    val detailRows = listOf(
        DetailRow("Travel Type", if (post.travelType==TravelType.HOME_TRAVEL) "Home Travel" else "Weekend Trip"),
        DetailRow("Date",         post.travelDate),
        DetailRow("Transport",    transportLabel(post.transportMode)),
        DetailRow("Seats Left",   if (post.availableSeats>0) "${post.availableSeats}" else "No seats left"),
        DetailRow("Cost/Person",  "₹${post.estimatedCost.toInt()}"),
        DetailRow("Posted By",    post.creatorName)
    )

    Scaffold(
        containerColor = ScreenBg,
        topBar = {
            TopAppBar(
                title = { Text("${post.startLocation} → ${post.destination}",
                    fontWeight=FontWeight.Bold, color=Color.White,
                    style=MaterialTheme.typography.titleMedium) },
                navigationIcon = {
                    IconButton(onClick=onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back", tint=Color.White)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Teal)
            )
        }
    ) { padding ->

        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(bottom = 40.dp)
        ) {

            // 1. Hero banner
            item(key="hero") {
                Box(Modifier.fillMaxWidth().background(Teal).padding(20.dp)) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Surface(
                                modifier = Modifier.size(46.dp),
                                shape = RoundedCornerShape(50),
                                color = Color.White.copy(alpha = 0.2f)
                            ) {
                                Box(contentAlignment=Alignment.Center) {
                                    Icon(transportIcon(post.transportMode), null,
                                        tint=Color.White, modifier=Modifier.size(26.dp))
                                }
                            }
                            Spacer(Modifier.width(14.dp))
                            Column {
                                Text("${post.startLocation}  →  ${post.destination}",
                                    style=MaterialTheme.typography.headlineSmall,
                                    fontWeight=FontWeight.ExtraBold, color=Color.White)
                                Text("${transportLabel(post.transportMode)}  ·  ${post.travelDate}",
                                    style=MaterialTheme.typography.bodySmall,
                                    color=Color.White.copy(alpha=0.80f))
                            }
                        }
                        Spacer(Modifier.height(16.dp))
                        Row(horizontalArrangement=Arrangement.spacedBy(10.dp)) {
                            HeroPill("${post.availableSeats} Seats Left")
                            HeroPill("₹${post.estimatedCost.toInt()}/person")
                            HeroPill("${post.members.size} Members")
                        }
                    }
                }
            }

            // 2. Trip details section
            item(key="det_hdr") { CardSectionHeader("Trip Details") }
            items(items=detailRows, key={ it.label }) { row ->
                CardRow(label=row.label, value=row.value)
            }
            item(key="det_ftr") { CardSectionFooter() }

            // 3. Description
            item(key="desc_hdr") { CardSectionHeader("Description") }
            item(key="desc_body") {
                Box(Modifier.fillMaxWidth().padding(horizontal=16.dp)
                    .background(CardBg).padding(horizontal=16.dp, vertical=12.dp)) {
                    Text(post.description, style=MaterialTheme.typography.bodyMedium,
                        color=TextPrimary)
                }
            }
            item(key="desc_ftr") { CardSectionFooter() }

            // 4. Members — each member is its own LazyColumn item
            item(key="mem_hdr") { CardSectionHeader("Members  (${post.members.size})") }
            if (post.members.isEmpty()) {
                item(key="mem_empty") { CardEmptyRow("No members yet. Be the first to join!") }
            } else {
                items(items=post.members, key={"member_$it"}) { member ->
                    Box(Modifier.fillMaxWidth().padding(horizontal=16.dp)
                        .background(CardBg).padding(horizontal=16.dp, vertical=7.dp)) {
                        Surface(shape = RoundedCornerShape(20.dp), color = TealTrack) {
                            Text(member, style=MaterialTheme.typography.bodySmall,
                                color=TealDark, fontWeight=FontWeight.Medium,
                                modifier=Modifier.padding(horizontal=14.dp, vertical=6.dp))
                        }
                    }
                }
            }
            item(key="mem_ftr") { CardSectionFooter() }

            // 5. Places — each place is its own LazyColumn item
            if (post.placesToVisit.isNotEmpty()) {
                item(key="places_hdr") { CardSectionHeader("Places to Visit") }
                items(items=post.placesToVisit, key={"place_$it"}) { place ->
                    Box(Modifier.fillMaxWidth().padding(horizontal=16.dp)
                        .background(CardBg).padding(horizontal=16.dp, vertical=5.dp)) {
                        Surface(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(8.dp),
                            color = TealTrack.copy(alpha = 0.55f)
                        ) {
                            Text(place, style=MaterialTheme.typography.bodyMedium,
                                color=TealDark,
                                modifier=Modifier.padding(horizontal=14.dp, vertical=10.dp))
                        }
                    }
                }
                item(key="places_ftr") { CardSectionFooter() }
            }

            // 6. Expenses — each expense is its own LazyColumn item
            if (post.expenses.isNotEmpty()) {
                item(key="exp_hdr") { CardSectionHeader("Shared Expenses") }
                items(items=post.expenses, key={"expense_${it.id}"}) { expense ->
                    androidx.compose.foundation.layout.Row(
                        Modifier.fillMaxWidth().padding(horizontal=16.dp)
                            .background(CardBg).padding(horizontal=16.dp, vertical=10.dp),
                        horizontalArrangement=Arrangement.SpaceBetween,
                        verticalAlignment=Alignment.CenterVertically
                    ) {
                        Text(expense.name, style=MaterialTheme.typography.bodyMedium,
                            color=TextPrimary)
                        Text("₹${String.format("%.0f", expense.amount)}",
                            style=MaterialTheme.typography.bodyMedium,
                            fontWeight=FontWeight.SemiBold, color=Teal)
                    }
                }
                // Summary: total + per person
                item(key="exp_summary") {
                    val total     = viewModel.getTotalExpense(postId)
                    val perPerson = viewModel.getCostPerPerson(postId)
                    Column(Modifier.fillMaxWidth().padding(horizontal=16.dp)
                        .background(CardBg).padding(horizontal=16.dp, vertical=12.dp)) {
                        HorizontalDivider(color=DividerColor)
                        Spacer(Modifier.height(12.dp))
                        Row(Modifier.fillMaxWidth(),
                            horizontalArrangement=Arrangement.spacedBy(12.dp)) {
                            listOf("Total" to "₹${String.format("%.0f",total)}",
                                "Per Person" to "₹${String.format("%.0f",perPerson)}"
                            ).forEach { (label, value) ->
                                Surface(
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(10.dp),
                                    color = TealTrack
                                ) {
                                    Column(Modifier.padding(12.dp),
                                        horizontalAlignment=Alignment.CenterHorizontally) {
                                        Text(label, style=MaterialTheme.typography.labelSmall,
                                            color=TealDark.copy(alpha=0.7f))
                                        Spacer(Modifier.height(2.dp))
                                        Text(value, style=MaterialTheme.typography.titleMedium,
                                            fontWeight=FontWeight.ExtraBold, color=Teal)
                                    }
                                }
                            }
                        }
                    }
                }
                item(key="exp_ftr") { CardSectionFooter() }
            }

            // 7. Join Trip button
            item(key="join") {
                val alreadyJoined = post.members.contains("You")
                val isFull        = post.availableSeats <= 0
                Box(Modifier.padding(horizontal=16.dp, vertical=12.dp)) {
                    Button(
                        onClick  = { viewModel.joinTrip(postId=postId, userName="You") },
                        modifier = Modifier.fillMaxWidth().height(54.dp),
                        shape    = RoundedCornerShape(14.dp),
                        enabled  = !alreadyJoined && !isFull,
                        colors   = ButtonDefaults.buttonColors(
                            containerColor=Teal, disabledContainerColor=Color(0xFFBDBDBD))
                    ) {
                        Icon(
                            if (alreadyJoined) Icons.Default.CheckCircle else Icons.Default.PersonAdd,
                            null, modifier=Modifier.size(20.dp), tint=Color.White)
                        Spacer(Modifier.width(8.dp))
                        Text(
                            when { alreadyJoined->"Already Joined"; isFull->"Trip is Full"; else->"Join Trip" },
                            style=MaterialTheme.typography.titleSmall,
                            fontWeight=FontWeight.Bold, color=Color.White)
                    }
                }
            }
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
//  SMALL REUSABLE COMPOSABLES
// ─────────────────────────────────────────────────────────────────────────────

@Composable
private fun FieldLabel(text: String) = Text(text,
    style=MaterialTheme.typography.labelLarge, fontWeight=FontWeight.SemiBold, color=TextPrimary)

@Composable
private fun ErrText(msg: String) = Text(msg,
    color=MaterialTheme.colorScheme.error, style=MaterialTheme.typography.labelSmall)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun fieldColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor=Teal, focusedLabelColor=Teal, cursorColor=Teal,
    unfocusedBorderColor=Color(0xFFCCCCCC), unfocusedLabelColor=TextSecondary)

@Composable
private fun TransportSelectChip(
    mode: TransportMode, isSelected: Boolean,
    onClick: () -> Unit, modifier: Modifier = Modifier
) {
    FilterChip(selected=isSelected, onClick=onClick,
        label = {
            Row(Modifier.fillMaxWidth(),
                verticalAlignment=Alignment.CenterVertically,
                horizontalArrangement=Arrangement.Center) {
                Icon(transportIcon(mode), mode.name, modifier=Modifier.size(16.dp))
                Spacer(Modifier.width(6.dp))
                Text(transportLabel(mode), style=MaterialTheme.typography.bodySmall,
                    fontWeight=if(isSelected) FontWeight.SemiBold else FontWeight.Normal)
            }
        },
        modifier=modifier,
        colors=FilterChipDefaults.filterChipColors(
            selectedContainerColor=Teal, selectedLabelColor=Color.White,
            selectedLeadingIconColor=Color.White, containerColor=ChipUnselected, labelColor=TextPrimary),
        border=FilterChipDefaults.filterChipBorder(
            enabled=true, selected=isSelected,
            selectedBorderColor=Teal, borderColor=Color(0xFFCCCCCC))
    )
}

@Composable
private fun TinyChip(label: String, containerColor: Color,
                     contentColor: Color, modifier: Modifier = Modifier) {
    Surface(modifier = modifier, shape = RoundedCornerShape(8.dp), color = containerColor) {
        Box(Modifier.padding(vertical=6.dp, horizontal=4.dp),
            contentAlignment=Alignment.Center) {
            Text(label, style=MaterialTheme.typography.labelSmall,
                color=contentColor, fontWeight=FontWeight.SemiBold, maxLines=1)
        }
    }
}

@Composable
private fun SmallIconText(icon: ImageVector, text: String) {
    Row(verticalAlignment=Alignment.CenterVertically) {
        Icon(icon, null, modifier=Modifier.size(15.dp), tint=Teal)
        Spacer(Modifier.width(4.dp))
        Text(text, style=MaterialTheme.typography.bodySmall, color=TextSecondary)
    }
}

@Composable
private fun HeroPill(text: String) {
    Surface(shape = RoundedCornerShape(20.dp), color = Color.White.copy(alpha = 0.20f)) {
        Text(text, style=MaterialTheme.typography.labelSmall, color=Color.White,
            fontWeight=FontWeight.SemiBold,
            modifier=Modifier.padding(horizontal=12.dp, vertical=6.dp))
    }
}

@Composable
private fun CardSectionHeader(title: String) {
    Column(Modifier.fillMaxWidth().padding(start=16.dp, end=16.dp, top=12.dp)
        .background(CardBg, RoundedCornerShape(topStart=14.dp, topEnd=14.dp))
        .padding(start=16.dp, end=16.dp, top=14.dp, bottom=4.dp)) {
        Text(title, style=MaterialTheme.typography.titleSmall,
            fontWeight=FontWeight.Bold, color=Teal)
        Spacer(Modifier.height(8.dp))
        HorizontalDivider(color=DividerColor)
    }
}

@Composable
private fun CardSectionFooter() {
    Spacer(Modifier.fillMaxWidth().padding(horizontal=16.dp)
        .background(CardBg, RoundedCornerShape(bottomStart=14.dp, bottomEnd=14.dp))
        .height(12.dp))
}

@Composable
private fun CardRow(label: String, value: String) {
    Column(Modifier.fillMaxWidth().padding(horizontal=16.dp)
        .background(CardBg).padding(horizontal=16.dp, vertical=10.dp)) {
        Row(Modifier.fillMaxWidth(),
            horizontalArrangement=Arrangement.SpaceBetween,
            verticalAlignment=Alignment.CenterVertically) {
            Text(label, style=MaterialTheme.typography.bodySmall,
                color=TextSecondary, modifier=Modifier.weight(0.40f))
            Text(value, style=MaterialTheme.typography.bodyMedium,
                fontWeight=FontWeight.Medium, color=TextPrimary, modifier=Modifier.weight(0.60f))
        }
        Spacer(Modifier.height(8.dp))
        HorizontalDivider(color=DividerColor.copy(alpha=0.5f))
    }
}

@Composable
private fun CardEmptyRow(text: String) {
    Box(Modifier.fillMaxWidth().padding(horizontal=16.dp).background(CardBg)
        .padding(horizontal=16.dp, vertical=12.dp)) {
        Text(text, style=MaterialTheme.typography.bodySmall, color=TextSecondary)
    }
}

