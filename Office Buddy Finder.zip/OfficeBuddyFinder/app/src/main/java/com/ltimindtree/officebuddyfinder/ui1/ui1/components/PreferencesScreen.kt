//package com.ltimindtree.officebuddyfinder.ui1.ui1.components
//
//import androidx.compose.foundation.background
//import androidx.compose.foundation.clickable
//import androidx.compose.foundation.layout.Arrangement
//import androidx.compose.foundation.layout.Box
//import androidx.compose.foundation.layout.Column
//import androidx.compose.foundation.layout.Row
//import androidx.compose.foundation.layout.Spacer
//import androidx.compose.foundation.layout.fillMaxSize
//import androidx.compose.foundation.layout.fillMaxWidth
//import androidx.compose.foundation.layout.height
//import androidx.compose.foundation.layout.padding
//import androidx.compose.foundation.shape.RoundedCornerShape
//import androidx.compose.material3.Button
//import androidx.compose.material3.ButtonDefaults
//import androidx.compose.material3.OutlinedTextField
//import androidx.compose.material3.OutlinedTextFieldDefaults
//import androidx.compose.material3.Text
//import androidx.compose.runtime.Composable
//import androidx.compose.runtime.getValue
//import androidx.compose.runtime.mutableStateOf
//import androidx.compose.runtime.remember
//import androidx.compose.runtime.setValue
//import androidx.compose.ui.Alignment
//import androidx.compose.ui.Modifier
//import androidx.compose.ui.draw.clip
//import androidx.compose.ui.graphics.Color
//import androidx.compose.ui.graphics.Color.Companion.Cyan
//import androidx.compose.ui.text.font.FontWeight
//import androidx.compose.ui.unit.dp
//import androidx.compose.ui.unit.sp
//import androidx.lifecycle.viewmodel.compose.viewModel
//import androidx.navigation.NavController
//import com.ltimindtree.officebuddyfinder.viewmodel.AuthViewModel
//
//
//
//data class PreferenceItem(val genre: String)
//
//@Composable
//fun PrefrencesScreen(navController: NavController) {
//    val viewModel: AuthViewModel = viewModel()
//    val Navy = Color(0xFFF5F5F5)      // light grey background (instead of dark navy)
//    val Cyan = Color(0xFF1A9E8F)
//    var name by remember { mutableStateOf("") }
//    var jobProfile by remember { mutableStateOf("") }
//    var bio by remember { mutableStateOf("") }
//    var hometown by remember { mutableStateOf("") }
//
//    var selectedMovie by remember { mutableStateOf("") }
//    var isMovieDropdownExpanded by remember { mutableStateOf(false) }
//
//    val moviesList = remember {
//        listOf(
//            PreferenceItem("Horror"),
//            PreferenceItem("Comedy"),
//            PreferenceItem("Romance"),
//            PreferenceItem("Thriller")
//        )
//    }
//
//    Box(
//        modifier = Modifier
//            .fillMaxSize()
//            .background(Color.White),
//        contentAlignment = Alignment.Center
//    ) {
//        Column(
//            modifier = Modifier
//                .padding(horizontal = 28.dp)
//                .clip(RoundedCornerShape(24.dp))
//                .background(Color.White)
//                .padding(horizontal = 28.dp, vertical = 36.dp),
//            horizontalAlignment = Alignment.CenterHorizontally,
//            verticalArrangement = Arrangement.Center
//        ) {
//
//            Text(
//                "PREFERENCES",
//                color = Cyan,
//                fontSize = 24.sp,
//                fontWeight = FontWeight.Black,
//                letterSpacing = (-0.5).sp
//            )
//
//            Spacer(Modifier.height(6.dp))
//
//            Text(
//                "Tell us what you love",
//                color = Cyan,
//                fontSize = 13.sp
//            )
//
//            Spacer(Modifier.height(24.dp))
//
//            // Name Field
//            OutlinedTextField(
//                value = name,
//                onValueChange = { name = it },
//                label = { Text("Enter your name") },
//                modifier = Modifier.fillMaxWidth(),
//                singleLine = true,
//                shape = RoundedCornerShape(12.dp),
//                colors = OutlinedTextFieldDefaults.colors(
//                    focusedBorderColor = Cyan,
//                    unfocusedBorderColor = Cyan.copy(alpha = 0.3f),
//                    focusedContainerColor = Navy,
//                    unfocusedContainerColor = Navy,
//                    focusedTextColor = Color.Black,
//                    unfocusedTextColor = Color.Black,
//                    cursorColor = Cyan,
//                    focusedLabelColor = Cyan,
//                    unfocusedLabelColor = Cyan.copy(alpha = 0.5f)
//                )
//            )
//
//            Spacer(Modifier.height(16.dp))
//
//            // Job Profile Field
//            OutlinedTextField(
//                value = jobProfile,
//                onValueChange = { jobProfile = it },
//                label = { Text("Enter your job profile") },
//                modifier = Modifier.fillMaxWidth(),
//                singleLine = true,
//                shape = RoundedCornerShape(12.dp),
//                colors = OutlinedTextFieldDefaults.colors(
//                    focusedBorderColor = Cyan,
//                    unfocusedBorderColor = Cyan.copy(alpha = 0.3f),
//                    focusedContainerColor = Navy,
//                    unfocusedContainerColor = Navy,
//                    focusedTextColor = Color.Black,
//                    unfocusedTextColor = Color.Black,
//                    cursorColor = Cyan,
//                    focusedLabelColor = Cyan,
//                    unfocusedLabelColor = Cyan.copy(alpha = 0.5f)
//                )
//            )
//
//            Spacer(Modifier.height(16.dp))
//
//            // Bio Field
//            OutlinedTextField(
//                value = bio,
//                onValueChange = { bio = it },
//                label = { Text("Enter bio") },
//                modifier = Modifier.fillMaxWidth(),
//                singleLine = true,
//                shape = RoundedCornerShape(12.dp),
//                colors = OutlinedTextFieldDefaults.colors(
//                    focusedBorderColor = Cyan,
//                    unfocusedBorderColor = Cyan.copy(alpha = 0.3f),
//                    focusedContainerColor = Navy,
//                    unfocusedContainerColor = Navy,
//                    focusedTextColor = Color.Black,
//                    unfocusedTextColor = Color.Black,
//                    cursorColor = Cyan,
//                    focusedLabelColor = Cyan,
//                    unfocusedLabelColor = Cyan.copy(alpha = 0.5f)
//                )
//            )
//
//            Spacer(Modifier.height(16.dp))
//
//            // Movies Dropdown Label
//            Text(
//                "Movies",
//                color = Cyan,
//                fontSize = 13.sp,
//                fontWeight = FontWeight.SemiBold,
//                modifier = Modifier.fillMaxWidth()
//            )
//
//            Spacer(Modifier.height(8.dp))
//
//            // Dropdown Selector
//            Box(
//                modifier = Modifier
//                    .fillMaxWidth()
//                    .height(52.dp)
//                    .clip(RoundedCornerShape(12.dp))
//                    .background(Navy)
//                    .clickable { isMovieDropdownExpanded = !isMovieDropdownExpanded },
//                contentAlignment = Alignment.CenterStart
//            ) {
//                Row(
//                    modifier = Modifier
//                        .fillMaxWidth()
//                        .padding(horizontal = 16.dp),
//                    horizontalArrangement = Arrangement.SpaceBetween,
//                    verticalAlignment = Alignment.CenterVertically
//                ) {
//                    Text(
//                        text = if (selectedMovie.isEmpty()) "Choose a genre" else selectedMovie,
//                        color = if (selectedMovie.isEmpty()) Color.White else Cyan,
//                        fontSize = 14.sp
//                    )
//                    Text(
//                        if (isMovieDropdownExpanded) "▲" else "▼",
//                        color = Cyan,
//                        fontSize = 11.sp
//                    )
//                }
//            }
//
//            if (isMovieDropdownExpanded) {
//                Column(
//                    modifier = Modifier
//                        .fillMaxWidth()
//                        .clip(RoundedCornerShape(bottomStart = 12.dp, bottomEnd = 12.dp))
//                        .background(Color(0xFF0D2D55))
//                ) {
//                    moviesList.forEachIndexed { index, item ->
//                        val isSelected = selectedMovie == item.genre
//                        Row(
//                            modifier = Modifier
//                                .fillMaxWidth()
//                                .background(if (isSelected) Cyan.copy(alpha = 0.12f) else Color.Transparent)
//                                .clickable {
//                                    selectedMovie = item.genre
//                                    isMovieDropdownExpanded = false
//                                }
//                                .padding(horizontal = 16.dp, vertical = 14.dp),
//                            horizontalArrangement = Arrangement.SpaceBetween,
//                            verticalAlignment = Alignment.CenterVertically
//                        ) {
//                            Text(
//                                item.genre,
//                                color = if (isSelected) Cyan else Color.White,
//                                fontSize = 14.sp,
//                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
//                            )
//                            if (isSelected) {
//                                Text("✓", color = Cyan, fontWeight = FontWeight.Black)
//                            }
//                        }
//                        if (index < moviesList.size - 1) {
//                            Box(
//                                modifier = Modifier
//                                    .fillMaxWidth()
//                                    .height(1.dp)
//                                    .background(Cyan.copy(alpha = 0.08f))
//                            )
//                        }
//                    }
//                }
//            }
//
//            Spacer(Modifier.height(16.dp))
//
//            // Hometown Field
//            OutlinedTextField(
//                value = hometown,
//                onValueChange = { hometown = it },
//                label = { Text("Enter hometown") },
//                modifier = Modifier.fillMaxWidth(),
//                singleLine = true,
//                shape = RoundedCornerShape(12.dp),
//                colors = OutlinedTextFieldDefaults.colors(
//                    focusedBorderColor = Cyan,
//                    unfocusedBorderColor = Cyan.copy(alpha = 0.3f),
//                    focusedContainerColor = Navy,
//                    unfocusedContainerColor = Navy,
//                    focusedTextColor = Color.Black,
//                    unfocusedTextColor = Color.Black,
//                    cursorColor = Cyan,
//                    focusedLabelColor = Cyan,
//                    unfocusedLabelColor = Cyan.copy(alpha = 0.5f)
//                )
//            )
//
//            Spacer(Modifier.height(24.dp))
//
//            Button(
//                onClick = { navController.navigate("login")},
//                enabled = selectedMovie.isNotEmpty(),
//                modifier = Modifier
//                    .fillMaxWidth()
//                    .height(52.dp),
//                shape = RoundedCornerShape(14.dp),
//                colors = ButtonDefaults.buttonColors(
//                    containerColor = Cyan,
//                    contentColor = Navy,
//                    disabledContainerColor = Cyan.copy(alpha = 0.25f),
//                    disabledContentColor = Color.White.copy(alpha = 0.4f)
//                )
//            ) {
//                Text(
//                    "Save Preferences",
//                    fontWeight = FontWeight.Black,
//                    fontSize = 15.sp
//                )
//            }
//        }
//    }
//}
package com.ltimindtree.officebuddyfinder.ui1.ui1.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.ltimindtree.officebuddyfinder.repository.FirebaseRepository

// PreferenceItem is kept here for the genre dropdown
data class PreferenceItem(val genre: String)

@Composable
fun PrefrencesScreen(navController: NavController) {
    val repository = remember { FirebaseRepository() }

    val Navy = Color(0xFFF5F5F5)
    val Cyan = Color(0xFF1A9E8F)

    // ── Form state ────────────────────────────────────────────────────────
    var bio      by remember { mutableStateOf("") }
    var hobbies  by remember { mutableStateOf("") }
    var hometown by remember { mutableStateOf("") }

    var selectedMovie           by remember { mutableStateOf("") }
    var isMovieDropdownExpanded by remember { mutableStateOf(false) }

    // ── Validation errors ─────────────────────────────────────────────────
    var bioError      by remember { mutableStateOf("") }
    var hobbiesError  by remember { mutableStateOf("") }
    var hometownError by remember { mutableStateOf("") }
    var movieError    by remember { mutableStateOf("") }

    // ── Save / loading state ──────────────────────────────────────────────
    var isSaving  by remember { mutableStateOf(false) }
    var saveError by remember { mutableStateOf("") }

    val moviesList = listOf(
        PreferenceItem("Horror"),
        PreferenceItem("Comedy"),
        PreferenceItem("Romance"),
        PreferenceItem("Thriller"),
        PreferenceItem("Action"),
        PreferenceItem("Drama")
    )

    // ── Validation ────────────────────────────────────────────────────────
    fun validate(): Boolean {
        var ok = true

        bioError = when {
            bio.isBlank()           -> { ok = false; "Bio is required" }
            bio.trim().length < 10  -> { ok = false; "Bio must be at least 10 characters" }
            else -> ""
        }
        hobbiesError = when {
            hobbies.isBlank()          -> { ok = false; "Please enter at least one hobby" }
            hobbies.trim().length < 3  -> { ok = false; "Enter a valid hobby" }
            else -> ""
        }
        hometownError = when {
            hometown.isBlank()         -> { ok = false; "Hometown is required" }
            hometown.trim().length < 2 -> { ok = false; "Enter a valid hometown" }
            else -> ""
        }
        movieError = if (selectedMovie.isEmpty()) { ok = false; "Please select a genre" } else ""

        return ok
    }

    // ── UI ────────────────────────────────────────────────────────────────
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.White),
        contentAlignment = Alignment.TopCenter
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 28.dp)
                .padding(top = 48.dp, bottom = 36.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {

            Text(
                "PREFERENCES",
                color = Cyan,
                fontSize = 24.sp,
                fontWeight = FontWeight.Black,
                letterSpacing = (-0.5).sp
            )
            Text(
                "Tell us what you love",
                color = Cyan.copy(alpha = 0.7f),
                fontSize = 13.sp
            )

            // ── Bio ───────────────────────────────────────────────────────
            OutlinedTextField(
                value        = bio,
                onValueChange = { bio = it; bioError = "" },
                label        = { Text("Your bio") },
                placeholder  = { Text("Write something about yourself...") },
                isError      = bioError.isNotEmpty(),
                supportingText = if (bioError.isNotEmpty()) {
                    { Text(bioError, color = MaterialTheme.colorScheme.error, fontSize = 11.sp) }
                } else null,
                modifier    = Modifier.fillMaxWidth(),
                minLines    = 2,
                shape       = RoundedCornerShape(12.dp),
                colors      = prefFieldColors(Cyan, Navy)
            )

            // ── Hobbies ───────────────────────────────────────────────────
            OutlinedTextField(
                value        = hobbies,
                onValueChange = { hobbies = it; hobbiesError = "" },
                label        = { Text("Your hobbies") },
                placeholder  = { Text("e.g. Reading, Hiking, Cooking") },
                isError      = hobbiesError.isNotEmpty(),
                supportingText = if (hobbiesError.isNotEmpty()) {
                    { Text(hobbiesError, color = MaterialTheme.colorScheme.error, fontSize = 11.sp) }
                } else null,
                modifier    = Modifier.fillMaxWidth(),
                singleLine  = true,
                shape       = RoundedCornerShape(12.dp),
                colors      = prefFieldColors(Cyan, Navy)
            )

            // ── Movie genre dropdown ──────────────────────────────────────
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    "Favourite movie genre",
                    color = if (movieError.isNotEmpty()) MaterialTheme.colorScheme.error else Cyan,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold
                )
                Spacer(Modifier.height(6.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Navy)
                        .clickable { isMovieDropdownExpanded = !isMovieDropdownExpanded },
                    contentAlignment = Alignment.CenterStart
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text  = if (selectedMovie.isEmpty()) "Choose a genre" else selectedMovie,
                            color = if (selectedMovie.isEmpty()) Color.Gray else Cyan,
                            fontSize = 14.sp
                        )
                        Text(
                            if (isMovieDropdownExpanded) "▲" else "▼",
                            color = Cyan,
                            fontSize = 11.sp
                        )
                    }
                }

                if (movieError.isNotEmpty()) {
                    Text(
                        movieError,
                        color = MaterialTheme.colorScheme.error,
                        fontSize = 11.sp,
                        modifier = Modifier.padding(start = 4.dp, top = 4.dp)
                    )
                }

                if (isMovieDropdownExpanded) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(bottomStart = 12.dp, bottomEnd = 12.dp))
                            .background(Color(0xFF0D2D55))
                    ) {
                        moviesList.forEachIndexed { index, item ->
                            val isSelected = selectedMovie == item.genre
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(
                                        if (isSelected) Cyan.copy(alpha = 0.12f)
                                        else Color.Transparent
                                    )
                                    .clickable {
                                        selectedMovie = item.genre
                                        movieError = ""
                                        isMovieDropdownExpanded = false
                                    }
                                    .padding(horizontal = 16.dp, vertical = 14.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    item.genre,
                                    color = if (isSelected) Cyan else Color.White,
                                    fontSize = 14.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                )
                                if (isSelected) Text("✓", color = Cyan, fontWeight = FontWeight.Black)
                            }
                            if (index < moviesList.size - 1) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(1.dp)
                                        .background(Cyan.copy(alpha = 0.08f))
                                )
                            }
                        }
                    }
                }
            }

            // ── Hometown ──────────────────────────────────────────────────
            OutlinedTextField(
                value        = hometown,
                onValueChange = { hometown = it; hometownError = "" },
                label        = { Text("Your hometown") },
                placeholder  = { Text("e.g. Mumbai") },
                isError      = hometownError.isNotEmpty(),
                supportingText = if (hometownError.isNotEmpty()) {
                    { Text(hometownError, color = MaterialTheme.colorScheme.error, fontSize = 11.sp) }
                } else null,
                modifier    = Modifier.fillMaxWidth(),
                singleLine  = true,
                shape       = RoundedCornerShape(12.dp),
                colors      = prefFieldColors(Cyan, Navy)
            )

            // ── Save error ────────────────────────────────────────────────
            if (saveError.isNotEmpty()) {
                Text(saveError, color = MaterialTheme.colorScheme.error, fontSize = 13.sp)
            }

            // ── Save button ───────────────────────────────────────────────
            Button(
                onClick = {
                    if (!validate()) return@Button
                    isSaving = true
                    saveError = ""

                    val preferencesData = mapOf(
                        "bio"      to bio.trim(),
                        "hobbies"  to hobbies.trim(),
                        "movies"   to selectedMovie,
                        "hometown" to hometown.trim()
                    )

                    repository.updateFullUserProfile(preferencesData) { success ->
                        isSaving = false
                        if (success) {
                            // Navigate to login so the user can log in fresh and see their profile
                            navController.navigate("login") {
                                popUpTo("signup") { inclusive = true }
                            }
                        } else {
                            saveError = "Failed to save preferences. Please try again."
                        }
                    }
                },
                enabled  = !isSaving,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp),
                shape  = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor         = Cyan,
                    contentColor           = Color.White,
                    disabledContainerColor = Cyan.copy(alpha = 0.4f)
                )
            ) {
                if (isSaving) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(20.dp),
                        color    = Color.White,
                        strokeWidth = 2.dp
                    )
                } else {
                    Text("Save Preferences", fontWeight = FontWeight.Black, fontSize = 15.sp)
                }
            }
        }
    }
}

@Composable
private fun prefFieldColors(cyan: Color, navy: Color) =
    OutlinedTextFieldDefaults.colors(
        focusedBorderColor   = cyan,
        unfocusedBorderColor = cyan.copy(alpha = 0.3f),
        focusedContainerColor   = navy,
        unfocusedContainerColor = navy,
        focusedTextColor    = Color.Black,
        unfocusedTextColor  = Color.Black,
        cursorColor         = cyan,
        focusedLabelColor   = cyan,
        unfocusedLabelColor = cyan.copy(alpha = 0.5f),
        errorBorderColor    = Color.Red,
        errorLabelColor     = Color.Red
    )