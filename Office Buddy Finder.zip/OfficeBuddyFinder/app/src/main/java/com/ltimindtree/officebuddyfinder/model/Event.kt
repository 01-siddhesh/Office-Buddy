package com.ltimindtree.officebuddyfinder.model

data class Event(
    val id: Int,
    val title: String,
    val time: String,
    val location: String,
    val category: String,
    val attendees: List<String>,
    val imageUrl: String = "",
    val isJoined: Boolean = false
)