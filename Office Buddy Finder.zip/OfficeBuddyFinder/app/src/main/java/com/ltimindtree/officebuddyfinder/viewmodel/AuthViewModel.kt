package com.ltimindtree.officebuddyfinder.viewmodel

import androidx.lifecycle.ViewModel
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.ltimindtree.officebuddyfinder.repository.FirebaseRepository

class AuthViewModel : ViewModel(){
    private val auth = FirebaseAuth.getInstance()
    private val repo = FirebaseRepository()
    private val db = FirebaseFirestore.getInstance()
    
    fun signup(
        email : String,
        password: String,
        name: String,
        department: String,
        onResult: (Boolean, String?) -> Unit
    ){
        auth.createUserWithEmailAndPassword(email,password)
            .addOnCompleteListener { task ->
                if (task.isSuccessful){
                    val user = auth.currentUser
                    val userId = user?.uid
                    
                    if (userId != null) {
                        saveUser(userId, name, department, email)
                        
                        // Sending verification email
                        user.sendEmailVerification()
                            .addOnCompleteListener { verificationTask ->
                                if (verificationTask.isSuccessful) {
                                    onResult(true, "Verification email sent to $email")
                                } else {
                                     onResult(true, "Account created, but failed to send verification email.")
                                }
                            }
                    } else {
                        onResult(true, null)
                    }

                } else{
                    onResult(false,task.exception?.message)
                }
            }
    }
    
    fun login(
        email : String,
        password: String,
        onResult: (Boolean, String?) -> Unit
    ){
        repo.login(email,password,onResult)
    }
    
    fun saveUser(userId: String, name: String, department: String, email: String){
        val user = hashMapOf(
            "name" to name,
            "department" to department,
            "email" to email
        )
        db.collection("users")
            .document(userId)
            .set(user)
    }

}