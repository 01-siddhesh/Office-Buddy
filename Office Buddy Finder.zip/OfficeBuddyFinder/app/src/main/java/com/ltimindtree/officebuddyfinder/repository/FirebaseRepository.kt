package com.ltimindtree.officebuddyfinder.repository

import android.util.Log
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.ltimindtree.officebuddyfinder.model.ConnectionRequest
import com.ltimindtree.officebuddyfinder.model.User

class FirebaseRepository {
    private val auth = FirebaseAuth.getInstance()
    private val db = FirebaseFirestore.getInstance()

    fun signup(
        email: String,
        password: String,
        name: String,
        department: String,
        onResult: (Boolean, String?) -> Unit
    ) {
        auth.createUserWithEmailAndPassword(email, password).addOnCompleteListener { task ->
            if (task.isSuccessful) {
                val userId = auth.currentUser?.uid
                if (userId != null) {
                    saveUser(userId, name, department, email)
                }
                onResult(true, null)
            } else {
                onResult(false, task.exception?.message)
            }
        }
    }

    fun login(
        email: String,
        password: String,
        onResult: (Boolean, String?) -> Unit
    ) {
        auth.signInWithEmailAndPassword(email, password).addOnCompleteListener { task ->
            if (task.isSuccessful) {
                onResult(true, null)
            } else {
                onResult(false, task.exception?.message)
            }
        }
    }

    fun saveUser(
        userId: String,
        name: String,
        department: String,
        email: String? = null
    ) {
        val user = mutableMapOf(
            "name" to name,
            "department" to department
        )
        if (email != null) user["email"] = email
        db.collection("users").document(userId).set(user)
    }

    fun getAllUsers(onResult: (List<User>) -> Unit) {
        db.collection("users")
            .get()
            .addOnSuccessListener { result ->
                val userlist = mutableListOf<User>()
                for (document in result) {
                    val user = User(
                        id = document.id,
                        name = document.getString("name") ?: "",
                        department = document.getString("department") ?: "",
                        bio = document.getString("bio") ?: "",
                        hobbies = document.getString("hobbies") ?: "",
                        movies = document.getString("movies") ?: "",
                        hometown = document.getString("hometown") ?: ""
                    )
                    userlist.add(user)
                }
                onResult(userlist)
            }
    }

    fun sendBuddyRequest(
        senderId: String,
        receiverId: String,
        onResult: (Boolean) -> Unit
    ) {
        if (senderId.isBlank() || receiverId.isBlank()) {
            onResult(false)
            return
        }
        val request = hashMapOf(
            "senderId" to senderId,
            "receiverId" to receiverId,
            "status" to "pending"
        )
        db.collection("buddyRequests")
            .add(request)
            .addOnSuccessListener { onResult(true) }
            .addOnFailureListener { e ->
                Log.e("FirebaseRepo", "Error sending request: ${e.message}")
                onResult(false)
            }
    }

    fun getPendingRequests(userId: String, onResult: (List<ConnectionRequest>) -> Unit) {
        db.collection("buddyRequests")
            .whereEqualTo("receiverId", userId)
            .whereEqualTo("status", "pending")
            .get()
            .addOnSuccessListener { result ->
                val requestList = mutableListOf<ConnectionRequest>()
                var processedCount = 0

                if (result.isEmpty) {
                    onResult(emptyList())
                    return@addOnSuccessListener
                }

                for (document in result) {
                    val senderId = document.getString("senderId") ?: ""
                    val requestId = document.id

                    db.collection("users").document(senderId).get()
                        .addOnSuccessListener { userDoc ->
                            val name = userDoc.getString("name") ?: "Unknown"
                            val dept = userDoc.getString("department") ?: ""
                            val email = userDoc.getString("email") ?: ""
                            requestList.add(ConnectionRequest(requestId, name, dept, email))
                            processedCount++
                            if (processedCount == result.size()) onResult(requestList)
                        }
                        .addOnFailureListener { e ->
                            Log.e("FirebaseRepo", "Error fetching user details: ${e.message}")
                            processedCount++
                            if (processedCount == result.size()) onResult(requestList)
                        }
                }
            }
            .addOnFailureListener { e ->
                Log.e("FirebaseRepo", "Error fetching requests: ${e.message}")
                onResult(emptyList())
            }
    }

    fun updateRequestStatus(requestId: String, status: String, onResult: (Boolean) -> Unit) {
        Log.d("FirebaseRepo", "Updating request $requestId to $status")
        db.collection("buddyRequests").document(requestId)
            .get()
            .addOnSuccessListener { requestDoc ->
                val senderId   = requestDoc.getString("senderId") ?: ""
                val receiverId = requestDoc.getString("receiverId") ?: ""

                requestDoc.reference.update("status", status)
                    .addOnSuccessListener {
                        Log.d("FirebaseRepo", "Status updated successfully")
                        if (status == "accepted" && senderId.isNotBlank() && receiverId.isNotBlank()) {
                            incrementFriendsCount(senderId)
                            incrementFriendsCount(receiverId)
                        }
                        onResult(true)
                    }
                    .addOnFailureListener { e ->
                        Log.e("FirebaseRepo", "Update FAILED: ${e.message}")
                        onResult(false)
                    }
            }
            .addOnFailureListener { e ->
                Log.e("FirebaseRepo", "Failed to fetch request doc: ${e.message}")
                onResult(false)
            }
    }

    private fun incrementFriendsCount(userId: String) {
        val ref = db.collection("users").document(userId)
        db.runTransaction { tx ->
            val snap  = tx.get(ref)
            val count = (snap.getLong("friendsCount") ?: 0L) + 1L
            tx.update(ref, "friendsCount", count)
        }.addOnFailureListener { e ->
            Log.e("FirebaseRepo", "friendsCount increment failed for $userId: ${e.message}")
        }
    }

    fun getCurrentUserDetails(onResult: (Map<String, Any>?) -> Unit) {
        val userId = auth.currentUser?.uid
        if (userId != null) {
            getUserDetails(userId, onResult)
        } else {
            onResult(null)
        }
    }

    fun getUserDetails(userId: String, onResult: (Map<String, Any>?) -> Unit) {
        db.collection("users").document(userId).get()
            .addOnSuccessListener { document -> onResult(document.data) }
            .addOnFailureListener { onResult(null) }
    }

    fun updateFullUserProfile(data: Map<String, Any>, onResult: (Boolean) -> Unit) {
        val userId = auth.currentUser?.uid
        if (userId != null) {
            db.collection("users").document(userId)
                .set(data, com.google.firebase.firestore.SetOptions.merge())
                .addOnSuccessListener { onResult(true) }
                .addOnFailureListener { onResult(false) }
        }
    }

    // ─────────────────────────────────────────────────────────────
    // TRAVEL TRIPS
    // ─────────────────────────────────────────────────────────────

    /**
     * Posts a new trip to Firestore.
     * Fields stored: creatorId, creatorName, from, to, date, transport, seats, description
     * memberIds is initialised with just the creator's uid.
     */
    fun addTrip(
        creatorName : String,
        from        : String,
        to          : String,
        date        : String,
        transport   : String,
        seats       : Int,
        description : String,
        onResult    : (Boolean) -> Unit
    ) {
        val userId = auth.currentUser?.uid ?: return onResult(false)
        val trip = hashMapOf(
            "creatorId"   to userId,
            "creatorName" to creatorName,
            "from"        to from,
            "to"          to to,
            "date"        to date,
            "transport"   to transport,
            "seats"       to seats,
            "description" to description,
            "memberIds"   to listOf(userId),
            "createdAt"   to com.google.firebase.firestore.FieldValue.serverTimestamp()
        )
        db.collection("trips").add(trip)
            .addOnSuccessListener { onResult(true) }
            .addOnFailureListener { e ->
                Log.e("FirebaseRepo", "Add trip failed: ${e.message}")
                onResult(false)
            }
    }

    /**
     * Real-time listener on the trips collection, ordered newest first.
     * Returns a ListenerRegistration — call .remove() on dispose.
     */
    fun listenToTrips(
        onUpdate: (List<Map<String, Any?>>) -> Unit
    ): com.google.firebase.firestore.ListenerRegistration {
        return db.collection("trips")
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.e("FirebaseRepo", "Trips listener error: ${error.message}")
                    return@addSnapshotListener
                }
                val list = snapshot?.documents?.map { doc ->
                    val data = doc.data?.toMutableMap() ?: mutableMapOf()
                    data["id"] = doc.id
                    data as Map<String, Any?>
                } ?: emptyList()
                onUpdate(list)
            }
    }

    /**
     * Adds the current user's uid to a trip's memberIds list and decrements seats by 1.
     * Uses a transaction so concurrent joins don't oversell seats.
     */
    fun joinTrip(tripId: String, onResult: (Boolean) -> Unit) {
        val userId = auth.currentUser?.uid ?: return onResult(false)
        val ref = db.collection("trips").document(tripId)

        db.runTransaction { tx ->
            val snap    = tx.get(ref)
            val seats   = (snap.getLong("seats") ?: 0L).toInt()
            val members = snap.get("memberIds") as? List<*> ?: emptyList<String>()

            if (seats <= 0)               throw Exception("No seats left")
            if (members.contains(userId)) throw Exception("Already joined")

            tx.update(ref, mapOf(
                "seats"     to seats - 1,
                "memberIds" to members + userId
            ))
        }
            .addOnSuccessListener { onResult(true) }
            .addOnFailureListener { e ->
                Log.e("FirebaseRepo", "Join trip failed: ${e.message}")
                onResult(false)
            }
    }
}