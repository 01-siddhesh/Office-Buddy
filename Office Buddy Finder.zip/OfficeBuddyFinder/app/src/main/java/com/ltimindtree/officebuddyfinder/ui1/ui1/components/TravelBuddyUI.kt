package com.ltimindtree.officebuddyfinder.ui1.ui1.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.google.firebase.auth.FirebaseAuth
import com.ltimindtree.officebuddyfinder.repository.FirebaseRepository
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter

// ── Simple model parsed from Firestore map ────────────────────────────────────
data class TripItem(
    val id          : String,
    val creatorId   : String,
    val creatorName : String,
    val from        : String,
    val to          : String,
    val date        : String,
    val transport   : String,
    val seats       : Int,
    val description : String,
    val memberIds   : List<String>
)

private fun Map<String, Any?>.toTripItem() = TripItem(
    id          = this["id"]?.toString() ?: "",
    creatorId   = this["creatorId"]?.toString() ?: "",
    creatorName = this["creatorName"]?.toString() ?: "",
    from        = this["from"]?.toString() ?: "",
    to          = this["to"]?.toString() ?: "",
    date        = this["date"]?.toString() ?: "",
    transport   = this["transport"]?.toString() ?: "",
    seats       = (this["seats"] as? Long)?.toInt() ?: 0,
    description = this["description"]?.toString() ?: "",
    memberIds   = (this["memberIds"] as? List<*>)?.map { it.toString() } ?: emptyList()
)

// ── Nav host — single nav stack for this feature ─────────────────────────────
@Composable
fun TravelBuddyNavHost(rootNavController: NavController) {
    val repository    = remember { FirebaseRepository() }
    val currentUserId = FirebaseAuth.getInstance().currentUser?.uid ?: ""

    var trips     by remember { mutableStateOf(listOf<TripItem>()) }
    var isLoading by remember { mutableStateOf(true) }
    var showForm  by remember { mutableStateOf(false) }

    // Real-time Firestore listener
    DisposableEffect(Unit) {
        val reg = repository.listenToTrips { rawList ->
            trips     = rawList.map { it.toTripItem() }
            isLoading = false
        }
        onDispose { reg.remove() }
    }

    if (showForm) {
        PostTripScreen(
            repository = repository,
            onBack     = { showForm = false },
            onPosted   = { showForm = false }
        )
    } else {
        TripListScreen(
            trips         = trips,
            isLoading     = isLoading,
            currentUserId = currentUserId,
            repository    = repository,
            onBack        = { rootNavController.popBackStack() },
            onPostTrip    = { showForm = true }
        )
    }
}

// ── Trip list screen ──────────────────────────────────────────────────────────
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun TripListScreen(
    trips         : List<TripItem>,
    isLoading     : Boolean,
    currentUserId : String,
    repository    : FirebaseRepository,
    onBack        : () -> Unit,
    onPostTrip    : () -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Travel Buddy", fontWeight = FontWeight.Bold, color = Color.White) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Teal)
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick        = onPostTrip,
                containerColor = Teal,
                contentColor   = Color.White
            ) {
                Icon(Icons.Default.Add, contentDescription = "Post a trip")
            }
        }
    ) { innerPadding ->
        when {
            isLoading -> {
                Box(
                    modifier         = Modifier.fillMaxSize().padding(innerPadding),
                    contentAlignment = Alignment.Center
                ) { CircularProgressIndicator(color = Teal) }
            }

            trips.isEmpty() -> {
                Box(
                    modifier         = Modifier.fillMaxSize().padding(innerPadding),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        "No trips posted yet.\nTap + to plan one!",
                        color     = Color.Gray,
                        fontSize  = 15.sp,
                        textAlign = TextAlign.Center
                    )
                }
            }

            else -> {
                LazyColumn(
                    modifier       = Modifier.fillMaxSize().padding(innerPadding),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(trips, key = { it.id }) { trip ->
                        TripCard(
                            trip          = trip,
                            currentUserId = currentUserId,
                            onJoin        = { repository.joinTrip(trip.id) {} }
                        )
                    }
                }
            }
        }
    }
}

// ── Single trip card ──────────────────────────────────────────────────────────
@Composable
private fun TripCard(
    trip          : TripItem,
    currentUserId : String,
    onJoin        : () -> Unit
) {
    val alreadyJoined = trip.memberIds.contains(currentUserId)
    val isCreator     = trip.creatorId == currentUserId
    val isFull        = trip.seats <= 0

    Card(
        modifier  = Modifier.fillMaxWidth(),
        shape     = RoundedCornerShape(12.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        colors    = CardDefaults.cardColors(containerColor = Color.White)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {

            // Route
            Text(
                "${trip.from}  →  ${trip.to}",
                fontWeight = FontWeight.Bold,
                fontSize   = 17.sp
            )

            Spacer(Modifier.height(8.dp))
            HorizontalDivider(color = Color(0xFFEEEEEE))
            Spacer(Modifier.height(8.dp))

            // Date
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.DateRange, contentDescription = null, tint = Teal, modifier = Modifier.size(15.dp))
                Spacer(Modifier.width(6.dp))
                Text(trip.date, fontSize = 13.sp, color = Color.DarkGray)

                Spacer(Modifier.width(16.dp))

                // Transport
                Text("✦ ${trip.transport}", fontSize = 13.sp, color = Color.DarkGray)
            }

            Spacer(Modifier.height(4.dp))

            // Seats + creator
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Person, contentDescription = null, tint = Teal, modifier = Modifier.size(15.dp))
                Spacer(Modifier.width(6.dp))
                Text(
                    if (isFull) "Full" else "${trip.seats} seat${if (trip.seats == 1) "" else "s"} left",
                    fontSize = 13.sp,
                    color    = if (isFull) Color.Red else Color.DarkGray
                )
                Spacer(Modifier.width(16.dp))
                Text("by ${trip.creatorName}", fontSize = 12.sp, color = Color.Gray)
            }

            // Description
            if (trip.description.isNotBlank()) {
                Spacer(Modifier.height(8.dp))
                Text(trip.description, fontSize = 13.sp, color = Color.Gray)
            }

            // Join button — hidden for creator, shows joined state otherwise
            if (!isCreator) {
                Spacer(Modifier.height(12.dp))
                Button(
                    onClick  = onJoin,
                    enabled  = !alreadyJoined && !isFull,
                    modifier = Modifier.fillMaxWidth(),
                    shape    = RoundedCornerShape(8.dp),
                    colors   = ButtonDefaults.buttonColors(
                        containerColor         = Teal,
                        disabledContainerColor = Color(0xFFBDBDBD)
                    )
                ) {
                    Text(
                        when {
                            alreadyJoined -> "Joined"
                            isFull        -> "Trip Full"
                            else          -> "Join Trip"
                        },
                        color = Color.White,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }
    }
}

// ── Post trip form ────────────────────────────────────────────────────────────
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun PostTripScreen(
    repository : FirebaseRepository,
    onBack     : () -> Unit,
    onPosted   : () -> Unit
) {
    var creatorName  by remember { mutableStateOf("") }
    var from         by remember { mutableStateOf("") }
    var to           by remember { mutableStateOf("") }
    var transport    by remember { mutableStateOf("") }
    var seats        by remember { mutableStateOf("") }
    var description  by remember { mutableStateOf("") }
    var isSaving     by remember { mutableStateOf(false) }

    // Date picker
    var showDatePicker  by remember { mutableStateOf(false) }
    val datePickerState = rememberDatePickerState()
    val selectedDate    = datePickerState.selectedDateMillis?.let { millis ->
        Instant.ofEpochMilli(millis)
            .atZone(ZoneId.systemDefault())
            .toLocalDate()
            .format(DateTimeFormatter.ofPattern("dd MMM yyyy"))
    } ?: ""

    // Validation errors
    var nameErr      by remember { mutableStateOf("") }
    var fromErr      by remember { mutableStateOf("") }
    var toErr        by remember { mutableStateOf("") }
    var transportErr by remember { mutableStateOf("") }
    var seatsErr     by remember { mutableStateOf("") }
    var dateErr      by remember { mutableStateOf("") }

    fun validate(): Boolean {
        var ok = true
        nameErr = when {
            creatorName.isBlank()           -> { ok = false; "Required" }
            creatorName.trim().length < 2   -> { ok = false; "Too short" }
            else -> ""
        }
        fromErr = when {
            from.isBlank()                  -> { ok = false; "Required" }
            from.trim().length < 2          -> { ok = false; "Too short" }
            else -> ""
        }
        toErr = when {
            to.isBlank()                    -> { ok = false; "Required" }
            to.trim().equals(from.trim(), ignoreCase = true) -> { ok = false; "Same as origin" }
            else -> ""
        }
        transportErr = if (transport.isBlank()) { ok = false; "Required" } else ""
        dateErr      = if (selectedDate.isBlank()) { ok = false; "Required" } else ""
        val s = seats.toIntOrNull()
        seatsErr = when {
            seats.isBlank() -> { ok = false; "Required" }
            s == null       -> { ok = false; "Must be a number" }
            s <= 0          -> { ok = false; "At least 1" }
            s > 50          -> { ok = false; "Max 50" }
            else -> ""
        }
        return ok
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Post a Trip", fontWeight = FontWeight.Bold, color = Color.White) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Teal)
            )
        }
    ) { innerPadding ->

        val fieldColors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor   = Teal,
            unfocusedBorderColor = Color.LightGray
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {

            // Your name
            OutlinedTextField(
                value          = creatorName,
                onValueChange  = { creatorName = it; nameErr = "" },
                label          = { Text("Your Name") },
                isError        = nameErr.isNotEmpty(),
                supportingText = if (nameErr.isNotEmpty()) {{ Text(nameErr) }} else null,
                modifier       = Modifier.fillMaxWidth(),
                singleLine     = true,
                shape          = RoundedCornerShape(10.dp),
                colors         = fieldColors
            )

            // From
            OutlinedTextField(
                value          = from,
                onValueChange  = { from = it; fromErr = "" },
                label          = { Text("From") },
                placeholder    = { Text("e.g. Bangalore") },
                isError        = fromErr.isNotEmpty(),
                supportingText = if (fromErr.isNotEmpty()) {{ Text(fromErr) }} else null,
                modifier       = Modifier.fillMaxWidth(),
                singleLine     = true,
                shape          = RoundedCornerShape(10.dp),
                colors         = fieldColors
            )

            // To
            OutlinedTextField(
                value          = to,
                onValueChange  = { to = it; toErr = "" },
                label          = { Text("To") },
                placeholder    = { Text("e.g. Mumbai") },
                isError        = toErr.isNotEmpty(),
                supportingText = if (toErr.isNotEmpty()) {{ Text(toErr) }} else null,
                modifier       = Modifier.fillMaxWidth(),
                singleLine     = true,
                shape          = RoundedCornerShape(10.dp),
                colors         = fieldColors
            )

            // Date picker trigger
            OutlinedTextField(
                value          = selectedDate,
                onValueChange  = {},
                readOnly       = true,
                label          = { Text("Travel Date") },
                placeholder    = { Text("Select a date") },
                isError        = dateErr.isNotEmpty(),
                supportingText = if (dateErr.isNotEmpty()) {{ Text(dateErr) }} else null,
                trailingIcon   = {
                    IconButton(onClick = { showDatePicker = true }) {
                        Icon(Icons.Default.DateRange, contentDescription = "Pick date", tint = Teal)
                    }
                },
                modifier   = Modifier.fillMaxWidth(),
                singleLine = true,
                shape      = RoundedCornerShape(10.dp),
                colors     = fieldColors
            )

            // Transport
            OutlinedTextField(
                value          = transport,
                onValueChange  = { transport = it; transportErr = "" },
                label          = { Text("Mode of Transport") },
                placeholder    = { Text("e.g. Train, Car, Bus, Flight") },
                isError        = transportErr.isNotEmpty(),
                supportingText = if (transportErr.isNotEmpty()) {{ Text(transportErr) }} else null,
                modifier       = Modifier.fillMaxWidth(),
                singleLine     = true,
                shape          = RoundedCornerShape(10.dp),
                colors         = fieldColors
            )

            // Seats
            OutlinedTextField(
                value          = seats,
                onValueChange  = { if (it.all { c -> c.isDigit() } && it.length <= 2) { seats = it; seatsErr = "" } },
                label          = { Text("Available Seats") },
                placeholder    = { Text("e.g. 3") },
                isError        = seatsErr.isNotEmpty(),
                supportingText = if (seatsErr.isNotEmpty()) {{ Text(seatsErr) }} else null,
                modifier       = Modifier.fillMaxWidth(),
                singleLine     = true,
                shape          = RoundedCornerShape(10.dp),
                colors         = fieldColors
            )

            // Description (optional)
            OutlinedTextField(
                value         = description,
                onValueChange = { description = it },
                label         = { Text("Description (optional)") },
                placeholder   = { Text("Any details about the trip...") },
                modifier      = Modifier.fillMaxWidth().height(110.dp),
                shape         = RoundedCornerShape(10.dp),
                colors        = fieldColors
            )

            Spacer(Modifier.height(4.dp))

            // Post button
            Button(
                onClick = {
                    if (!validate()) return@Button
                    isSaving = true
                    repository.addTrip(
                        creatorName = creatorName.trim(),
                        from        = from.trim(),
                        to          = to.trim(),
                        date        = selectedDate,
                        transport   = transport.trim(),
                        seats       = seats.toInt(),
                        description = description.trim(),
                        onResult    = { success ->
                            isSaving = false
                            if (success) onPosted()
                        }
                    )
                },
                enabled  = !isSaving,
                modifier = Modifier.fillMaxWidth().height(52.dp),
                shape    = RoundedCornerShape(12.dp),
                colors   = ButtonDefaults.buttonColors(containerColor = Teal)
            ) {
                if (isSaving) {
                    CircularProgressIndicator(modifier = Modifier.size(20.dp), color = Color.White, strokeWidth = 2.dp)
                } else {
                    Text("Post Trip", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = Color.White)
                }
            }
        }
    }

    if (showDatePicker) {
        DatePickerDialog(
            onDismissRequest = { showDatePicker = false },
            confirmButton = {
                TextButton(onClick = { showDatePicker = false; dateErr = "" }) {
                    Text("OK", color = Teal)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDatePicker = false }) { Text("Cancel") }
            }
        ) {
            DatePicker(state = datePickerState)
        }
    }
}