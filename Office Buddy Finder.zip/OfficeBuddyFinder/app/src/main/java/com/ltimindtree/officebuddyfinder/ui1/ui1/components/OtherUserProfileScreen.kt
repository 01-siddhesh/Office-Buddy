package com.ltimindtree.officebuddyfinder.ui1.ui1.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.ltimindtree.officebuddyfinder.repository.FirebaseRepository

@Composable
fun OtherUserProfileScreen(navController: NavController, userId: String) {
    val repository = remember { FirebaseRepository() }

    var name     by remember { mutableStateOf("Loading...") }
    var job      by remember { mutableStateOf("...") }
    var bio      by remember { mutableStateOf("") }
    var hobbies  by remember { mutableStateOf("") }
    var movies   by remember { mutableStateOf("") }
    var hometown by remember { mutableStateOf("") }

    // NEW: friends count from Firestore
    var friendsCount by remember { mutableStateOf(0L) }

    LaunchedEffect(userId) {
        repository.getUserDetails(userId) { data ->
            if (data != null) {
                name         = data["name"]?.toString() ?: "Unknown"
                job          = data["department"]?.toString() ?: "No Department"
                bio          = data["bio"]?.toString() ?: "No bio available"
                hobbies      = data["hobbies"]?.toString() ?: "None listed"
                movies       = data["movies"]?.toString() ?: "None listed"
                hometown     = data["hometown"]?.toString() ?: "Not specified"
                // Read friendsCount; defaults to 0 if field doesn't exist yet
                friendsCount = (data["friendsCount"] as? Long) ?: 0L
            }
        }
    }

    Scaffold(
        topBar = {
            Surface(tonalElevation = 3.dp) {
                Row(
                    modifier = Modifier.statusBarsPadding().padding(8.dp).fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                    Text("Buddy Profile", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier.padding(innerPadding).fillMaxSize(),
            contentPadding = PaddingValues(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            item {
                Box(modifier = Modifier.padding(bottom = 8.dp)) {
                    Box(modifier = Modifier.size(120.dp).clip(CircleShape).background(Color.LightGray), contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.AccountCircle, null, Modifier.size(90.dp), tint = Color.Gray)
                    }
                }

                // Friends count badge
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = Teal.copy(alpha = 0.12f),
                    modifier = Modifier.padding(bottom = 16.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Person, contentDescription = null, tint = Teal, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text(
                            "$friendsCount ${if (friendsCount == 1L) "Friend" else "Friends"}",
                            color = Teal,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }

                Text(name, fontSize = 26.sp, fontWeight = FontWeight.Bold)
                Text(job, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(bottom = 24.dp))

                DetailItem("Bio",        bio)
                DetailItem("Department", job)
                DetailItem("Hobbies",    hobbies)
                DetailItem("Movies",     movies)
                DetailItem("Hometown",   hometown)

                Spacer(Modifier.size(32.dp))

//                Button(
//                    onClick = { /* Add Send Request Logic Here */ },
//                    modifier = Modifier.fillMaxWidth()
//                ) {
//                    Text("Send Buddy Request")
//                }
            }
        }
    }
}