package com.ltimindtree.officebuddyfinder.viewmodel

import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import com.google.firebase.auth.FirebaseAuth
import com.ltimindtree.officebuddyfinder.model.ConnectionRequest
import com.ltimindtree.officebuddyfinder.repository.FirebaseRepository

class RequestViewModel : ViewModel() {
    private val repo = FirebaseRepository()
    private val auth = FirebaseAuth.getInstance()

    val requests     = mutableStateListOf<ConnectionRequest>()
    var isLoading    = mutableStateOf(false)

    // True when a request was accepted in this session — drives "New Friend!" button label
    var hasNewFriend = mutableStateOf(false)

    fun fetchRequests() {
        val userId = auth.currentUser?.uid ?: return
        isLoading.value = true
        repo.getPendingRequests(userId) { fetchedRequests ->
            requests.clear()
            requests.addAll(fetchedRequests)
            isLoading.value = false
        }
    }

    fun acceptRequest(requestId: String, onResult: (Boolean) -> Unit) {
        repo.updateRequestStatus(requestId, "accepted") { success ->
            if (success) {
                val index = requests.indexOfFirst { it.id == requestId }
                if (index != -1) {
                    requests[index] = requests[index].copy(isAccepted = true)
                }
                // Mark that a new friend was made — HomeScreen will show "New Friend!"
                hasNewFriend.value = true
            }
            onResult(success)
        }
    }

    fun denyRequest(requestId: String, onResult: (Boolean) -> Unit) {
        repo.updateRequestStatus(requestId, "denied") { success ->
            if (success) {
                requests.removeAll { it.id == requestId }
            }
            onResult(success)
        }
    }

    // Called by HomeScreen once the user taps the Friends button — clears the badge
    fun clearNewFriendFlag() {
        hasNewFriend.value = false
    }
}