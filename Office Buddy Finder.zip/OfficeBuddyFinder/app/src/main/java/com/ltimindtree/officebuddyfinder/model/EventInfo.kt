package com.ltimindtree.officebuddyfinder.model

data class EventInfo(
    val eventName: String,
    val hostName: String,
    val dateMillis: Long,
    val location: String,
    val memberCount: String
)