package com.ltimindtree.officebuddyfinder.ui1.ui1.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AddCircle
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.ExitToApp
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Place
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.google.firebase.auth.FirebaseAuth
import com.ltimindtree.officebuddyfinder.R
import com.ltimindtree.officebuddyfinder.model.User
import com.ltimindtree.officebuddyfinder.viewmodel.BuddyViewModel
import com.ltimindtree.officebuddyfinder.viewmodel.RequestViewModel
import kotlinx.coroutines.launch

@Composable
fun HomeScreen(navController: NavController) {
    val viewModel        : BuddyViewModel   = viewModel()
    val requestViewModel : RequestViewModel = viewModel()
    val auth             = FirebaseAuth.getInstance()
    val drawerState      = rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope            = rememberCoroutineScope()

    var userList by remember { mutableStateOf(listOf<User>()) }
    val currentUserId = auth.currentUser?.uid ?: ""

    // Observe the "New Friend" flag from RequestViewModel
    val hasNewFriend by requestViewModel.hasNewFriend

    LaunchedEffect(Unit) {
        viewModel.getAllUsers { users -> userList = users }
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet(modifier = Modifier.width(300.dp)) {
                Text("Menu", modifier = Modifier.padding(16.dp), fontSize = 24.sp, fontWeight = FontWeight.Bold)
                HorizontalDivider()

                NavigationDrawerItem(
                    label    = { Text("Events") },
                    selected = false,
                    icon     = { Icon(Icons.Default.DateRange, contentDescription = null) },
                    onClick  = { navController.navigate("events") }
                )
                NavigationDrawerItem(
                    label    = { Text("Travel Buddy") },
                    selected = false,
                    icon     = { Icon(Icons.Default.Place, contentDescription = null) },
                    onClick  = { navController.navigate("travel") }
                )
                NavigationDrawerItem(
                    label    = { Text("Profile") },
                    selected = false,
                    icon     = { Icon(Icons.Default.AccountCircle, contentDescription = null) },
                    onClick  = {
                        scope.launch { drawerState.close() }
                        navController.navigate("profile/{name}/{department}")
                    }
                )
                NavigationDrawerItem(
                    label    = { Text("Requests") },
                    selected = false,
                    icon     = { Icon(Icons.Default.AddCircle, contentDescription = null) },
                    onClick  = {
                        scope.launch { drawerState.close() }
                        navController.navigate("requests")
                    }
                )
                Spacer(Modifier.weight(1f))
                NavigationDrawerItem(
                    label    = { Text("Logout", color = Color.Red) },
                    selected = false,
                    icon     = { Icon(Icons.Default.ExitToApp, contentDescription = null, tint = Color.Red) },
                    onClick  = {
                        auth.signOut()
                        navController.navigate("login") {
                            popUpTo("home") { inclusive = true }
                        }
                    }
                )
            }
        }
    ) {
        Scaffold(
            topBar = {
                Surface(
                    modifier      = Modifier.fillMaxWidth(),
                    color         = Teal,
                    tonalElevation = 3.dp
                ) {
                    Row(
                        modifier = Modifier
                            .statusBarsPadding()
                            .padding(horizontal = 16.dp, vertical = 12.dp)
                            .fillMaxWidth(),
                        verticalAlignment    = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        // Left: logo + app name
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Image(
                                painter            = painterResource(R.drawable.outline_handshake_24),
                                contentDescription = "logo",
                                modifier           = Modifier.size(25.dp)
                            )
                            Spacer(Modifier.width(12.dp))
                            Text("WorkBond", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Color.White)
                        }

                        // Right: Friends button + Menu icon
                        Row(verticalAlignment = Alignment.CenterVertically) {

                            // Friends text button — shows "New Friend!" when hasNewFriend is true
                            TextButton(
                                onClick = {
                                    requestViewModel.clearNewFriendFlag()
                                    navController.navigate("friends")
                                },
                                colors = ButtonDefaults.textButtonColors(
                                    contentColor = Color.White
                                )
                            ) {
                                if (hasNewFriend) {
                                    // Pulsing green dot to draw attention
                                    Box(
                                        modifier = Modifier
                                            .size(8.dp)
                                            .clip(CircleShape)
                                            .background(Color(0xFF4CAF50))
                                    )
                                    Spacer(Modifier.width(6.dp))
                                    Text(
                                        "New Friend!",
                                        fontSize   = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        color      = Color(0xFF4CAF50)
                                    )
                                } else {
                                    Text(
                                        "Friends",
                                        fontSize   = 13.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color      = Color.White
                                    )
                                }
                            }

                            IconButton(onClick = { scope.launch { drawerState.open() } }) {
                                Icon(Icons.Default.Menu, contentDescription = "Menu", tint = Color.White)
                            }
                        }
                    }
                }
            }
        ) { innerPadding ->
            Column(modifier = Modifier.padding(innerPadding).fillMaxSize()) {
                Text(
                    "Recommended for you",
                    modifier   = Modifier.padding(16.dp),
                    fontSize   = 20.sp,
                    fontWeight = FontWeight.Bold
                )
                LazyColumn(
                    modifier       = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(bottom = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(userList) { user ->
                        if (user.id != currentUserId) {
                            UserListItem(
                                user           = user,
                                onConnectClick = {
                                    if (currentUserId.isNotBlank()) {
                                        viewModel.sendRequest(
                                            senderId   = currentUserId,
                                            receiverId = user.id
                                        ) { success ->
                                            if (success) println("Request Sent")
                                            else println("Request Failed")
                                        }
                                    }
                                },
                                onClick        = {
                                    navController.navigate("profile/${user.name}/${user.department}")
                                },
                                navController  = navController
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun UserListItem(user: User, onConnectClick: () -> Unit, onClick: () -> Unit, navController: NavController) {
    ElevatedCard(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
            .background(Color.White),
        shape   = RoundedCornerShape(12.dp),
        onClick = { navController.navigate("other_profile/${user.id}") }
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(60.dp)
                    .clip(CircleShape)
                    .background(Color.LightGray),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    Icons.Default.AccountCircle,
                    contentDescription = "profile pic",
                    modifier = Modifier.size(40.dp),
                    tint     = Color.Gray
                )
            }

            Spacer(modifier = Modifier.width(16.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(text = user.name,       fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Text(text = user.department, fontSize   = 14.sp,          color    = Color.DarkGray)
            }

            IconButton(onClick = onConnectClick) {
                Icon(imageVector = Icons.Default.Add, contentDescription = "Connect")
            }
        }
    }
}