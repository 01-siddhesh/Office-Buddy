package com.ltimindtree.officebuddyfinder.viewmodel

import androidx.lifecycle.ViewModel
import com.ltimindtree.officebuddyfinder.model.User
import com.ltimindtree.officebuddyfinder.repository.FirebaseRepository
//import com.ltimindtree.officebuddyfinder.ui1.ui1.components.User

class BuddyViewModel : ViewModel(){
    private val repo = FirebaseRepository()
    fun getAllUsers(onResult: (List<User>) -> Unit){
        repo.getAllUsers(onResult)
    }
    fun sendRequest(senderId: String, receiverId: String, onResult: (Boolean)-> Unit){
        repo.sendBuddyRequest(senderId,receiverId,onResult)
    }
}