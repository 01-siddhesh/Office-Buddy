package com.ltimindtree.officebuddyfinder.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.*
import androidx.navigation.navArgument
import com.ltimindtree.officebuddyfinder.ui1.ui1.components.*

@Composable
fun NavGraph(navController: NavHostController) {
    NavHost(navController = navController, startDestination = "splash") {
        composable("splash") {
            SplashScreen(navController)
        }
        composable("login") {
            LoginScreen(navController)
        }
        composable("home") {
            HomeScreen(navController)
        }
        composable("signup") {
            SignupScreen(navController)
        }
        composable("requests") {
            RequestsScreen()
        }
        composable(
            route = "profile/{name}/{department}",
            arguments = listOf(
                navArgument("name")       { type = NavType.StringType },
                navArgument("department") { type = NavType.StringType }
            )
        ) {
            ProfileScreen(navController)
        }
        composable("other_profile/{userId}") { backStackEntry ->
            val userId = backStackEntry.arguments?.getString("userId") ?: ""
            OtherUserProfileScreen(navController, userId)
        }
        composable("prefrences") {
            PrefrencesScreen(navController)
        }
        composable("events") {
            MainEventsScreen(navController)
        }
        composable("travel") {
            TravelBuddyNavHost(navController)
        }
        // New: Friends screen
        composable("friends") {
            FriendsScreen(navController)
        }
    }
}